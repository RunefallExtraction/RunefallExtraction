---
Document: Concept_Art_Briefs_Index.md
Section: 24_Concept_Art
---

# Concept Art Briefs — Index

## Document Metadata
- **Purpose:** Point to where each asset category's concept-art brief lives (embedded in that asset's own document, per this repository's no-duplication rule) rather than collecting them separately.
- **Audience:** Concept Art, Art Direction.
- **Scope:** GDD Ch. 151–155 (art direction chapters, which embed brief-level detail per champion/mob/biome rather than as separate standalone briefs).
- **Dependencies:** `17_Art/Art_Direction_Overview.md`.
- **Related Documents:** `04_Characters` (per-champion art specs), `05_Enemies`/`06_Bosses` (per-mob/boss art specs), `07_World/Risk_Rings.md` (per-biome art specs).
- **GDD Chapters Covered:** Ch. 151–155.
- **Current Implementation Status:** Not Started — no concept art exists yet; the briefs below are the GDD-authored starting point for commissioning it.

## Overview
The GDD does not author separate "concept art brief" documents — art direction (silhouette, color, polycount, mood) is embedded directly inside each champion, mob, boss, and biome's own design chapter. This index exists to make those embedded briefs discoverable as a set, for whoever is commissioning or producing concept art.

## Detailed Explanation

### Where each brief actually lives

| Asset category | Brief location |
|---|---|
| Champions (4) | `04_Characters/<Champion>/Design.md` — each has a full Art Direction section (silhouette, colors, polycount, texture budget) |
| Mobs & Bosses | `05_Enemies/Enemies_Overview.md`, `06_Bosses/Bosses_Overview.md` — visual descriptions per species/boss |
| Biomes | `07_World/Risk_Rings.md` — full palette + prop list per ring |
| General style | `17_Art/Art_Direction_Overview.md` — the shared low poly rules every brief above follows |

## Producer Notes
When concept art production actually begins (M13, or per-pillar as each milestone opens), the practical workflow is: open the relevant asset's own document above, not a separate brief file — the brief *is* that document's Art Direction / visual description section.

## Appendix
Full source: `Part15_Art_and_Audio.md`, GDD Chapters 151–155 (embedded within, not separately authored).

---
*Traceability: GDD Ch. 151–155 · Spread across owning milestones · Owner Discipline: Concept Art · Status: Not Started; briefs already embedded in owning documents.*

---
Document: UI_Screen_Catalog.md
Section: 09_UI
---

# UI Screen Catalog

## Document Metadata
- **Purpose:** Every designed UI screen — HUD, map, inventory, stash, crafting, results, pre-raid, town lobby — plus the shared style guide and the scene list they belong to.
- **Audience:** UI/UX, Engineering, Art.
- **Scope:** GDD Ch. 124 (overview/philosophy), 125 (art style), 126 (HUD), 127 (map), 128 (inventory/loadout), 129 (stash), 130 (crafting UI), 131 (results), 132 (pre-raid), 133 (town lobby), 134 (scene list).
- **Dependencies:** `08_Items/Items_Overview.md` (inventory/loadout slots).
- **Related Documents:** `02_Technical/Architecture_Decision_Log_Index.md` (ADR-0007 scene flow), `01_Production/Production_Coverage_Report_Summary.md` (NOT YET WRITTEN — the §D HUD-widget completion tracker).
- **GDD Chapters Covered:** Ch. 124–134.
- **Current Implementation Status:** Partial (~4 screens implemented: menu/HUD/results/loading, per `01_Production/GDD_Coverage_Matrix.md`); most screens below are Not Started.

## Overview
Six UI philosophy pillars — Readability, Consistency, Efficiency, Accessibility (color-blind friendly, scalable) — govern every screen, grouped into 6 categories: HUD, Inventory, Progression, Economy, Social, Lobby.

## Detailed Explanation

### UI art style (Ch. 125)
Fonts: Serif (Cinzel) for titles, Sans-serif (Roboto) for body/numbers. Borders 1–2px gold. Backgrounds dark, semi-transparent. Buttons gold fill, dark text. Icons low poly stylized.

| Element | Color | Hex |
|---|---|---|
| Background | Dark | #2A2A3A |
| Primary | Gold | #D4A76A |
| Secondary | Grey | #8B8B8B |
| Accent | Cyan | #5ADADA |
| Text | White | #FFFFFF |
| Text Dim | Grey | #6A6A6A |
| Health | Red | #A85A3A |
| Mana | Blue | #4A7A8A |
| Stamina | Green | #6B8B4A |

### Screen catalog

| Screen | Key elements | Status |
|---|---|---|
| **Raid HUD** (Ch. 126) | Minimap (top-right), Party (top-right), Timer (top-center), Extract status (top-center), Health/Mana/Stamina bars (bottom-left), Q/W/E/R abilities + 4 consumable slots (bottom-center/right), Gold/Kills/Deaths (bottom-right) | **Partial** — HP shown, most widgets Not Started |
| **Full Map** (Ch. 127, `M` key) | Landmarks (colored icons), players (team-colored dots), extract points (green icons), gathering hotspots (glowing areas), storm boundary (red) | Not Started |
| **Inventory & Loadout** (Ch. 128) | 9 equipment slots (Head/Chest/Legs/Feet/Gloves/Weapon/Off-Hand/Relic/Trinket) + 32-slot inventory grid | Not Started |
| **Stash** (Ch. 129) | 50 slots base, expandable +10 per 100 Gems, both towns, pre-raid access only | Not Started (Extraction Slice banks to an in-memory stash with no UI yet) |
| **Crafting UI** (Ch. 130) | 5 station tabs (Forge/Leather/Tailor/Alchemy/Kitchen), recipe list with materials + resulting stats, [CRAFT] button | Not Started |
| **Results Screen** (Ch. 131) | Extraction/death status, time, extracted items list, XP/Kills/Gold summary | **Partial** — implemented for the Extraction Vertical Slice (basic outcome + banked loot count) |
| **Pre-Raid UI** (Ch. 132) | Champion roster (4 cards), party list with ready checks, [JOIN MATCH] | Not Started |
| **Town Lobby** (Ch. 133) | Stash/Market/Forge/Missions row + Party/Skills/Mastery/Faction row, per-town (Falcrest/Emberwatch) | Not Started |

### Scene list (Ch. 134)

| Scene | Description | Loads |
|---|---|---|
| Boot | Initial load scene | First |
| MainMenu | Main menu | Always |
| Lobby | Town lobby | Between raids |
| Raid | Raid gameplay | Raid |
| Loading | Loading screen | Between scenes |

**Reconciliation:** the as-built scene flow (`02_Technical/Architecture_Overview.md`, ADR-0007) is `Boot → MainMenu → Loading → Raid_Greybox` — no dedicated `Lobby` scene exists yet (town lobby is Not Started), and `Loading` is implemented as a persistent overlay rather than its own scene.

## Producer Notes
This catalog is the checklist behind `Production_Coverage_Report.md`'s "UI/UX Screen Catalog" (§D) — every row here maps 1:1 to a row there, tracked per-milestone (e.g. Inventory ships with M3, Crafting UI with M6, Market UI with M7).

## Appendix
Full source: `Part13_UI_and_Scenes.md`, GDD Chapters 124–134.

---
*Traceability: GDD Ch. 124–134 · Spread across milestones (each screen ships with its owning system) · Owner Discipline: UI/UX/Engineering · Status: 2 of ~8 screen groups partially implemented.*

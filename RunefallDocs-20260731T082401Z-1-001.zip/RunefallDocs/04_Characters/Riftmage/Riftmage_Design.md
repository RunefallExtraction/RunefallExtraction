---
Document: Riftmage_Design.md
Section: 04_Characters/Riftmage
---

# Riftmage — The Burst Caster

## Document Metadata
- **Purpose:** Complete design for the Riftmage champion.
- **Audience:** Design, Engineering, Art, Animation, Audio.
- **Scope:** GDD Ch. 24.
- **Dependencies:** `../Champions_Overview.md`.
- **Related Documents:** `03_Gameplay/Combat/Combat_Overview.md`.
- **GDD Chapters Covered:** Ch. 24.
- **Current Implementation Status:** **Not Started.**

## Overview
A glass-cannon who controls space and deletes clustered foes — Mage / Burst DPS / AoE Controller, Medium difficulty.

## Detailed Explanation

### Identity
**Fantasy:** stay at maximum range, burst enemies with combos, Blink to escape, control areas with Void Zone. **Silhouette:** slender, robed, staff. **Weapon:** staff with crystal focus; orb floats near hand. **Colors:** Violet #5A3A8A primary, Cyan #5ADADA accents. **Movement:** floating, ethereal.

### Base stats

| Stat | Value |
|---|---|
| HP | 800 |
| Mana | 700 |
| Move Speed | 5.5 m/s |
| Armor | 5 |
| Magic Resist | 20 |
| HP Regen | 3 HP/s |
| Mana Regen | 4 Mana/s |

### Passive — Arcane Resonance
Ability hits reduce cooldowns by 0.5s (max 3s per ability). Visual: violet runes spin on hit.

### Basic Attack
Ranged (projectile), 14m range, 18 Magical, 0.4s cadence, 28 m/s projectile speed.

### Ability kit

| Slot | Name | Type | Windup | Cooldown | Mana | Damage | Range |
|---|---|---|---|---|---|---|---|
| Q | Arcane Bolt | Skillshot (Line) | 0.2s | 3s | 35 | 110 Magical | 15m |
| W | Blink | Teleport (Instant) | — | 8s | 40 | None | 7m |
| E | Void Zone | Ground AoE (Circle) | 0.6s | 7s | 55 | 140 Magical | 16m, 4m radius, slows |
| R | Cataclysm (Ultimate) | Ground AoE (Circle) | 1.0s | 20s | 100 | 300 Magical | 18m, 6m radius, 0.3s stagger |

**Q — Arcane Bolt:** fast, reliable poke damage. Consistent damage at range.
**W — Blink:** teleports to target location, can cross gaps. Escape, reposition, reach high ground — a critical survival tool.
**E — Void Zone:** collapsing void that damages and slows enemies inside. Control zones, deny access, combo with CC.
**R — Cataclysm:** huge delayed rift explosion, massive damage + stagger. Teamfights, chokepoints, nuking objectives — powerful but heavily telegraphed (1.0s windup, largest of any ability in the kit).

## QA Checklist
- [ ] Basic Attack
- [ ] Q — Arcane Bolt
- [ ] W — Blink
- [ ] E — Void Zone
- [ ] R — Cataclysm
- [ ] Passive — Arcane Resonance
- [ ] Art, Animation, Audio, VFX
- [ ] Mastery/progression hooks

## Appendix
Full source: `Part03_Champions.md`, GDD Chapter 24.

---
*Traceability: GDD Ch. 24 · Milestone M2 · Owner Discipline: Design/Engineering/Art · Status: Not Started.*

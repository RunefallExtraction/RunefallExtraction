---
Document: Ranger_Design.md
Section: 04_Characters/Ranger
---

# Ranger — The Ranged Skirmisher

## Document Metadata
- **Purpose:** Complete design for the Ranger champion.
- **Audience:** Design, Engineering, Art, Animation, Audio.
- **Scope:** GDD Ch. 23.
- **Dependencies:** `../Champions_Overview.md`.
- **Related Documents:** `03_Gameplay/Combat/Combat_Overview.md`.
- **GDD Chapters Covered:** Ch. 23.
- **Current Implementation Status:** **Not Started.** Design-complete, zero code (per `01_Production/GDD_Coverage_Matrix.md`).

## Overview
A mobile kiter who rains arrows — Ranged DPS / Kiter / Harasser, Medium difficulty.

## Detailed Explanation

### Identity
**Fantasy:** stay at range, kite melee threats, poke and reposition, focus priority targets. **Silhouette:** lean, agile, hooded. **Armor:** light leathers with hood. **Weapon:** longbow/shortbow, visible on back; quiver on hip. **Colors:** Forest Green #6B8B4A primary, Brown #8B6B4A accents. **Movement:** light, quick footsteps.

### Base stats

| Stat | Value |
|---|---|
| HP | 850 |
| Mana | 500 |
| Move Speed | 6.0 m/s |
| Armor | 10 |
| Magic Resist | 15 |
| HP Regen | 4 HP/s |
| Mana Regen | 2.5 Mana/s |

### Passive — Swiftfoot
10% move speed for 2s after using any ability. Visual: green wind trails.

### Basic Attack
Ranged (projectile), 14m range, 20 Physical, 0.35s cadence, 30 m/s projectile speed.

### Ability kit

| Slot | Name | Type | Windup | Cooldown | Mana | Damage | Range |
|---|---|---|---|---|---|---|---|
| Q | Piercing Arrow | Skillshot (Line) | 0.2s | 3s | 30 | 120 Physical | 16m, pierces all in line |
| W | Evasive Roll | Dash | — | 6s | 25 | None | 6m, 0.18s duration |
| E | Multishot | Cone | 0.3s | 5s | 45 | 90 Physical/arrow | 9m, 45° arc |
| R | Arrow Storm (Ultimate) | Ground AoE (Circle) | 1.0s | 15s | 75 | 50 Physical/wave ×3 | 15m, 5m radius |

**Q — Piercing Arrow:** long-range, pierces through enemies in a line. Snipe fleeing enemies or hit clumped targets.
**W — Evasive Roll:** rolls backward/sideways, avoids incoming attacks. Dodge telegraphs, reposition, kite melee.
**E — Multishot:** fan of arrows hitting all enemies in the cone. Area damage, clearing groups.
**R — Arrow Storm:** rain of arrows over an area, 3 waves over 2 seconds. Chokepoints, objectives, zoning in teamfights.

### Art direction (from Ch. 23.6, referenced)
Consistent with the low poly stylized pipeline shared across all champions — see `Vanguard_Design.md` for the format this section follows once fully authored; full skin catalog not reproduced here to avoid restating placeholder rows not yet confirmed distinct from Vanguard's pattern.

## QA Checklist
- [ ] Basic Attack
- [ ] Q — Piercing Arrow
- [ ] W — Evasive Roll
- [ ] E — Multishot
- [ ] R — Arrow Storm
- [ ] Passive — Swiftfoot
- [ ] Art, Animation, Audio, VFX
- [ ] Mastery/progression hooks

## Appendix
Full source: `Part03_Champions.md`, GDD Chapter 23.

---
*Traceability: GDD Ch. 23 · Milestone M2 · Owner Discipline: Design/Engineering/Art · Status: Not Started.*

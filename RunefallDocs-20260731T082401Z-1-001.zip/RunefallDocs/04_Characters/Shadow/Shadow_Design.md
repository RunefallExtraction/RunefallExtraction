---
Document: Shadow_Design.md
Section: 04_Characters/Shadow
---

# Shadow — The Assassin

## Document Metadata
- **Purpose:** Complete design for the Shadow champion.
- **Audience:** Design, Engineering, Art, Animation, Audio.
- **Scope:** GDD Ch. 25.
- **Dependencies:** `../Champions_Overview.md`.
- **Related Documents:** `03_Gameplay/Combat/Combat_Overview.md`.
- **GDD Chapters Covered:** Ch. 25.
- **Current Implementation Status:** **Not Started.**

## Overview
Vanish, close, burst a single target, vanish again — Assassin / Burst DPS / High-Mobility, Hard difficulty.

## Detailed Explanation

### Identity
**Fantasy:** flank the backline, burst priority targets, use stealth to escape/reposition, engage on cooldown. **Silhouette:** smallest, hunched, twin daggers. **Armor:** hooded wraps, light armor. **Colors:** Charcoal #2A2A3A primary, Grey #5A5A6A accents. **Movement:** silent, fast, low profile.

### Base stats

| Stat | Value |
|---|---|
| HP | 900 |
| Mana | 400 |
| Move Speed | 6.2 m/s (fastest champion) |
| Armor | 12 |
| Magic Resist | 12 |
| HP Regen | 4 HP/s |
| Mana Regen | 2 Mana/s |

### Passive — Shadow Adept
Basic attacks from behind deal 30% bonus damage. Visual: cyan flash on backstab.

### Basic Attack
Melee, 2.5m arc, 28 Physical, 0.45s cadence.

### Ability kit

| Slot | Name | Type | Windup | Cooldown | Mana | Damage | Range |
|---|---|---|---|---|---|---|---|
| Q | Shadow Strike | Dash (single-target) | — | 5s | 30 | 130 Physical | 8m, 0.15s duration, ends behind target |
| W | Smoke Veil | Self-buff (stealth) | 1.5s (breaks on damage/action) | 12s | 40 | None | 6s stealth, +15% move speed |
| E | Fan of Knives | Cone | 0.3s | 6s | 35 | 80 Physical/knife | 6m, 120° arc |
| R | Death Mark (Ultimate) | Single-target | 0.6s | 15s | 60 | — | 10m, +40% damage taken for 6s |

**Q — Shadow Strike:** dashes through the target for heavy damage, ends up behind them. Engage, execute, or reposition behind enemies.
**W — Smoke Veil:** stealth, breaks on dealing/taking damage or acting. Escape, reposition, set up ganks — often broken deliberately with Shadow Strike.
**E — Fan of Knives:** wide-arc knife fan. Area damage, clearing packs, finishing multiple low-HP enemies.
**R — Death Mark:** marks a target — all damage against them is +40% for 6s. Use on priority targets (healers, squishies, bosses), coordinated with team focus fire.

## QA Checklist
- [ ] Basic Attack
- [ ] Q — Shadow Strike
- [ ] W — Smoke Veil
- [ ] E — Fan of Knives
- [ ] R — Death Mark
- [ ] Passive — Shadow Adept
- [ ] Art, Animation, Audio, VFX
- [ ] Mastery/progression hooks

## Appendix
Full source: `Part03_Champions.md`, GDD Chapter 25.

---
*Traceability: GDD Ch. 25 · Milestone M2 · Owner Discipline: Design/Engineering/Art · Status: Not Started.*

---
Document: Vanguard_Design.md
Section: 04_Characters/Vanguard
---

# Vanguard — The Melee Bulwark

## Document Metadata
- **Purpose:** Complete design and current implementation status for the Vanguard champion.
- **Audience:** Design, Engineering, Art, Animation, Audio.
- **Scope:** GDD Ch. 22, cross-referenced against the actual implementation (Batch C1–C3.3).
- **Dependencies:** `Champions_Overview.md`.
- **Related Documents:** `02_Technical/Architecture_Decision_Log_Index.md` (ADR-0012 unified ability model — Shield Slam was the first real ability built on it), `03_Gameplay/Combat/Combat_Overview.md`.
- **GDD Chapters Covered:** Ch. 22.
- **Current Implementation Status:** **Partial — the only champion with any implementation.** Basic Attack and Q (Shield Slam) are implemented and verified (Combat Sandbox). W, E, R, and the passive are design-complete but Not Started.

## Overview
An armored frontline anchor who absorbs and disrupts — Tank / Initiator / Frontline Controller, Easy difficulty.

## Detailed Explanation

### Identity
**Fantasy:** hold the line, absorb damage, disrupt enemy formations, protect squishier teammates. **Silhouette:** broad, square, imposing. **Armor:** heavy plate, rounded pauldrons. **Weapon:** one-handed sword, broad and simple. **Shield:** large tower shield covering most of the body. **Colors:** Steel Blue #5A6B7A primary, Gold #D4A76A accents. **Movement:** heavy, deliberate footsteps.

### Base stats

| Stat | Value |
|---|---|
| HP | 1000 |
| Mana | 500 |
| Move Speed | 5.5 m/s |
| Armor | 20 |
| Magic Resist | 10 |
| HP Regen | 5 HP/s |
| Mana Regen | 2 Mana/s |

### Passive — Iron Will
Reduces all incoming damage by 10% when below 40% HP. Visual: steel-blue aura glow at low HP.

### Basic Attack
Melee, 2.8m arc, 25 Physical, 0.6s cadence, no telegraph (instant).

### Ability kit

| Slot | Name | Type | Windup | Cooldown | Mana | Damage | Range | Effects |
|---|---|---|---|---|---|---|---|---|
| Q | Shield Slam | Cone | 0.4s | 4s | 40 | 150 Physical | 6m cone, 120° | 0.75s stagger, ~1.5m knockback |
| W | Bulwark | Self-buff | Instant | 8s | 50 | — | — | 300 Shield HP, 140° front arc, 5s duration |
| E | Line Breaker | Dash | — | 6s | 45 | 80 Physical | 6m | Knockback along line, 0.2s duration |
| R | Unbreakable (Ultimate) | Self-buff | Instant | 20s | 100 | — | — | 50% damage reduction + CC immunity, 5s duration |

**Q — Shield Slam:** slams shield forward, damaging and shoving enemies in a frontal cone; stagger interrupts channeling. Use to interrupt boss attacks, shove enemies off cliffs, or create space.
**W — Bulwark:** raises shield in a forward arc, blocking frontal damage — shield HP absorbs before HP does. Directional; must face the threat.
**E — Line Breaker:** charges forward, damaging and shoving enemies aside. Closes gaps, pushes enemies into walls, or escapes.
**R — Unbreakable:** becomes immovable — 50% damage reduction, CC immune. Use to survive burst damage or hold a chokepoint.

### Art direction
Polycount 10,000 tris · Texture 1024×1024 (solid colors) · Rig 60 bones · Height 1.8m.

| Part | Color |
|---|---|
| Armor | Steel Blue #5A6B7A |
| Shield | Steel Blue + Gold #5A6B7A + #D4A76A |
| Cape | Deep Red #8B3A2A |
| Accents | Gold #D4A76A |
| Skin | Light Tan #D4B89A |

**Skins:** Default (Free) · Royal Sentinel — White+Gold, Paladin theme (900 gems) · Molten Warden — Dark Red+Orange, Fire theme (1,200 gems) · Rift-Touched — Violet+Cyan, Corrupted theme (1,500 gems) · Frostguard — White+Cyan, Ice theme (1,200 gems) · Shadow Paladin — Black+Purple, Dark theme (1,500 gems).

## Implementation Status (cross-check)
`Batch_C3_ShieldSlam_Design.md` established Shield Slam as the **first real ability**, deliberately built to prove the permanent ability model (`AbilityDef` + phase FSM + `IAbility` strategy) that every subsequent ability — for every champion and every mob — reuses. The implemented numbers (150 physical, 6m/120° cone, 0.75s stagger, 4s cooldown) match this GDD spec exactly. W (Bulwark), E (Line Breaker), R (Unbreakable), and the Iron Will passive remain **Not Started**.

## QA Checklist
- [x] Basic Attack implemented and verified
- [x] Q — Shield Slam implemented and verified (Combat Sandbox)
- [ ] W — Bulwark
- [ ] E — Line Breaker
- [ ] R — Unbreakable
- [ ] Passive — Iron Will
- [ ] Art (model, textures, rig)
- [ ] Animation set
- [ ] Audio (ability/impact sounds)
- [ ] VFX (beyond greybox telegraph)
- [ ] Mastery/progression hooks
- [ ] AI compatibility (usable by an AI-controlled Vanguard, if ever needed)

## Appendix
Full source: `Part03_Champions.md`, GDD Chapter 22; `Batch_C3_ShieldSlam_Design.md`.

---
*Traceability: GDD Ch. 22 · Milestone M1 (Q shipped) / M2 (rest) · Owner Discipline: Design/Engineering/Art · Status: Partial (Basic Attack + Q done).*

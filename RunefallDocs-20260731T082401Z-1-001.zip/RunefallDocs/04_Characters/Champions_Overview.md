---
Document: Champions_Overview.md
Section: 04_Characters
---

# Champions — Framework, Selection, Relics, Balance & Progression

## Document Metadata
- **Purpose:** The shared champion framework, champion select UI, the Relic (5th ability) system, balance philosophy, and account-wide progression — everything that applies across all four champions. Per-champion kits live in their own files.
- **Audience:** Design, Engineering, UI/UX.
- **Scope:** GDD Ch. 21 (overview), 26 (selection UI), 27 (relics), 28 (balance philosophy), 29 (account progression).
- **Dependencies:** `00_Executive/Design_Pillars.md`.
- **Related Documents:** `Vanguard/Vanguard_Design.md`, `Ranger/Ranger_Design.md`, `Riftmage/Riftmage_Design.md`, `Shadow/Shadow_Design.md`, `02_Technical/Architecture_Decision_Log_Index.md` (ADR-0012, ADR-0017 — the engine this framework is implemented on).
- **GDD Chapters Covered:** Ch. 21, 26, 27, 28, 29.
- **Current Implementation Status:** Framework implemented (the generic `AbilitySystem`/`IAbility` engine, ADR-0012/0017); champion selection UI, relics, and balance tuning are all **Not Started**.

## Overview
Four champions ship at launch, each a distinct archetype built on one shared, data-driven ability framework.

## Detailed Explanation

### Champion philosophy (Ch. 21.1)
Every champion has: 4 active abilities (Q/W/E/R), a basic attack (melee or ranged), 1 Relic slot (a 5th ability granted by an equipped Relic item), and 1 always-active passive.

### Global controls (Ch. 21.2)

| Action | PC | Mobile |
|---|---|---|
| Move-to-point | Right-click | Joystick (left) |
| Basic Attack | Left-click | Tap/drag on enemy (right) |
| Abilities | Q/W/E/R | Ability buttons (bottom-right) |
| Sprint | Shift | Sprint button |
| Gather/Loot/Open | F | Interact button |
| Ping | Z | Ping button + selection |
| Target Select | Left-click on target | Tap target |

### Champion art overview (Ch. 21.3)

| Champion | Silhouette | Primary Color | Role |
|---|---|---|---|
| Vanguard | Broad, shield, heavy armor | Steel Blue | Tank |
| Ranger | Lean, hood, bow | Forest Green | Ranged DPS |
| Riftmage | Slender, robes, staff | Violet | Mage |
| Shadow | Hooded, daggers, dark | Charcoal | Assassin |

### The ability framework (Ch. 21.4)
`Windup (0.2–1.0s, telegraph visible) → Active (instant/duration) → Recovery (0.1–0.3s)`. Every ability is data-driven: mana cost (25–100), cooldown (3–20s), telegraph shape (Line/Cone/Circle/Ring/Self), server-authoritative validation on every hit. **This is exactly what `AbilitySystem`'s phase FSM implements** (ADR-0012) — see `03_Gameplay/Combat/Combat_Overview.md`.

### Champion selection & party UI (Ch. 26)
Pre-raid select screen: roster of 4 portraits (left), rotating 3D preview (center), stats/toolkit (right), READY button. Cards show portrait, name, role tag, difficulty, live pick-rate. **Party cap: 3 players.** Recommended composition: 1 Tank + 1 Ranged DPS + 1 Flex — a design intent, not an enforced rule. Flow: Champion Selection → Party Ready → Join Match → Matchmaking (10–60s queue) → Match Found → Loading Screen → Edge Spawn.

### Relic items — the 5th ability slot (Ch. 27)
A Relic item grants a 5th active ability on its own dedicated key (**T on PC** — a V4.0 ruling; R stays reserved for the champion ultimate). Dropped by bosses (3–8%), rare chests, or the Warden faction trader at high reputation.

| Relic | Effect | Cooldown | Acquisition |
|---|---|---|---|
| Stormcaller's Amulet | Lightning at target, 100 Magical, circle AoE | 15s | Matron of Thorns (3%) |
| Ember Core | 150 Physical cone + burn (20/s for 3s) | 12s | Grumnir (4%) |
| Shadow Cloak | 1s invisibility + 30% move speed | 20s | Hollow King (8%) |
| Guardian Idol | Heals 50 HP/s for 3s, 15m radius | 25s | Rare chests (1%) |
| Void Crystal | Trap, 2m radius, 100 Magical | 10s | Warden reputation (Honored) |
| Bloodstone | +20% lifesteal for 5s | 18s | Bosses (2%) |

### Champion balance philosophy (Ch. 28)

| Champion | Target pick rate |
|---|---|
| Vanguard | 25–30% |
| Ranger | 25–30% |
| Riftmage | 20–25% |
| Shadow | 20–25% |

**Design intent:** no champion should exceed 35% pick rate (dominant) or fall below 15% (irrelevant). Balance patches monthly (or as needed), driven by pick rates, win rates (extraction success), K/D ratios, and average extracted value per champion.

**Tuning parameters:** Damage ±10–20%/patch · Cooldown ±0.5–2s/patch · Mana Cost ±5–15/patch · HP ±50–100/patch · Move Speed ±0.1–0.3 m/s/patch.

### Champion progression — account-wide (Ch. 29)
**All four champions are unlocked at launch — no unlock grind.** Collection Log tracks champion kills/boss kills/unique items. Mastery XP is per-champion, banked on extraction (see `03_Gameplay/Progression/Progression_Overview.md`). Cosmetics are purchased account-wide, usable on any champion (subject to model constraints).

## Producer Notes
Only Vanguard has any implementation today (basic attack + Shield Slam, per `01_Production/GDD_Coverage_Matrix.md`). Ranger, Riftmage, and Shadow are 100% design-complete, 0% implemented — each is a straightforward `ChampionDef` + 4 `AbilityDef`s + one `ShapedStrikeAbility`/future-strategy consumer once the generic framework is available, per the reusability already proven by Shield Slam.

## Appendix
Full source: `Part03_Champions.md`, GDD Chapters 21, 26–29.

---
*Traceability: GDD Ch. 21, 26–29 · Milestone M2 · Owner Discipline: Design/Engineering/UI · Status: Framework implemented; UI/relics/balance Not Started.*

---
Document: Matchmaking_Design.md
Section: 14_Networking
---

# Matchmaking — Design Summary

## Document Metadata
- **Purpose:** How players queue, form parties, and get matched into a raid.
- **Audience:** Design, Production, QA.
- **Scope:** `TDD-04_Matchmaking.md` in full.
- **Dependencies:** `Networking_Design_Summary.md`.
- **Related Documents:** `15_Backend/Server_and_Orchestration.md` (NOT YET WRITTEN — the `/spawn` handoff this depends on).
- **GDD Chapters Covered:** Ch. 137 (matchmaking flow), 222–229.
- **Current Implementation Status:** **Not Started.** Milestone M12.

## Overview
Nakama-based matchmaking: solo or party-of-3 queueing, gear-score banding for fairness, and a handoff to the orchestrator that spawns (or reuses) a dedicated server.

## Detailed Explanation

### Ticket lifecycle
Client creates a matchmaking ticket via Nakama socket (party of up to 3), carrying gear score / region / champion properties. Nakama assembles tickets **every 2 seconds**; ticket TTL up to 12 hours; the pool is sized for up to 10,000 tickets.

### Gear-score banding
A gear score is computed from equipped Mk tiers/item stats. Matching happens within a band, which **widens with queue time** to bound wait (a fairness/latency tradeoff) — exact band widths and the widen schedule are an explicitly open design question, parameterized in config and meant to be tuned from live metrics rather than fixed upfront. **Anti-churn cohorts:** Rookie Raids (a player's first 10 raids) and Scav runs are matched in protected pools separate from mains, to protect new players from being crushed by high-gear-score veterans early.

### Party formation
Parties (≤3) queue as a unit; the matchmaker uses the party's aggregate/highest gear score for banding — specifically to prevent a high-gear player from "smurf-carrying" a low-gear-band party into an easy match.

### Match → server handoff
```
Nakama forms a match (party + fill to raid population within band)
→ MatchAssignmentSystem calls Orchestrator POST /spawn {match_id, players, region}
→ receives {ip, port, status}
→ all matched clients receive the endpoint and connect via FishNet
→ server admits up to 24 players; late/failed joins handled by the reconnect window
```
Region is chosen from the party's region property, falling back to the nearest region if unavailable.

### Edge cases
Party larger than remaining band capacity: hold the party intact, never split it across servers. Queue cancel/disconnect: ticket removed; if mid-assembly, the orchestrator spawn isn't issued until members confirm. Spawn failure (no server available): re-queue with priority, bounded retries, then a user-facing "servers busy" message. Gear-score gaming (naked-queue then swap gear before entering): loadout is locked at match formation — gear score is snapshotted at ticket creation and re-validated server-side on spawn.

## Programmer Notes
Several parameters are explicitly left open in the source TDD rather than guessed at: exact band widths + widen schedule, fixed-24 vs. dynamic-minimum raid fill policy, the cross-region latency ceiling before refusing a neighbor-region match, and whether solo/party queues share banding or are separate pools. These are flagged as decisions owed before implementation, not oversights.

## Appendix
Full source: `TDD-04_Matchmaking.md`.

---
*Traceability: GDD Ch. 137, 222–229 · Milestone M12 · Owner Discipline: Engineering/Design · Status: Not Started; several parameters explicitly open.*

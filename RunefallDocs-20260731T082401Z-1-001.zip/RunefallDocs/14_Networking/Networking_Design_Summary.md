---
Document: Networking_Design_Summary.md
Section: 14_Networking
---

# Networking — Design Summary

## Document Metadata
- **Purpose:** The gameplay-facing summary of the networking design — what players will experience once M12 ships — distinct from the deep engineering contract in `TDD-01_Networking.md`.
- **Audience:** Design, Production, QA; Engineering readers should go straight to the source TDD.
- **Scope:** `TDD-01_Networking.md` in full.
- **Dependencies:** `02_Technical/Architecture_Decision_Log_Index.md` (ADR-0003 transport decision).
- **Related Documents:** `Matchmaking_Design.md`, `15_Backend/Server_and_Orchestration.md` (NOT YET WRITTEN), `16_Database/Schema_Reference.md` (NOT YET WRITTEN).
- **GDD Chapters Covered:** Ch. 136 (network architecture), 214–221 (Phase 1: network & multiplayer), 310 (disconnect/reconnect).
- **Current Implementation Status:** **Not Started.** This is Milestone M12, deliberately deferred (single-player-first, ADR-0005) but built behind server-authoritative-ready seams throughout every other system.

## Overview
FishNet-based, server-authoritative, 30 Hz simulation, 24 players per raid instance, with a 4-minute reconnect window that keeps a disconnected player's body live in the match.

## Detailed Explanation

### Core model
- **Server-authoritative:** the dedicated server validates every action; clients send inputs, never authoritative results.
- **Tick rate:** fixed 30 Hz server simulation.
- **Latency handling:** 150ms ping cap; client-side prediction + reconciliation; remote entities interpolated (`interpolationTime = 0.1s`), snap-corrected beyond `maxReconcileDistance = 5m`.
- **Capacity:** 24 players per raid instance, plus AI, within the 30 Hz frame budget.
- **Resilience:** transactional, idempotent state mutations — no duplication under packet loss or reconnect.

### Transport
**ENet/UDP** for real-time gameplay traffic, with a **WebSocket** fallback for restrictive networks/mobile web (ADR-0003 — this resolves a discrepancy in the GDD itself, which lists WebSocket in its architecture table but shows ENet/UDP sample code).

### Authority & data flow
`Client → Server`: movement input, ability requests, RPC calls. `Server → Client`: world state, positions, damage/CC events, SyncVar updates. Movement: client sends input, server simulates authoritative position, owner reconciles, remotes interpolate; server rejects impossible deltas (speed/encumbrance-aware). Abilities: client requests a cast; the server runs the authoritative `AbilitySystem` through its phase FSM and emits phase events; the client only plays telegraphs/VFX off those events — **this is exactly the seam the current single-player `AbilitySystem` already implements** (ADR-0012), which is why the retrofit is expected to be a transport swap, not a gameplay rewrite.

### Connection lifecycle & reconnect
Connect → auth handshake (session token + config-hash check, reject mismatches) → spawn `NetworkedPlayer` → heartbeat every 5s. **Reconnect:** a **4-minute window** during which the player's body persists live in the match; auto-reconnect 3× at 5s intervals, then a "Rejoin Raid" button while the window is open. On rejoin: position, HP, inventory, cooldowns, and attunement restore bit-exact. If the body dies during disconnect, kill-cam attributes the kill correctly and the player sees the Results screen with "Connection lost" framing.

### Idempotency
All inventory/economy mutations carry idempotency keys; corpse looting is exclusive-access with a 2-player queue. Replays of a mutation under packet loss are no-ops — this is the same idempotency discipline already implemented in the (single-player) Extraction Vertical Slice's stash transfer (ADR-0018), designed from day one to survive the eventual multiplayer retrofit unchanged.

## Programmer Notes
The single open engineering question flagged in the source TDD: true network interest management (distance/grid-based observer scoping) is recommended but not yet decided — the GDD as written relies on `[ObserversRpc]` + occlusion culling alone, which would scale bandwidth/CPU with total-world entities rather than visible ones at 24 players + full mob population.

## Appendix
Full source: `TDD-01_Networking.md`.

---
*Traceability: GDD Ch. 136, 214–221, 310 · Milestone M12 · Owner Discipline: Engineering · Status: Not Started (design finalized, seams already in place).*

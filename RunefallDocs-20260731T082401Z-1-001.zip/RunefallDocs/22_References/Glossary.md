---
Document: Glossary.md
Section: 22_References
---

# Glossary

## Document Metadata
- **Purpose:** Definitions for terms used repeatedly across this repository, so a new reader isn't left guessing at project-specific vocabulary.
- **Audience:** Everyone, especially new team members.
- **Scope:** Cross-cutting — terms drawn from the GDD and from the project's own engineering/production vocabulary.
- **Dependencies:** None.
- **Related Documents:** All.
- **GDD Chapters Covered:** N/A (cross-cutting reference).
- **Current Implementation Status:** N/A.

## Overview
Alphabetical glossary of Runefall-specific and project-process terms.

## Detailed Explanation

**ADR (Architecture Decision Record)** — a dated, numbered record of a major engineering decision with context and reasoning. See `02_Technical/Architecture_Decision_Log_Index.md`.

**Ashen Reach** — the name of Runefall's single map.

**Attunement** — temporary, per-raid power gained from shrines; resets on death/extraction. See `03_Gameplay/Progression/Progression_Overview.md`.

**Boon** — a temporary buff granted by a landmark, similar to Attunement. See `03_Gameplay/Progression/Progression_Overview.md`.

**Combat Sandbox** — the verified test scenario (3 Husks + 3 Bandit Archers, multiple compositions) used to close out early AI/combat implementation. See `00_Executive/Current_Project_Status.md`.

**Deadzone** — informal name for the Core ring, the highest-risk zone at the map's center.

**Extraction Vertical Slice** — the closed, Production-Ready implementation of the carry→extract→bank-or-lose loop. See `01_Production/Vertical_Slices_Overview.md`.

**Full loot** — the design rule that all equipped and carried items drop on death. See `00_Executive/Design_Pillars.md`.

**Gear score** — a computed value from equipped Mk tiers/item stats, used for matchmaking banding. See `14_Networking/Matchmaking_Design.md`.

**Mk tier (Mk 0–Mk V)** — gear quality tiers, referenced throughout `08_Items` and `04_Characters`.

**Raid Loop** — the moment-to-moment 35–40 minute gameplay loop. See `03_Gameplay/Core_Loop_Overview.md`.

**Retrospective (R-00X)** — a written reflection closing an implementation slice, recording what stayed simple or got simpler. See `02_Technical/Architecture_Retrospectives_Index.md`.

**Risk ring** — one of the three concentric zones (Outer, Mid, Core). See `07_World/Risk_Rings.md`.

**Slice (implementation slice)** — a scoped unit of engineering work, closed only after passing the Mandatory Slice Closure Gates. See `02_Technical/Standing_Engineering_Rules.md`.

**Standing Rule** — one of 13 permanent engineering rules distilled from retrospectives. See `02_Technical/Standing_Engineering_Rules.md`.

**Storm** — the unmitigable, shrinking damage field that ends every raid. See `03_Gameplay/Extraction_Storm/Storm_System.md`.

**Telegraph** — a visible windup indicator for a dangerous ability, in a fixed shape (Line/Cone/Circle/Ring) that cosmetics can never alter. See `03_Gameplay/Combat/Combat_Overview.md`.

**Vertical slice** — a playable checkpoint cutting across milestones to prove a complete loop end-to-end. See `01_Production/Vertical_Slices_Overview.md`.

## Producer Notes
This glossary grows as new terms are coined — add an entry whenever a document introduces a project-specific term not already defined here, rather than letting readers infer meaning from context across multiple documents.

## Appendix
Terms compiled from across the repository's own document set; none are quoted from a single GDD chapter — see the "Related Documents" link on each entry for its source.

---
*Traceability: N/A (cross-cutting) · N/A · Owner Discipline: Everyone · Status: Living document — expand as new terms appear.*

---
Document: Appendices_Index.md
Section: 22_References
---

# GDD Appendices Index (A–R)

## Document Metadata
- **Purpose:** Navigation index for the 18 GDD appendices (Ch. 173–190), each a reference table/reproduction other chapters point back to.
- **Audience:** Everyone.
- **Scope:** GDD Ch. 173–190 (Part 17).
- **Dependencies:** `GDD_Chapter_Index.md`.
- **Related Documents:** Cross-referenced individually below.
- **GDD Chapters Covered:** Ch. 173–190.
- **Current Implementation Status:** N/A — reference index.

## Overview
Eighteen appendices hold reference data other chapters cite rather than restate: coordinates, schemas, ability cards, tier chains, drop tables, color palettes, and more.

## Detailed Explanation

### Appendix index

| App | Ch. | Title | Where it's used in this repository |
|---|---|---|---|
| A | 173 | Coordinate Reference | `07_World/Landmarks_Index.md` (landmark X,Y,Z table reproduced there) |
| B | 174 | Unity MapDef JSON Schema | `07_World/Ashen_Reach_Overview.md` (coordinate/sector system) |
| C | 175 | Champion Ability Cards | `04_Characters` (each champion's ability table follows this card format) |
| D | 176 | Item Tier Chains | `08_Items/Weapon_Catalog.md`, `Armor_Catalog.md` |
| E | 177 | Unified Drop Tables | `03_Gameplay/Loot_Economy/Loot_Overview.md` |
| F | 178 | Complete UI Reference Images | Referenced only — no image assets exist in the uploaded text sources |
| G | 179 | Color Palette Reference | `04_Characters` (champion colors), `07_World/Risk_Rings.md` (biome colors), `21_Lore/Setting_and_Tone.md` |
| H | 180 | Low Poly Modeling Guidelines | `17_Art/Art_Direction_Overview.md` |
| I | 181 | Connection Flow Diagram | `14_Networking/Networking_Design_Summary.md` (conceptually; not reproduced verbatim) |
| J | 182 | Server State Transitions | `15_Backend/Server_and_Orchestration.md` (conceptually) |
| K | 183 | Port Allocation Strategy | `15_Backend/Server_and_Orchestration.md` (base port 7777 referenced) |
| L | 184 | Performance Benchmarks | `17_Art/Performance_Budgets.md` |
| M | 185 | Crafting Recipes — Complete Catalog | `01_Production/GDD_Coverage_Matrix.md` cites this as the M6 authoritative recipe list; not yet expanded into its own document (M6 not started) |
| N | 186 | Ability VFX Reference | `10_VFX/VFX_Overview.md` |
| O | 187 | Animation State Machines | `12_Animation/Animation_Overview.md` |
| P | 188 | Station Interaction Details | Referenced from `01_Production/GDD_Coverage_Matrix.md` (M6); not yet expanded |
| Q | 189 | Landmark Map Reference | `07_World/Landmarks_Index.md` |
| R | 190 | Mob Behavior Trees | `13_AI/AI_Gameplay_Overview.md` |

## Producer Notes
Appendices F (UI reference images), M (full recipe catalog), and P (station interaction details) are the three not yet meaningfully expanded into their own repository documents — F because it references image assets not present in the text sources, M and P because they belong to Milestone M6 (Gathering→Refining→Crafting), which is Not Started.

## Appendix
Full source: `Part17_Appendices.md`, GDD Chapters 173–190.

---
*Traceability: GDD Ch. 173–190 · N/A (index) · Owner Discipline: Everyone · Status: N/A — reference index; 3 of 18 appendices not yet expanded elsewhere.*

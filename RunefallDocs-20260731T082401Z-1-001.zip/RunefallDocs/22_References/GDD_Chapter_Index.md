---
Document: GDD_Chapter_Index.md
Section: 22_References
---

# GDD Chapter Index (317 Chapters, 19 Parts)

## Document Metadata
- **Purpose:** The top-level map of the entire GDD — which Part covers which chapter range and topic, so any reader can find the right source document fast.
- **Audience:** Everyone.
- **Scope:** All 19 source parts of `Runefall_Extraction_GDD_V4_0.docx` as uploaded.
- **Dependencies:** None (root reference).
- **Related Documents:** `01_Production/GDD_Coverage_Matrix.md` (the same chapters, mapped to milestones instead of parts), `Appendices_Index.md`.
- **GDD Chapters Covered:** 1–317 (index-level).
- **Current Implementation Status:** N/A — reference index.

## Overview
The GDD is delivered as 19 part-files, each covering a contiguous chapter range, plus a full merged export. This index maps part → chapter range → topic.

## Detailed Explanation

### Part index

| Part | File | Chapters | Topic |
|---|---|---|---|
| 01 | `Part01_Vision_and_Pillars.md` | 1–10 | Vision, pillars, core loops, tone, art/inspiration reference, KPIs, risks |
| 02 | `Part02_World_and_Map.md` | 11–20 | Ashen Reach — dimensions, risk rings, topography, coordinates, hydrology, bridges, roads, landmarks, props, gathering hotspots |
| 03 | `Part03_Champions.md` | 21–29 | The 4 champions, selection UI, relics, balance, progression |
| 04 | `Part04_Combat.md` | 30–39 | Combat overview, telegraph language, damage model, CC, shields/healing, movement/encumbrance, logging, audio, balance |
| 05 | `Part05_Progression.md` | 40–49 | Attunement/boons, mastery, 15 account skills, collection log, faction reputation, progression UI, seasonal, achievements, data storage |
| 06 | `Part06_Gathering_Refining_Crafting.md` | 50–63 | Gathering skills, resources, refining, crafting, professions, salvage, recipes |
| 07 | `Part07_Items_and_Equipment.md` | 64–73 | Equipment slots, armor sets, weapons, trinkets, consumables, ammo/keys/barter, 30+ materials, item UI, stacking |
| 08 | `Part08_Mobs_and_AI.md` | 74–83 | Beasts, Husks, Constructs, Bandits, Rift-Touched, mini-bosses, world boss, spawn zones |
| 09 | `Part09_Loot_Economy_Market.md` | 84–93 | Looting, drop/container tables, economy, market, insurance, safe box, data storage, tuning dashboard |
| 10 | `Part10_Factions_Missions_Social.md` | 94–103 | Factions, missions/contracts, PvP, social, chat, friends, kill-cam, comeback, company |
| 11 | `Part11_Live_Events.md` | 104–113 | Dynamic raid events, seasonal content, battle pass, event scheduler |
| 12 | `Part12_Monetization.md` | 114–123 | Gems, membership, cosmetics, transmog, shops, battle pass, monetization metrics |
| 13 | `Part13_UI_and_Scenes.md` | 124–134 | UI overview, style, HUD, map, inventory, stash, crafting UI, results, pre-raid, town lobby, scene list |
| 14 | `Part14_Technical_Architecture.md` | 135–150 | Tech stack, networking, orchestration, database, matchmaking, security |
| 15 | `Part15_Art_and_Audio.md` | 151–162 | Art style, biome/champion/mob art direction, performance budgets, audio, VFX, animation, kitbash, UI art, production schedule |
| 16 | `Part16_Dev_Roadmap.md` | 163–172 | Development roadmap, fun gates, KPIs, risk assessment, live-ops dashboard, community, support, tools, final checklist |
| 17 | `Part17_Appendices.md` | 173–190 | Appendices A–R (see `Appendices_Index.md`) |
| 18 | `Part18_Implementation_Plan.md` | 191–304 | Full AI-assisted implementation plan: foundation, network, matchmaking, champions, world, mobs, gathering/crafting, progression, economy, UI/polish, infrastructure, launch |
| 19 | `Part19_Completion_Addenda.md` | 305–317 | V4.0-new: extraction & storm, NPE/tutorial, settings/accessibility, localization, voice chat, reconnect, cross-platform accounts, audio middleware, analytics taxonomy, legal/compliance, controller support, production resources, consistency rulings |

**Full merged export:** `_FULL_GDD_V4_0_extracted.md` (all 319 chapters — includes the 2 extra completion-system chapters beyond 317, per Part 19's own framing — in one file, 984K characters).

## Producer Notes
This is a navigation index only. For the same chapters organized by *milestone ownership* instead of source-file location, see `01_Production/GDD_Coverage_Matrix.md` — the two documents answer different questions ("where is chapter X in the source" vs. "who owns building chapter X").

## Appendix
Full source: all 19 uploaded GDD part files.

---
*Traceability: GDD Ch. 1–317 (complete) · N/A (index) · Owner Discipline: Everyone · Status: N/A — reference index.*

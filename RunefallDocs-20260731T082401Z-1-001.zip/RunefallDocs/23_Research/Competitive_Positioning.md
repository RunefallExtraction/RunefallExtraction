---
Document: Competitive_Positioning.md
Section: 23_Research
---

# Competitive Positioning

## Document Metadata
- **Purpose:** Pointer document — the GDD's competitive-positioning content (Ch. 7) is already fully documented in `00_Executive/Target_Audience_and_Market.md`. This document does not repeat that table; it exists so `23_Research` isn't an empty section, and to record what further market research this repository does *not* contain.
- **Audience:** Design, Production, Marketing.
- **Scope:** GDD Ch. 7 — see `00_Executive/Target_Audience_and_Market.md` for the full content.
- **Dependencies:** `00_Executive/Target_Audience_and_Market.md`.
- **Related Documents:** `00_Executive/Executive_Overview.md`.
- **GDD Chapters Covered:** Ch. 7.
- **Current Implementation Status:** N/A.

## Overview
The GDD's own competitive differentiation table (Runefall vs. Tarkov/Hunt: Showdown/Albion Online on progression, combat, economy, accessibility, social, art style) lives in `00_Executive/Target_Audience_and_Market.md`.

## See Also
`00_Executive/Target_Audience_and_Market.md` — the full "Key differentiators vs. competitors" table.

## What this repository does NOT contain
A genuine market-research report (competitor player counts, pricing benchmarks, feature-by-feature teardowns, addressable-market sizing) is **NOT DEFINED IN GDD** and does not exist in any uploaded project document. If commissioned, it belongs here as new content, clearly marked as a Recommendation with its own Purpose/Benefits/Drawbacks/Effort assessment per this repository's Recommendation format — not folded silently into the Executive summary.

---
*Traceability: GDD Ch. 7 · N/A · Owner Discipline: Design/Marketing · Status: N/A — see `00_Executive/Target_Audience_and_Market.md`.*

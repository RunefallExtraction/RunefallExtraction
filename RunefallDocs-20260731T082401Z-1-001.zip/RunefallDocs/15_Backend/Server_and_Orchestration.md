---
Document: Server_and_Orchestration.md
Section: 15_Backend
---

# Server & Orchestration — Design Summary

## Document Metadata
- **Purpose:** How dedicated game-server instances are built, deployed, allocated, scaled, and recovered.
- **Audience:** Design/Production (for capacity awareness), Engineering.
- **Scope:** `TDD-02_Server_and_Orchestration.md` in full.
- **Dependencies:** `14_Networking/Networking_Design_Summary.md`.
- **Related Documents:** `16_Database/Schema_Reference.md`, `14_Networking/Matchmaking_Design.md`.
- **GDD Chapters Covered:** Ch. 138, 140–142, 196–206, 225–234.
- **Current Implementation Status:** **Not Started.** Milestone M12.

## Overview
Each raid runs on an isolated, authoritative headless Unity server process, spawned on demand and terminated when empty, orchestrated by a Node.js service on Kubernetes.

## Detailed Explanation

### Headless server
Build: Unity headless (`-batchmode -nographics`), Linux Ubuntu 22.04, launched with `-config config.json`. Authoritative config:
```json
{ "tickRate": 30, "timeoutSeconds": 30, "heartbeatInterval": 5,
  "stormTimer": 2100, "stormDuration": 300,
  "port": 7777, "maxPlayers": 24,
  "logging": { "level": "info", "console": true, "file": true } }
```
Server assemblies exclude UI/VFX/Audio to minimize footprint. **Storm is server-owned:** 2100s active + 300s collapse = 40-minute raid; the storm boundary shrink is authoritative and validated against player position for extraction — matching the exact timeline in `03_Gameplay/Extraction_Storm/Storm_System.md`.

### Containerization & Kubernetes
Game server, Nakama, PostgreSQL, Redis, TimescaleDB each containerized; Game Server and Nakama run under a Kubernetes Horizontal Pod Autoscaler; load balancer is Nginx/HAProxy with HTTPS/HSTS.

### Orchestrator service (Node.js)
| Endpoint | Method | Purpose |
|---|---|---|
| `/spawn` | POST | Allocate a game server for a matched party — `{match_id, players, region}` → `{port, ip, status}` |
| `/terminate` | POST | Stop an empty/finished server — `{port}` → `{status}` |
| `/health` | GET | Orchestrator health → `{status, cpu, ram}` |

### Auto-scaling

| Metric | Threshold | Action |
|---|---|---|
| CPU | > 70% | Scale up (add server pods) |
| Demand/empty | Empty server | Scale down / terminate |

A warm pool avoids cold-start latency on match assignment; ports are pre-allocated (base 7777, incrementing per instance).

### Lifecycle & failure recovery
`ServerHeartbeat` every 5s → orchestrator marks unhealthy on miss → failure recovery restarts/reassigns. Because banked progression persists in PostgreSQL, a crashed raid loses only in-raid (un-extracted) state — consistent with the full-loot design (a server crash is treated the same as a death for anything not yet extracted). The reconnect window (`14_Networking/Networking_Design_Summary.md`) is honored across brief restarts where feasible.

### Match → server data flow
```
Matchmaker forms party of 3 → MatchAssignmentSystem asks Orchestrator /spawn
→ Orchestrator picks region + warm pod, returns {ip, port} → clients connect (FishNet)
→ ServerHeartbeat reports health → on empty, Orchestrator /terminate
```

### Live-ops dashboard
A Unity app for live ops: server list with region/load, spawn/terminate/add/remove controls, auto-scaling config, live metrics (CPU, memory, player count).

## Producer Notes
Several deployment parameters are explicitly flagged as owed decisions in the source TDD, not oversights: the cloud/VPS provider and K8s flavor (managed vs. self-hosted), the warm-pool size per region (needs a demand model, start conservative), and how server binaries are versioned/rolled with client releases (gated by the config-hash handshake from `14_Networking`).

## Appendix
Full source: `TDD-02_Server_and_Orchestration.md`.

---
*Traceability: GDD Ch. 138, 140–142, 196–206, 225–234 · Milestone M12 · Owner Discipline: Engineering · Status: Not Started; storm config already reserved.*

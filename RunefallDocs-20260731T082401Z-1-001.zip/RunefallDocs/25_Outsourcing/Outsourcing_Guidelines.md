---
Document: Outsourcing_Guidelines.md
Section: 25_Outsourcing
---

# Outsourcing Guidelines

## Document Metadata
- **Purpose:** State clearly that no outsourcing process exists yet, rather than leaving this section silently empty or inventing one.
- **Audience:** Production.
- **Scope:** N/A — no GDD chapter and no uploaded project document defines an outsourcing process.
- **Dependencies:** None.
- **Related Documents:** `01_Production/Production_Governance_and_Operating_Model.md` (the Definition of Done / asset checklist any outsourcing partner would need).
- **GDD Chapters Covered:** None.
- **Current Implementation Status:** **NOT YET IMPLEMENTED.**

## Overview
NOT YET IMPLEMENTED — no outsourcing process, vendor list, contract template, or asset-handoff pipeline is defined anywhere in the GDD or the current project documentation.

## What exists that an outsourcing effort would build on
Nothing outsourcing-specific, but two things this repository already provides would be direct inputs whenever an outsourcing process is designed: the per-asset-type Definition-of-Done templates in `01_Production/Production_Governance_and_Operating_Model.md` (Champion/Mob/Boss/Landmark/Resource-Node/UI-Screen/VFX-Audio checklists), and this repository itself as the onboarding material an external studio would need.

## Producer Notes
If outsourcing is commissioned, the guidelines that result belong here as new content — vendor selection criteria, asset handoff format, review/approval workflow, IP/contract terms — clearly authored as project process, not extracted from a GDD chapter that doesn't exist.

---
*Traceability: N/A · N/A · Owner Discipline: Production · Status: NOT YET IMPLEMENTED.*

---
Document: Compliance_and_Legal.md
Section: 29_Legal
---

# Legal, Compliance & Platform Certification

## Document Metadata
- **Purpose:** Age ratings, monetization compliance, data protection, and platform certification requirements.
- **Audience:** Production, Legal, Monetization, Engineering.
- **Scope:** GDD Ch. 314.
- **Dependencies:** `28_Monetization/Monetization_Overview.md` (NOT YET WRITTEN).
- **Related Documents:** `00_Executive/Platform_and_Hardware_Targets.md`, `27_Analytics/Analytics_Taxonomy.md` (the PII rule this chapter governs).
- **GDD Chapters Covered:** Ch. 314.
- **Current Implementation Status:** Not Started — no legal documents drafted, no certification work begun. Scheduled for Phase 9 (drafting) / Phase 11 (legal review) per the source chapter.

## Overview
Target ratings ESRB T / PEGI 12, no loot boxes by design, GDPR/CCPA-compliant data handling with self-service export/deletion, and a platform certification checklist gating Phase 11 (launch).

## Detailed Explanation

### Age ratings & content (Ch. 314.1)
Target: **ESRB T, PEGI 12** (fantasy violence, no gore — consistent with the low poly art style — plus in-game purchases and user-interaction descriptors). Proximity voice and open trade require a "Users Interact" disclosure everywhere those features appear. Minimum age 13 (16 where locally required); under-threshold accounts get voice **off by default**.

### Monetization compliance (Ch. 314.2)
**No loot boxes exist in the design** — all shops are direct-purchase — and this is a stated constraint to *keep*, not just a current state: any future "random cosmetic" mechanic must pass legal review specifically for jurisdictions with loot-box regulation (e.g. Belgium, Netherlands) before being considered. This directly reinforces `00_Executive/Design_Pillars.md` Pillar 5 (Fair Monetization) from the legal side, not just the design side. Battle Pass and gem bundles must show local-currency price and the gem-to-currency conversion math; platform stores (Apple/Google/Steam) take purchases on their own rails.

### Data protection (Ch. 314.3)
GDPR/CCPA compliance: a privacy policy shown at account creation; self-service data export and deletion in Settings → Account (deletion executes a backend purge plus a Nakama account wipe within 30 days); analytics consent for optional diagnostics on iOS (App Tracking Transparency is **not** required, since no cross-app tracking exists in the design).

### Platform certification checklist (Ch. 314.4 — a Phase 11 gate)
Apple/Google: background/foreground handling, in-app-purchase restore, an account-deletion button (Apple guideline 5.1.1(v)), 120Hz ProMotion safety. Steam: overlay support, cloud-save conflict UI (account-authoritative — "server wins" is the trivial resolution). Steam Deck verification is a stretch goal tied to controller support.

### Required legal documents (Ch. 314.5)
Terms of Service, EULA, Privacy Policy, Community Guidelines (enforced via the kill-cam/reporting system and community management process) — drafted in Phase 9, legal-reviewed by Phase 11.

## Producer Notes
The "no loot boxes, keep it that way" rule is one of the few places in the GDD where a legal constraint and a design pillar (Pillar 5) reinforce each other explicitly — any monetization proposal that drifts toward randomized paid rewards should be checked against both this document and `00_Executive/Design_Pillars.md` before proceeding.

## Appendix
Full source: `Part19_Completion_Addenda.md`, GDD Chapter 314.

---
*Traceability: GDD Ch. 314 · Milestone M13 (Phase 9 draft / Phase 11 review) · Owner Discipline: Legal/Production/Monetization · Status: Not Started.*

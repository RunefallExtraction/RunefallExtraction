---
Document: Trinkets_and_Consumables.md
Section: 08_Items
---

# Trinkets, Consumables, Ammo & Keys

## Document Metadata
- **Purpose:** Rings/amulets, potions/food, combat consumables, and ammo/keys/barter items.
- **Audience:** Design, Engineering.
- **Scope:** GDD Ch. 67 (trinkets), 68 (consumables), 69 (ammo/keys/barter).
- **Dependencies:** `Items_Overview.md`.
- **Related Documents:** `Armor_Catalog.md`, `Weapon_Catalog.md`.
- **GDD Chapters Covered:** Ch. 67, 68, 69.
- **Current Implementation Status:** Not Started.

## Overview
Craftable trinkets, brewed/cooked consumables, and the ammo/key/barter economy that gates chests and faction reputation.

## Detailed Explanation

### Rings & Amulets (Ch. 67)
Both scale T1–T4 (+Rune variant at T4) granting flat HP/Mana and, at the top tier, a small % bonus (Rune Ring: +5% Damage; Rune Amulet: +5% Resist).

### Potions (Ch. 68.1)
Health and Mana potions, each T1–T4, scaling from 50 HP/30 Mana (T1) to 350 HP/210 Mana (T4), all instant-effect, crafted from tiered herbs (Swiftthistle → Kingsblood → Dreamfoil → Riftbloom).

### Food (Ch. 68.2)
Cooked Meat (T1, +2 HP/s/30s) → Fish Stew (T2) → Hearty Meal (T3, adds +5% damage) → Feast (T4, +10 HP/s +5 Mana/s +10% damage/90s) — food buffs stack HP/Mana regen with combat bonuses at higher tiers, unlike potions which are pure instant heals.

### Combat consumables (Ch. 68.3)
Stamina Potion (T2) · Resistance Potion (T3, +20% resist/60s) · Power Potion (T3, +20% damage/45s) · Speed Potion (T3, +20% move speed/30s).

### Ammo (Ch. 69.1)
Arrow (T1) → Iron Arrow (T2, +10% dmg) → Silver Arrow (T3, +20% dmg vs. undead) → Rune Arrow (T4, +30% dmg).

### Keys (Ch. 69.2)
Iron Key (T1, basic chests, bandit drops) → Silver Key (T2, T2 chests, Bandit Elite drops) → Gold Key (T3, T3 chests, boss drops) → Rune Key (T4, Rune Vaults, boss drops + faction reputation).

### Barter items (Ch. 69.3)
Bandit Insignia (T2, faction reputation) · Rune Fragment (T3, faction reputation + crafting) · Void Shard (T4, faction reputation + enchanting) · Scrap (T1, salvage + crafting).

## Designer Notes
Keys are the explicit gate between "regular loot" and "locked chest loot" (`03_Gameplay/Loot_Economy/Loot_Overview.md` container tables) — the Rune Key is the only key sourced from both boss drops *and* faction reputation, making faction grinding a legitimate alternate path to endgame loot access.

## Appendix
Full source: `Part07_Items_and_Equipment.md`, GDD Chapters 67–69.

---
*Traceability: GDD Ch. 67–69 · Milestone M3 · Owner Discipline: Design/Engineering · Status: Not Started.*

---
Document: Armor_Catalog.md
Section: 08_Items
---

# Armor Catalog

## Document Metadata
- **Purpose:** The complete armor catalog — three material families × four tiers each.
- **Audience:** Design, Engineering, Art.
- **Scope:** GDD Ch. 65.
- **Dependencies:** `Items_Overview.md`.
- **Related Documents:** `Weapon_Catalog.md`, `Materials_and_Resources.md`.
- **GDD Chapters Covered:** Ch. 65.
- **Current Implementation Status:** Not Started (design-complete catalog, no gear model to author it into yet).

## Overview
Three armor families (Cloth, Leather, Metal) each scale across 4 tiers, with Total Protection roughly doubling per tier within a family and Metal > Leather > Cloth at equal tier.

## Detailed Explanation

### Cloth armor sets

| Set | Tier | Total Protection |
|---|---|---|
| Cloth | 1 | 25 |
| Silk | 2 | 50 |
| Rune | 3 | 100 |
| Void | 4 | 175 |

Each set = Hood + Robe + Pants + Shoes + Gloves, named per-tier (e.g. Rune Hood, Rune Robe...).

### Leather armor sets

| Set | Tier | Total Protection |
|---|---|---|
| Leather | 1 | 50 |
| Thick | 2 | 100 |
| Corrupted | 3 | 175 |
| Void | 4 | 275 |

Each set = Hood + Vest + Pants + Boots + Gloves.

### Metal armor sets

| Set | Tier | Total Protection |
|---|---|---|
| Chainmail | 1 | 100 |
| Plate | 2 | 200 |
| Heavy Plate | 3 | 325 |
| Rune Plate | 4 | 475 |

Each set = Coif/Helmet + Chest + Legs + Boots + Gloves/Gauntlets.

## Designer Notes
The three families are a deliberate risk/mobility triangle: Cloth is lightest (best for casters, worst protection), Metal is heaviest (best protection, worst encumbrance), Leather sits between. This directly interacts with the Encumbrance system (`03_Gameplay/Combat/Combat_Data.md`) — a fully-decked Rune Plate set is a real mobility cost, not just a stat upgrade.

## Appendix
Full source: `Part07_Items_and_Equipment.md`, GDD Chapter 65.

---
*Traceability: GDD Ch. 65 · Milestone M3 · Owner Discipline: Design/Engineering/Art · Status: Not Started.*

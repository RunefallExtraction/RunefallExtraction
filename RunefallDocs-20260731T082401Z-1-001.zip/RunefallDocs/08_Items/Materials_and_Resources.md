---
Document: Materials_and_Resources.md
Section: 08_Items
---

# Materials & Resources — The 30+ Loot Materials

## Document Metadata
- **Purpose:** The full raw-material list (35 materials across 10 categories) and their per-tier resource stats.
- **Audience:** Design, Engineering (`Gathering`/`Refining` systems), Art.
- **Scope:** GDD Ch. 70 (materials list), 71 (resources by tier).
- **Dependencies:** `Items_Overview.md`, `Armor_Catalog.md`, `Weapon_Catalog.md` (materials feed both).
- **Related Documents:** `03_Gameplay/Loot_Economy/Loot_Overview.md` (drop sources), `01_Production/Milestone_Index.md` (M6 Gathering→Refining→Crafting).
- **GDD Chapters Covered:** Ch. 70, 71.
- **Current Implementation Status:** Not Started — 2 of 35 materials exist as placeholder loot items (Corrupted Bone, Rift Essence) from the Husk Grunt Combat Sandbox drop.

## Overview
Ten material categories (Ore, Wood, Herb, Fish, Hide, Meat, Bone, Crystal, Essence, Scrap), each spanning 1–4 tiers, sourced from a specific gathering skill.

## Detailed Explanation

### Material categories & sources

| Category | Tiers | Source skill | Example (T1→T4) |
|---|---|---|---|
| Ore | 5 (incl. Mithril) | Mining | Copper → Iron → Silver → Gold → Mithril |
| Wood | 5 (incl. Shadowwood) | Lumbering | Pine → Oak → Ash → Ironwood → Shadowwood |
| Herb | 4 | Herbalism | Swiftthistle → Kingsblood → Dreamfoil → Riftbloom |
| Fish | 4 | Fishing | Trout → Salmon → Sturgeon → Voidfish |
| Hide | 4 | Skinning | Hide → Thick → Corrupted → Void |
| Meat | 4 | Skinning | Raw Meat → Venison → Bear Meat → Corrupted Meat |
| Bone | 4 | Skinning | Bone → Thick → Corrupted → Void |
| Crystal | 3 | Mining | Crystal Shard → Rune Crystal → Void Crystal |
| Essence | 2 | Rift-Touched/Core Beasts | Rift Essence → Void Essence |
| Scrap | 3 | Salvage | Scrap Metal, Scrap Wood, Tech Parts |

**35 materials total.** Value scales roughly with tier within each category (e.g. Ore: 10/25/50/100/150 gold for Copper/Iron/Silver/Gold/Mithril).

### Resources by ring tier (Ch. 71)
Materials are grouped by which ring they're primarily found in, each with a max stack size, weight/unit, and value/unit:
- **T1 (Outer):** Copper Ore, Pine Wood, Swiftthistle, Trout, Hide, Raw Meat, Bone, Crystal Shard, Scrap Metal, Scrap Wood.
- **T2 (Mid):** Iron Ore, Oak Wood, Kingsblood, Salmon, Thick Hide, Venison, Thick Bone, Tech Parts.
- **T3 (Mid/Core):** Silver Ore, Ash Wood, Dreamfoil, Sturgeon, Corrupted Hide, Bear Meat, Corrupted Bone, Rune Crystal, Rift Essence.
- **T4 (Core):** Gold Ore, Mithril Ore, Ironwood, Shadowwood, Riftbloom, Voidfish, Void Hide, Corrupted Meat, Void Bone, Void Crystal, Void Essence.

Stack limits by type: Ore/Wood/Scrap = 100 per stack; Herbs/Fish/Hides/Meat/Crystals = 50; Bones = 50 (Essences 20, smallest stack). Equipment never stacks (1 per slot); Consumables cap at 20.

## Producer Notes
Materials Corrupted Bone and Rift Essence already exist as real loot items (Husk Grunt drop), which makes them the natural starting point when M6 (Gathering→Refining→Crafting) opens — the item model + one drop source already exists for those two; the other 33 need both the item and a gathering/drop source built.

## Appendix
Full source: `Part07_Items_and_Equipment.md`, GDD Chapters 70–71.

---
*Traceability: GDD Ch. 70–71 · Milestone M6 · Owner Discipline: Design/Engineering · Status: 2 of 35 materials exist as placeholder drops.*

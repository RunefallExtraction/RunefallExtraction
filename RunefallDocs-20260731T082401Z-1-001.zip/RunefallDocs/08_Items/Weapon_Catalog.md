---
Document: Weapon_Catalog.md
Section: 08_Items
---

# Weapon Catalog

## Document Metadata
- **Purpose:** The complete weapon catalog across all weapon types and tiers.
- **Audience:** Design, Engineering, Art.
- **Scope:** GDD Ch. 66.
- **Dependencies:** `Items_Overview.md`.
- **Related Documents:** `Armor_Catalog.md`, `04_Characters` (per-champion weapon fantasy).
- **GDD Chapters Covered:** Ch. 66.
- **Current Implementation Status:** Not Started as a catalog; Vanguard's basic attack (25 physical, 2.8m melee) is the only weapon-adjacent thing implemented, and it's champion-intrinsic, not drawn from this catalog yet.

## Overview
Four weapon families (Swords, Bows, Staves, Daggers) each scale across 4 tiers with damage roughly doubling from T1 to T4.

## Detailed Explanation

### Swords (1H)

| Weapon | Tier | Damage | Speed | Range | Value |
|---|---|---|---|---|---|
| Copper Sword | 1 | 12–15 | 0.6s | 2.8m | 50 |
| Iron Sword | 2 | 18–22 | 0.6s | 2.8m | 100 |
| Silver Sword | 3 | 25–30 | 0.6s | 2.8m | 200 |
| Gold Sword | 4 | 35–42 | 0.6s | 2.8m | 400 |

### Bows (2H)

| Weapon | Tier | Damage | Speed | Range | Value |
|---|---|---|---|---|---|
| Shortbow | 1 | 8–12 | 0.35s | 12m | 40 |
| Longbow | 2 | 12–16 | 0.35s | 14m | 80 |
| Recurve Bow | 3 | 16–20 | 0.35s | 14m | 160 |
| Rune Bow | 4 | 22–28 | 0.35s | 16m | 320 |

### Staves (2H)

| Weapon | Tier | Damage | Speed | Range | Value |
|---|---|---|---|---|---|
| Wood Staff | 1 | 8–12 | 0.4s | 14m | 40 |
| Iron Staff | 2 | 12–16 | 0.4s | 14m | 80 |
| Crystal Staff | 3 | 16–20 | 0.4s | 14m | 160 |
| Rune Staff | 4 | 22–28 | 0.4s | 14m | 320 |

### Daggers (1H)

| Weapon | Tier | Damage | Speed | Range | Value |
|---|---|---|---|---|---|
| Iron Dagger | 1 | 14–18 | 0.45s | 2.5m | 45 |
| Silver Dagger | 2 | 20–25 | 0.45s | 2.5m | 90 |
| Shadow Dagger | 3 | 28–32 | 0.45s | 2.5m | 180 |
| Void Dagger | 4 | 36–42 | 0.45s | 2.5m | 360 |

### Tier chain by weapon family (App D cross-reference)
Every weapon type follows the same 4-tier naming convention: Copper/Shortbow/Wood/Iron(dagger) → Iron/Longbow/Iron/Silver → Silver/Recurve/Crystal/Shadow → Gold/Rune/Rune/Void. Materials scale with the ore/wood/crystal tier system in `Materials_and_Resources.md`.

## Designer Notes
Weapon speed and range are **fixed per family**, not per tier — a Copper Sword and a Gold Sword swing at the identical 0.6s cadence and 2.8m range. Only damage and value scale with tier. This means gear progression is purely a damage-magnitude curve, not a playstyle change within a weapon family — playstyle changes come from switching weapon type (Sword vs. Dagger vs. Bow vs. Staff), which is a champion-kit-level choice, not a raw stat choice.

## Appendix
Full source: `Part07_Items_and_Equipment.md`, GDD Chapter 66.

---
*Traceability: GDD Ch. 66 · Milestone M3 · Owner Discipline: Design/Engineering/Art · Status: Not Started.*

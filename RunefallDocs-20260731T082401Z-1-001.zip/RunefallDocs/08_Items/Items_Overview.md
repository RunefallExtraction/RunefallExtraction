---
Document: Items_Overview.md
Section: 08_Items
---

# Items & Equipment — System Overview

## Document Metadata
- **Purpose:** The equipment slot system, weight/quality model, and how it connects to encumbrance and gear progression.
- **Audience:** Design, Engineering.
- **Scope:** GDD Ch. 64 (equipment slots).
- **Dependencies:** `03_Gameplay/Combat/Combat_Data.md` (Encumbrance formula, Ch. 35).
- **Related Documents:** `Armor_Catalog.md`, `Weapon_Catalog.md`, `Trinkets_and_Consumables.md`, `Materials_and_Resources.md`.
- **GDD Chapters Covered:** Ch. 64.
- **Current Implementation Status:** **Placeholder only.** A minimal 3-field `ItemDef` (Id/DisplayName/Value) exists for the Extraction Vertical Slice (ADR-0018); the real gear model (slots, weights, quality tiers) below is entirely Not Started — this is Milestone M3, explicitly scheduled ahead of Gathering/Crafting/Economy because they all depend on it.

## Overview
Ten equipment slots, each with a weight range that feeds directly into the Encumbrance formula (`03_Gameplay/Combat/Combat_Data.md`).

## Detailed Explanation

### Slot overview

| Slot | Items | Slots |
|---|---|---|
| Head | Helmet, Hood, Mask | 1 |
| Chest | Chestpiece, Robe, Vest | 1 |
| Legs | Leggings, Pants, Skirt | 1 |
| Feet | Boots, Shoes | 1 |
| Gloves | Gauntlets, Gloves | 1 |
| Weapon | Sword, Bow, Staff, Daggers | 1 |
| Off-Hand | Shield, Dagger | 1 |
| Relic | Relic Item | 1 |
| Trinket | Ring, Amulet | 2 |
| Consumable | Potions, Food | 4 |

### Equipment weights

| Slot | Weight range | Examples |
|---|---|---|
| Head | 1–4 kg | Helmet (3kg), Hood (1kg) |
| Chest | 3–15 kg | Plate (15kg), Robe (3kg) |
| Legs | 2–10 kg | Plate Legs (10kg), Pants (2kg) |
| Feet | 1–4 kg | Boots (3kg), Shoes (1kg) |
| Gloves | 0.5–2 kg | Gauntlets (2kg), Gloves (0.5kg) |
| Weapon | 1–5 kg | Sword (2kg), Bow (3kg) |
| Off-Hand | 1–8 kg | Shield (8kg), Dagger (1kg) |

These weights sum into Carry Weight, which drives the Encumbrance penalty (`03_Gameplay/Combat/Combat_Data.md`, Ch. 35): 0–20kg no penalty, up to −50% move speed at 100kg+.

## Producer Notes
This is the highest-priority unbuilt system in the reconciled roadmap: `01_Production/Milestone_Index.md` pulls M3 (Items) ahead of Gathering/Crafting (M6), Loot/Economy (M7), and their content, specifically because loot drops, crafting outputs, and market listings are all currently built on the placeholder `ItemDef` and will need rework once the real model lands.

## Appendix
Full source: `Part07_Items_and_Equipment.md`, GDD Chapter 64.

---
*Traceability: GDD Ch. 64 · Milestone M3 · Owner Discipline: Design/Engineering · Status: Placeholder only.*

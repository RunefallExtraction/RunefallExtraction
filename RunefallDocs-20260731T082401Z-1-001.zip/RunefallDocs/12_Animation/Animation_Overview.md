---
Document: Animation_Overview.md
Section: 12_Animation
---

# Animation Direction

## Document Metadata
- **Purpose:** Animation categories and principles governing champions, mobs, and environment.
- **Audience:** Animation, Engineering, Design.
- **Scope:** GDD Ch. 159; App O (Animation State Machines).
- **Dependencies:** `04_Characters` (per-champion animation lists embedded in each kit).
- **Related Documents:** `02_Technical/Architecture_Decision_Log_Index.md` (ADR-0012 — the ability phase FSM that animation states hang off).
- **GDD Chapters Covered:** Ch. 159, App O.
- **Current Implementation Status:** **Not Started.** No animation rigs or clips beyond greybox capsule placeholders.

## Overview
Three animation categories, three principles — responsiveness and readability over naturalism, in keeping with the low poly keyframe style.

## Detailed Explanation

### Animation categories (Ch. 159.1)
- **Champion** — movement, abilities, death.
- **Mob** — idle, patrol, attack, death.
- **Environment** — water, trees, fire.

### Animation principles (Ch. 159.2)
- **Readability** — clear ability tells (animation is a third channel of the same telegraph-honesty principle as VFX and audio — the windup pose itself should read before the telegraph decal even appears).
- **Responsive** — fast, snappy animations.
- **Style** — low poly keyframe style (not motion-captured naturalism).

### Animation state machines (App O)
The GDD's Appendix O defines the generic champion animation state graph: `Idle ↔ Walk ↔ Sprint ↔ Ability`, with Ability reachable from any locomotion state and returning to Idle/Walk on completion. This generic graph is the animation-layer counterpart to `AbilitySystem`'s phase FSM (`02_Technical/Architecture_Decision_Log_Index.md` ADR-0012) — Windup/Active/Recovery phase events are the intended trigger source for the Ability animation state, once an Animator is actually wired to them.

## Producer Notes
Because the ability phase FSM already publishes `AbilityPhaseEvent`s that the telegraph system consumes (ADR-0013), an Animator-driven implementation of this state machine is expected to be a third consumer of the same event stream — not a new authority source. This is a concrete, low-risk integration point once character rigs exist.

## Appendix
Full source: `Part15_Art_and_Audio.md` Ch. 159; `Part17_Appendices.md` App O.

---
*Traceability: GDD Ch. 159, App O · Milestone M13 (+ per-champion, per-mob throughout) · Owner Discipline: Animation/Engineering · Status: Not Started.*

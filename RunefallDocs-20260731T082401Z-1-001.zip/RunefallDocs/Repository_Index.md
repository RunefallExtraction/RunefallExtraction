# Runefall: Extraction — Documentation Repository Index

**This is the master file.** Every document in this repository must appear here. Status is updated at the end of every generation pass — never mark something complete that has not actually been written.

**Status legend:** ✅ Complete · 🟡 In Progress · ⬜ Not Started

**Priority order for source-of-truth conflicts (never contradict a higher source):** 1. GDD → 2. Current Implementation → 3. ADRs → 4. Production Plan → 5. Production Checklists → 6. Production Coverage Report → 7. Everything else.

**How to read this index:** each row is a planned document. "Source" names the primary upload(s)/GDD chapters it must be built from. A row with no file yet is the plan for a future pass, not a promise of content — see `CHANGELOG.md` for what has actually been generated and when.

**Location:** this repository is mirrored to Google Drive under `RunefallDocs/` (https://drive.google.com/drive/folders/1MYiAa7h7lXChy-njtGNzNaBz9n8DTK-5). **Tooling constraint:** the connected Drive tools can create files but cannot update or delete them in place — see `CHANGELOG.md` Pass 2 for what this means for living documents like this index.

---

## 00_Executive

| Document | Status | Source |
|---|---|---|
| `Executive_Overview.md` | ✅ Complete | GDD Ch. 1–2 |
| `Design_Pillars.md` | ✅ Complete | GDD Ch. 2 |
| `Target_Audience_and_Market.md` | ✅ Complete | GDD Ch. 1, 7 |
| `Platform_and_Hardware_Targets.md` | ✅ Complete | GDD Ch. 8 |
| `KPI_Targets.md` | ✅ Complete | GDD Ch. 9, 165 |
| `Risk_Register_Executive_Summary.md` | ✅ Complete | GDD Ch. 10, 166 |
| `Current_Project_Status.md` | ✅ Complete | Project_Status.md |
| `Roadmap_Summary.md` | ✅ Complete | Production_Plan.md |

## 01_Production

| Document | Status | Source |
|---|---|---|
| `Production_Plan_Overview.md` | ✅ Complete | Production_Plan.md |
| `GDD_Coverage_Matrix.md` | ✅ Complete | Production_Plan.md §2 |
| `Milestone_Index.md` | ✅ Complete | Production_Plan.md §4 |
| `Vertical_Slices_Overview.md` | ✅ Complete | VerticalSlice1_Plan.md, Extraction_Slice_Production_Readiness |
| `Production_Governance_and_Operating_Model.md` | ✅ Complete | Production_Plan.md §13–14 |
| `Risk_Register.md` | ✅ Complete | Production_Plan.md §7–8, Risk Register table |
| `Implementation_Dashboard.md` | ✅ Complete | Project_Status.md, Production_Plan.md §14 |
| `Milestone_M0_Foundation.md` | ⬜ Not Started | Production_Plan.md, Milestone1_Engineering_Breakdown.md |
| `Milestone_M1_Combat.md` | ⬜ Not Started | Production_Plan.md, Batch_C_Combat_Plan.md |
| `Milestone_M2_Champions.md` | ⬜ Not Started | Production_Checklists.md |
| `Milestone_M3_Items_Equipment.md` | ⬜ Not Started | Production_Checklists.md |
| `Milestone_M4_World_Map.md` | ⬜ Not Started | Production_Checklists.md |
| `Milestone_M5_Mobs_Bosses.md` | ⬜ Not Started | Production_Checklists.md |
| `Milestone_M6_Gathering_Crafting.md` | ⬜ Not Started | Production_Checklists.md |
| `Milestone_M7_Loot_Economy.md` | ⬜ Not Started | Production_Checklists.md |
| `Milestone_M8_Progression.md` | ⬜ Not Started | Production_Checklists.md |
| `Milestone_M9_Extraction_Storm.md` | ⬜ Not Started | Production_Checklists.md |
| `Milestone_M10_Persistence.md` | ⬜ Not Started | Production_Plan.md |
| `Milestone_M11_Factions_PvP_Social.md` | ⬜ Not Started | Production_Checklists.md |
| `Milestone_M12_Multiplayer_Server.md` | ⬜ Not Started | Production_Checklists.md, TDD-01..05 |
| `Milestone_M13_NPE_UI_Art_Live_Launch.md` | ⬜ Not Started | Production_Checklists.md |
| `Production_Checklists_Index.md` | ⬜ Not Started | Production_Checklists.md |
| `Production_Coverage_Report_Summary.md` | ⬜ Not Started | Production_Coverage_Report.md |
| `Master_Asset_Catalog.md` | ⬜ Not Started | Production_Coverage_Report.md §E |
| `Discrete_Asset_Counts.md` | ⬜ Not Started | Production_Checklists.md |

## 02_Technical

| Document | Status | Source |
|---|---|---|
| `Architecture_Overview.md` | ✅ Complete | TDD-00 |
| `Architecture_Decision_Log_Index.md` | ✅ Complete | Architecture_Decisions.md (ADR-0001..0018) |
| `Architecture_Retrospectives_Index.md` | ✅ Complete | Architecture_Retrospectives.md (R-001..R-006) |
| `Standing_Engineering_Rules.md` | ✅ Complete | Architecture_Retrospectives.md |
| `Architecture_Freeze_Policy.md` | ✅ Complete | Architecture_Retrospectives.md |
| `Assembly_Map.md` | ✅ Complete | TDD-00, ADR-0005/0015/0017, Technical_Debt.md |
| `Coding_Standards.md` | ✅ Complete | CODING_STANDARDS.md |
| `Project_Settings_Reference.md` | ✅ Complete | ProjectSettings_Checklist.md |
| `Technical_Debt_Register.md` | ✅ Complete | Technical_Debt.md |
| `Engine_and_Platform_Decisions.md` | ✅ Complete | ADR-0002, ADR-0004 |
| `Architecture/Composition_Root_and_DI.md` | ⬜ Not Started | TDD-00, ADR-0001 |
| `Architecture/Event_Bus.md` | ⬜ Not Started | TDD-00, ADR-0001 |
| `Architecture/Scene_Flow.md` | ⬜ Not Started | ADR-0007 |
| `Networking_Design/Networking_Overview.md` | ⬜ Not Started | TDD-01 |
| `Networking_Design/Authority_and_Replication.md` | ⬜ Not Started | TDD-01 |
| `Networking_Design/Reconnect_and_Resilience.md` | ⬜ Not Started | TDD-01 Ch. 310 |
| `Data_Model/Definition_Architecture.md` | ⬜ Not Started | ADR-0001, Retrospectives Standing Rule 3 |
| `Data_Model/Database_Schema.md` | ⬜ Not Started | TDD-03 |
| `AI_Framework/AI_Architecture_Overview.md` | ⬜ Not Started | Batch_C4_HollowHusk_AI_Design.md, ADR/Retrospective R-002..R-005 |
| `AI_Framework/AI_Architecture_Evolution.md` | ⬜ Not Started | Retrospectives R-003/R-004/R-005 |
| `Combat_Framework/Combat_Architecture.md` | ⬜ Not Started | ADR-0010..0014, Batch_C_Combat_Plan.md |
| `Combat_Framework/Ability_System.md` | ⬜ Not Started | ADR-0012, ADR-0017 |
| `Combat_Framework/Effect_and_Status_Framework.md` | ⬜ Not Started | ADR-0014, Batch_C3.3_StatusFramework_Design.md |
| `Combat_Framework/Telegraph_System.md` | ⬜ Not Started | ADR-0013, Batch_C3.2_Telegraph_Design.md |
| `Combat_Framework/Locomotion_System.md` | ⬜ Not Started | ADR-0015 |

## 03_Gameplay

| Document | Status | Source |
|---|---|---|
| `Core_Loop_Overview.md` | ✅ Complete | GDD Ch. 3 |
| `Combat/Combat_Overview.md` | ✅ Complete | GDD Ch. 30, 31, 39 |
| `Combat/Combat_Data.md` | ✅ Complete | GDD Ch. 32–38 |
| `Progression/Progression_Overview.md` | ✅ Complete | GDD Ch. 40–49 |
| `Loot_Economy/Loot_Overview.md` | ✅ Complete | GDD Ch. 84–86 |
| `Loot_Economy/Market_and_Economy.md` | ✅ Complete | GDD Ch. 87–93 |
| `Extraction_Storm/Extraction_Overview.md` | ✅ Complete | GDD Ch. 305.1–305.3, 305.5, ADR-0018 |
| `Extraction_Storm/Storm_System.md` | ✅ Complete | GDD Ch. 305.2, 305.4 |

## 04_Characters

| Document | Status | Source |
|---|---|---|
| `Champions_Overview.md` | ✅ Complete | GDD Ch. 21–29 |
| `Vanguard/Vanguard_Design.md` | ✅ Complete | GDD Ch. 22 |
| `Ranger/Ranger_Design.md` | ✅ Complete | GDD Ch. 23 |
| `Riftmage/Riftmage_Design.md` | ✅ Complete | GDD Ch. 24 |
| `Shadow/Shadow_Design.md` | ✅ Complete | GDD Ch. 25 |

## 05_Enemies

| Document | Status | Source |
|---|---|---|
| `Enemies_Overview.md` | ✅ Complete | GDD Ch. 74–79, 83 |

## 06_Bosses

| Document | Status | Source |
|---|---|---|
| `Bosses_Overview.md` | ✅ Complete | GDD Ch. 80–82 |

## 07_World

| Document | Status | Source |
|---|---|---|
| `Ashen_Reach_Overview.md` | ✅ Complete | GDD Ch. 11–14 |
| `Risk_Rings.md` | ✅ Complete | GDD Ch. 12 |
| `Landmarks_Index.md` | ✅ Complete | GDD Ch. 15–20 |

## 08_Items

| Document | Status | Source |
|---|---|---|
| `Items_Overview.md` | ✅ Complete | GDD Ch. 64 |
| `Armor_Catalog.md` | ✅ Complete | GDD Ch. 65 |
| `Weapon_Catalog.md` | ✅ Complete | GDD Ch. 66 |
| `Trinkets_and_Consumables.md` | ✅ Complete | GDD Ch. 67–69 |
| `Materials_and_Resources.md` | ✅ Complete | GDD Ch. 70–71 |

## 09_UI — 10_VFX — 11_Audio — 12_Animation

| Document | Status | Source |
|---|---|---|
| `09_UI/UI_Screen_Catalog.md` | ✅ Complete | GDD Ch. 124–134 |
| `10_VFX/VFX_Overview.md` | ✅ Complete | GDD Ch. 158, App N |
| `11_Audio/Audio_Overview.md` | ✅ Complete | GDD Ch. 157, 312 |
| `12_Animation/Animation_Overview.md` | ✅ Complete | GDD Ch. 159, App O |

## 13_AI

| Document | Status | Source |
|---|---|---|
| `AI_Gameplay_Overview.md` | ✅ Complete | GDD Ch. 74–83, App R |
| `Husk_Grunt_Behaviour.md` | ✅ Complete | Batch_C4 slice docs, Retrospectives R-003/R-004/R-005 |

## 14_Networking

| Document | Status | Source |
|---|---|---|
| `Networking_Design_Summary.md` | ✅ Complete | TDD-01 |
| `Matchmaking_Design.md` | ✅ Complete | TDD-04 |

## 15_Backend — 16_Database

| Document | Status | Source |
|---|---|---|
| `15_Backend/Server_and_Orchestration.md` | ✅ Complete | TDD-02 |
| `16_Database/Schema_Reference.md` | ✅ Complete | TDD-03 |

## 17_Art

| Document | Status | Source |
|---|---|---|
| `Art_Direction_Overview.md` | ✅ Complete | GDD Ch. 151, 152, 160, 162 |
| `Biome_Art_Direction.md` | ✅ Complete | GDD Ch. 153 (pointer to 07_World/Risk_Rings.md) |
| `Performance_Budgets.md` | ✅ Complete | GDD Ch. 156 |

## 18_QA

| Document | Status | Source |
|---|---|---|
| `QA_Strategy_Overview.md` | ✅ Complete | GDD Ch. 303, 304 |
| `Validation_Framework.md` | ✅ Complete | ADR-0016 |

## 19_Release — 20_LiveOps

| Document | Status | Source |
|---|---|---|
| `19_Release/Launch_Checklist.md` | ✅ Complete | GDD Ch. 172, 304 |
| `20_LiveOps/Live_Events_Overview.md` | ✅ Complete | GDD Ch. 104, 105, 107–113 |
| `20_LiveOps/Battle_Pass.md` | ✅ Complete | GDD Ch. 106 |

## 21_Lore

| Document | Status | Source |
|---|---|---|
| `Setting_and_Tone.md` | ✅ Complete | GDD Ch. 4 |
| `NOTE` | — | GDD has no dedicated narrative/lore chapters beyond tone/atmosphere — deeper lore is **NOT DEFINED IN GDD**, stated explicitly in `Setting_and_Tone.md` rather than invented. |

## 22_References

| Document | Status | Source |
|---|---|---|
| `GDD_Chapter_Index.md` | ✅ Complete | Full GDD table of contents, all 19 parts |
| `Appendices_Index.md` | ✅ Complete | GDD App A–R |
| `Glossary.md` | ✅ Complete | cross-cutting |

## 23_Research — 24_Concept_Art — 25_Outsourcing — 26_Pipelines

| Document | Status | Source |
|---|---|---|
| `23_Research/Competitive_Positioning.md` | ✅ Complete | GDD Ch. 7 (pointer to 00_Executive/Target_Audience_and_Market.md) |
| `24_Concept_Art/Concept_Art_Briefs_Index.md` | ✅ Complete | GDD Ch. 151–155 (index; briefs live in owning documents) |
| `25_Outsourcing/Outsourcing_Guidelines.md` | ✅ Complete | NOT YET IMPLEMENTED — stated explicitly rather than invented |
| `26_Pipelines/Art_Production_Pipeline.md` | ✅ Complete | GDD Ch. 151.2, 162, App P |

## 27_Analytics — 28_Monetization — 29_Legal

| Document | Status | Source |
|---|---|---|
| `27_Analytics/Analytics_Taxonomy.md` | ✅ Complete | GDD Ch. 313 |
| `28_Monetization/Monetization_Overview.md` | ✅ Complete | GDD Ch. 114–123 |
| `29_Legal/Compliance_and_Legal.md` | ✅ Complete | GDD Ch. 314 |

---

## Repository-wide master files

| Document | Status |
|---|---|
| `Repository_Index.md` (this file) | ✅ Complete (living document — updated every pass) |
| `CHANGELOG.md` | ✅ Complete (living document — updated every pass) |

---

## Notes on this index

- This index intentionally plans further ahead than any single pass will populate. A row marked ⬜ is a **planned slot**, not a claim that content exists — check `CHANGELOG.md` for what has actually been written and when.
- Rows will be added as generation proceeds and gaps are discovered. Rows are never deleted once a document exists — only their status changes.
- Some folders (21_Lore, 25_Outsourcing, 27_Analytics) have thin or no GDD/implementation source material. Per the project's anti-fabrication rule, those documents state **NOT DEFINED IN GDD** or **NOT YET IMPLEMENTED** rather than invent content.
- GDD chapter references point to the 317-chapter V4.0 Game Bible (19 parts).

**Last updated:** 2026-07-31 (Pass 13 — ALL 30 top-level sections now have complete content. Running total 80 documents. Remaining deeper-detail sub-documents in 01_Production (18 milestone-detail files) and 02_Technical (15 subsystem-deep-dive files) are optional expansion, not required for section coverage — see CHANGELOG Pass 13.)

---
Document: GDD_Coverage_Matrix.md
Section: 01_Production
---

# GDD Coverage Matrix — All 317 Chapters

## Document Metadata
- **Purpose:** Answer "what milestone owns GDD Chapter X, and what's its status?" for any chapter in the 317-chapter Game Bible, with zero orphans.
- **Audience:** Production, every discipline lead, anyone starting work on a new pillar.
- **Scope:** Verbatim reproduction of `Production_Plan.md` §2, the authoritative chapter→milestone mapping.
- **Dependencies:** `Production_Plan_Overview.md`.
- **Related Documents:** `Milestone_Index.md` (per-milestone detail), `22_References/GDD_Chapter_Index.md` (NOT YET WRITTEN — full chapter titles).
- **GDD Chapters Covered:** 1–317 (all).
- **Current Implementation Status:** Status column below reflects the 2026-07-26 snapshot; cross-check against `00_Executive/Current_Project_Status.md` for anything that has moved since (notably Combat/M1 and Mobs/M5, which have progressed further via C3.3/C4 closures).

## Overview
Every one of the GDD's 317 chapters is assigned to **exactly one** milestone. This was not true before 2026-07-26 — the prior A–E roadmap left roughly half the GDD's pillars with no owning milestone at all. This table is the fix, and it is the reference used to answer any "is X planned?" question.

**Status legend:** Done · Partial · Planned · Missing (planned but not started) · Deferred.
**Type legend:** F = Foundation, S = Reusable System, P = Reusable Pipeline, C = Authored Content, X = Cross-cutting.

## Detailed Explanation

### Coverage table

| Chapters | Pillar / Cluster | Type | Status (2026-07-26) | Milestone |
|---|---|---|---|---|
| 1–10 | Vision, pillars, loops, art spec, philosophy, KPIs, risk | F | Done (reference) | M0 |
| 11–20 | World & Map — dimensions, risk rings, topography, hydrology, bridges, roads, landmarks, props, gathering hotspots | S+C | **Missing** (greybox only) | **M4** |
| 21–29 | Champions — 4 champions, selection UI, relic 5th slot, balance, account progression | S+C | **Partial** (Vanguard basic+Q; framework done) | **M1/M2** |
| 30–39 | Combat — overview, telegraph language, damage model, CC, shields/healing, movement/encumbrance, logging, SFX, balance | S | **Partial** (telegraph, damage, CC done; shields/healing, encumbrance missing) | **M1** |
| 40–49 | Progression — attunement/boons, mastery, 15 account skills, collection log, faction rep, seasonal, achievements, data storage | S+C | **Missing** | **M8** |
| 50–63 | Gathering / Refining / Crafting — skinning, 30+ resources, tiers, refining stations, crafting, armor types, gear quality Mk0–V, weapon types, professions, salvage, recipes, durability/repair | S+P+C | **Missing** | **M6** |
| 64–73 | Items & Equipment — slots, armor sets, weapon catalog, trinkets, consumables, ammo/keys, 30+ loot materials, item UI, stacking | S+C | **Partial** (placeholder `ItemDef` only) | **M3** |
| 74–83 | Mobs & AI — beasts, husks, constructs, bandits, rift-touched, mini-bosses (Matron, Grumnir), world boss (Hollow King), spawn zones | S+C | **Partial** (Husk Grunt, Bandit Archer; AI framework done) | **M5** |
| 84–93 | Loot / Economy / Market — drop tables, container tables, economy, market, market UI, insurance, safe box, tuning | S+C | **Partial** (mob drops + drop tables started; stash in-memory) | **M7** |
| 94–103 | Factions / Missions / PvP / Social — factions, missions, PvP, social, chat, friends, kill-cam, comeback, company | S+C | **Missing** | **M11** |
| 104–113 | Live Events — dynamic events, seasonal, battle pass, scheduler, blood moon, world-boss roam, rift surge, bandit convoy, caches | S+C | **Missing** | **M9 (raid events) / M13 (meta)** |
| 114–123 | Monetization — gems, membership, cosmetics, transmog, shops, battle pass, metrics | S+C | **Missing** | **M13** |
| 124–134 | UI & Scenes — HUD, full map, inventory/loadout, stash, crafting UI, results, pre-raid, town lobby, scene list | S+C | **Partial** (menu/HUD/results/loading; rest missing) | spread (each with its owning system) |
| 135–150 | Technical / Network / Matchmaking / DB / Orchestration / Security | F+S | **Missing** (deferred) | **M10 (DB), M12 (net)** |
| 151–162 | Art & Audio — biome/champion/mob art, budgets, audio, VFX, animation, kitbash, UI art, schedule | P+C | **Missing** (greybox placeholders) | **M13 (+ per-pillar polish)** |
| 163–172 | Dev Roadmap / Fun Gates / KPIs / Live-Ops / Support / Tools | F | Reference | governance |
| 173–190 | Appendices A–R — coordinates, MapDef schema, ability cards, item tier chains, unified drop tables, recipes catalog, VFX/anim refs, behavior trees, landmark map | C(ref) | Reference (feeds M3–M6) | per-pillar |
| 191–213 | Phase 0 Foundation — project setup, core framework, input, camera, UI, greybox | F | **Done** | **M0** |
| 214–234 | Phase 1–2 Network & Matchmaking — FishNet, replication, orchestration, auto-scaling | F+S | **Deferred** | **M12** |
| 235–245 | Phase 3 Character & Combat — 4 champions, combat core, telegraph, damage/CC, art pipeline | S+C | **Partial** | **M1/M2** |
| 246–255 | Phase 4 World — map system, terrain/biome, elevation, landmarks, props, rivers, roads, worldgen | S+C | **Missing** | **M4** |
| 256–265 | Phase 5 Mobs & AI — base class, families, bosses, behavior trees, spawning | S+C | **Partial** | **M5** |
| 266–272 | Phase 6 Gathering & Crafting — gathering, nodes, refining, crafting, inventory/item | S+C | **Missing** | **M3/M6** |
| 273–279 | Phase 7 Progression — account skills, mastery, talents/awakenings, collection, faction rep | S+C | **Missing** | **M8** |
| 280–285 | Phase 8 Economy & Market — market, loot tables, insurance/safe box, durability/repair | S+C | **Partial** | **M7** |
| 286–291 | Phase 9 UI & Polish — complete UI, audio, VFX, performance | P+C | **Partial** | **M13** |
| 292–304 | Phase 10–11 Infra Deploy & Launch — Docker/K8s, load balancer, monitoring, anti-cheat, live-ops, QA, launch | F | **Deferred** | **M12/M13** |
| 305 | Extraction & Storm — 40-min raid timer, storm collapse, extraction point states | S | **Partial** (extraction done; storm missing) | **M9** |
| 306 | New Player Experience — FTUE/tutorial | S+C | **Missing** | **M13** |
| 307 | Settings / Options / Accessibility | S | **Missing** | **M13** |
| 308–317 | Localization, voice chat, reconnect, cross-platform accounts, audio middleware (FMOD), analytics taxonomy, legal/cert, controller, team/timeline, consistency rulings | S+X | **Missing/Deferred** | **M12/M13** |

**Coverage: every GDD chapter is assigned to exactly one milestone. No orphans.**

### What changed since this snapshot (per `Current_Project_Status.md`, 2026-07-26 later same day / 2026-07-29)
- **Ch. 30–39 (Combat, M1):** progressed materially past "Partial" — C1 through C3.3 code-complete (unified ability model, telegraph + cast-rooting, unified Effect/Status Framework with stagger + knockback), plus a verified Combat Sandbox (Husks + Bandit Archers).
- **Ch. 74–83 (Mobs & AI, M5):** progressed past "Husk Grunt, Bandit Archer; AI framework done" — the Hollow Husk AI is now built through C4 Slice 3 (`MobSpawner`), closed.
- **Ch. 305 (Extraction & Storm, M9):** the extraction half is now **Production Ready** and permanently closed per `Extraction_Slice_Production_Readiness_2026-07-25.md`; the storm half remains Missing.

This document is not retroactively edited to chase these updates line-by-line — see `Milestone_Index.md` and `00_Executive/Current_Project_Status.md` for the current state; this matrix stays as the dated snapshot it was generated as, per the repository's "document both, don't silently overwrite" rule.

## Appendix
Full source: `Production_Plan.md` §2 (2026-07-26).

---
*Traceability: GDD Ch. 1–317 (complete) · All Milestones M0–M13 · Owner Discipline: Production · Status: Reference document, snapshot-dated.*

---
Document: Risk_Register.md
Section: 01_Production
---

# Production Risk Register

## Document Metadata
- **Purpose:** Track production/schedule/technical risks to the roadmap — distinct from the GDD's *design*-level risk analysis.
- **Audience:** Production, Engineering leads.
- **Scope:** `Production_Plan.md` §8 (Future Backtracking Report), §11 (Risks Before Each Milestone Freeze), and the living Risk Register table in §14.
- **Dependencies:** `Milestone_Index.md`.
- **Related Documents:** `00_Executive/Risk_Register_Executive_Summary.md` (the GDD design-risk equivalent — do not duplicate rows between the two; that document covers economy/P2W/desync/cheating/retention/art-scope/mobile-perf risks from GDD Ch. 10, this one covers roadmap/schedule/dependency risks from production planning).
- **GDD Chapters Covered:** N/A (production-process risk, not design risk).
- **Current Implementation Status:** Living document — update after every milestone/slice per `Production_Governance_and_Operating_Model.md`.

## Overview
This register tracks what could go wrong with the *roadmap itself* — not gameplay risk (see the Executive risk summary for that). Two of six risks are already fully or partially mitigated by the 2026-07-26 reconciliation; the rest are open and watched.

## Detailed Explanation

### Living Risk Register (from `Production_Plan.md` §14, current as of 2026-07-26)

| Risk | Type | Probability | Impact | Mitigation | Status |
|---|---|---|---|---|---|
| SP→server-authoritative retrofit (M12) | Technical/Networking | Medium | High | Server-authoritative seams kept from day 1; budget M12 as the highest-risk milestone | Open (mitigated) |
| Persistence built too late | Technical | Was High | High | M10 pulled before M7/M8 | **Mitigated** |
| Placeholder `ItemDef` → real gear model | Technical | High | Medium | M3 scheduled before loot/craft/economy | Planned |
| Content placed in greybox coordinates | Production | Medium | Medium | M4 (world) scheduled before spatial content (M5/M6) | Planned |
| Art/audio near-zero (≈6–8% overall) | Schedule/Art | High | High | Discipline matrix + FMOD hooked early; per-pillar art passes | **Open** |
| Combat over-investment | Schedule | Low | Low | Stop after Combat Balance; pivot to M3/M4 | Watched |

### Future Backtracking Report (risk if the roadmap had stayed unchanged)
This section records *why* the 2026-07-26 reconciliation happened — the risks that existed under the old A–E roadmap, for institutional memory:

| Severity | Risk | Mitigation adopted |
|---|---|---|
| **HIGH** | Persistence retrofit — building Economy/Progression/Crafting on in-memory state, then adding save/load, forces reworking every store | Schedule M10 before/with M7–M8 |
| **HIGH** | Networking last — the more systems built SP-only, the larger the M12 retrofit | Server-authoritative-by-design kept from the start; consider pulling core replication earlier if multiplayer feel becomes a validation blocker |
| **MEDIUM** | Item model — loot/craft/economy built on placeholder `ItemDef` will churn | M3 before M6/M7 |
| **MEDIUM** | Greybox world — content placed in greybox coordinates must be re-placed in the real map | M4 before heavy content (M5 roster/M6 nodes) |
| **LOW** | Combat over-investment | Acceptable — combat is the moment-to-moment core — but stop after Combat Balance and move to M3/M4/M10 rather than adding more combat content |

### Risks Before Each Milestone Freeze (pre-registered, checked at freeze time)

| Milestone | Freeze risk |
|---|---|
| **M1** | Combat feel is still placeholder-art dependent (audio/VFX) — freeze on *mechanics + readability*, not final art |
| **M3** | Gear-quality math must match GDD Ch. 58 before content is authored on top of it |
| **M4** | Map scale/performance (low-poly budget, Ch. 156) at full landmark count |
| **M10** | Save format must be forward-compatible (schema versioning) to avoid player wipes |
| **M12** | Every single-player system's server-authority assumption gets tested at once — the single highest-risk milestone; budget accordingly |
| **M13** | Monetization must satisfy Ch. 121 fair-monetization rules; compliance obligations per Ch. 314 |

## Producer Notes
Two risks are already resolved by the reconciliation itself and should not be re-litigated without a new measurable trigger, per the Operating Model: Persistence timing (mitigated by pulling M10 early) and Networking placement (mitigated by making it explicit rather than implicitly last).

## Appendix
Full source: `Production_Plan.md` §8, §11, §14 (2026-07-26).

---
*Traceability: N/A (production risk) · Cross-cutting · Owner Discipline: Production · Status: Living, update after every slice.*

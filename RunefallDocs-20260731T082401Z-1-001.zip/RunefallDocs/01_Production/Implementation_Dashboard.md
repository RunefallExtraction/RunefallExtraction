---
Document: Implementation_Dashboard.md
Section: 01_Production
---

# Implementation Dashboard

## Document Metadata
- **Purpose:** The single-page numeric snapshot of where the project actually is, per-discipline, updated after every slice.
- **Audience:** Everyone; the fastest way to answer "what % done are we?"
- **Scope:** `Production_Plan.md` §14 (Implementation Dashboard) reconciled against the more current `Project_Status.md` dashboard.
- **Dependencies:** `Milestone_Index.md`, `Risk_Register.md`.
- **Related Documents:** `00_Executive/Current_Project_Status.md` (the executive-level digest of the same data), `Production_Coverage_Report_Summary.md` (NOT YET WRITTEN — the cross-discipline breakdown this dashboard summarizes).
- **GDD Chapters Covered:** N/A (status tracking).
- **Current Implementation Status:** This document itself is a status report; see body for the two source snapshots it reconciles (2026-07-26 Production Plan dashboard vs. 2026-07-26/29 Project_Status dashboard).

## Overview
Two dashboards exist in the source material with slightly different numbers because they were captured at different points on the same rolling day (2026-07-26) — and `Project_Status.md` has continued to update since. Both are reproduced here, dated, rather than collapsed into one number.

## Detailed Explanation

### Snapshot A — `Production_Plan.md` §14 (2026-07-26, planning-time)

| Metric | Value |
|---|---|
| Overall project | ≈ 6–8% |
| Engineering | ~20% |
| Gameplay | ~15% |
| Content | ~3% |
| Art | ~1% |
| Animation | ~1% |
| Audio | ~1% |
| VFX | ~2% |
| UI | ~12% |
| **Current milestone** | M1 Combat (~60%) |
| **Current vertical slice** | ① Combat |
| **Critical path** | M1 → M3 → M4 → M10 |
| **Gameplay debt** | Placeholder art/audio; no hit-stop/impact-VFX/SFX yet |
| **Technical debt** | In-memory stash; no projectile/AI-commit tests; `QueryInRadius` XZ handled per-caller |
| **Top risk** | Art/audio staffing |

### Snapshot B — `Project_Status.md` (2026-07-26, implementation-time, later same day / most current)

| Metric | Value |
|---|---|
| Overall project | ≈ 12% (design ≈90%, engineering/gameplay ≈12%) |
| **Current milestone** | Vertical Slice 1 — Core Gameplay Loop |
| **Current batch** | Batch C (Combat), C1–C3.3 code-complete |
| **C4 status** | Hollow Husk AI — Slices 0–3 all CLOSED |
| **Separately closed** | Extraction Vertical Slice (Production Ready, 2026-07-25); Combat Sandbox (3 Husks + 3 Bandit Archers, verified) |
| **Codebase shape** | 18 assemblies, zero cycles (down from 27 after culling 9 unused placeholders) |
| **Architecture status** | **Freeze in effect** since 2026-07-25 — further architecture changes are reactive-only |

### Why both are kept
Per the repository's anti-fabrication rule, when two real source documents disagree, both are documented with their dates rather than one being silently treated as authoritative. Snapshot B is the more current and more granular of the two, and should be preferred for "where are we today" questions; Snapshot A is preserved because it's the dashboard the 2026-07-26 roadmap reconciliation was actually planned against, and remains useful for understanding *why* the roadmap is ordered the way it is in `Milestone_Index.md`.

## Producer Notes
This dashboard should be updated (a new dated snapshot added, not the old ones edited) after every slice close, per `Production_Governance_and_Operating_Model.md`.

## Appendix
Full sources: `Production_Plan.md` §14; `Project_Status.md` (dashboard header + system status table).

---
*Traceability: N/A (status) · Current: Vertical Slice 1 / M1 / M5 · Owner Discipline: Production · Status: Living, two dated snapshots reconciled.*

---
Document: Vertical_Slices_Overview.md
Section: 01_Production
---

# Vertical Slices — Overview

## Document Metadata
- **Purpose:** Explain what a "vertical slice" means for Runefall's production process, list the six planned major playable checkpoints, and give the detailed status of the two slices that have actually shipped.
- **Audience:** Production, Engineering, QA.
- **Scope:** `Production_Plan.md` §14 (vertical slice list), `VerticalSlice1_Plan.md` (full plan), `Extraction_Slice_Production_Readiness_2026-07-25.md` (audit + verdict).
- **Dependencies:** `Milestone_Index.md`.
- **Related Documents:** `00_Executive/Current_Project_Status.md`, `02_Technical/Architecture_Retrospectives_Index.md` (NOT YET WRITTEN).
- **GDD Chapters Covered:** Cross-cutting (a vertical slice cuts across milestones by design).
- **Current Implementation Status:** Extraction Vertical Slice — **Production Ready, permanently CLOSED** (2026-07-25). Core Gameplay Loop Vertical Slice (VS1) — **In Progress** (Batch C combat code-complete through C3.3; C4 Hollow Husk AI closed through Slice 3).

## Overview
A vertical slice is a playable checkpoint that cuts across milestones to prove a complete loop end-to-end, rather than a single system in isolation. Runefall's operating model defines six of them.

## Detailed Explanation

### The six planned vertical slices (per `Production_Plan.md` §14)

| # | Slice | Milestones it cuts across |
|---|---|---|
| ① | Combat | M1 |
| ② | Gather→Refine→Craft→Equip | M3 + M6 |
| ③ | Raid | M4 + M9 |
| ④ | Economy | M7 |
| ⑤ | Progression | M8 |
| ⑥ | Multiplayer | M12 |

### Vertical Slice 1 — Core Gameplay Loop (in progress)
**Source:** `VerticalSlice1_Plan.md`, dated 2026-07-20.

**Goal:** the smallest complete, playable Runefall loop on top of the framework — launch → main menu → load raid → spawn as Vanguard → move → fight a Hollow Husk with basic attack + Shield Slam → kill it → loot drops → pick up and equip → reach extraction → channel out → results → banked loot persists → return to menu. Placeholder art only; architecture, networking-readiness, performance, and code quality are production-grade and must not require future rewrites.

**Batch plan (5 batches, ~16–22 engineer-days estimated):**

| Batch | Scope | Exit condition |
|---|---|---|
| **A — Match Scaffolding & Flow** | Scene-flow events + loader, Boot/MainMenu/Loading/Raid_Greybox scenes, `MainMenuPanel`, `MatchController` skeleton + `MatchState` | Menu → load raid scene → return to menu |
| **B — Player, Camera & Input** | `Runefall.Gameplay` assembly, `ChampionDef` (Vanguard), `PlayerSpawner`, `CharacterMotor`+`ICharacterMotor`, `PlayerController`, camera follow, placeholder `HudPanel` | Spawn and move Vanguard with the top-down camera |
| **C — Combat** | `HealthComponent`/`DamageService`/`DamageResolver`, `WeaponDef`/`AbilityDef`, Vanguard Basic Attack + Shield Slam (+ minimal telegraph), `Runefall.Mobs` Husk + `MeleeEnemyAI` + death | Fight and kill the Husk; it dies; you can be killed |
| **D — Loot, Inventory & Equipment** | `ItemDef`/`LootTableDef`, `LootService` drop-on-death + pickup, `Inventory` + `EquipmentSlots`, HUD inventory view | Loot drops, pick up, equip, damage changes |
| **E — Extraction, Match Completion, Save/Load, Tests, Polish, Docs** | `ExtractionZone` + `ChannelBar`, match completion (Extracted/Died) + `ResultsPanel`, `ISaveService`/`JsonSaveService` + `Stash` persistence, full test pass, polish, docs | The entire loop is playable and loot persists |

**Design principle behind the batch order:** each batch leaves the game runnable; dependencies flow forward (flow → avatar → combat → loot → extraction/persistence); the biggest risk (the combat authority seam) sits in the middle, after a recommended compile checkpoint and before loot/extraction depend on it.

**Current status (per `00_Executive/Current_Project_Status.md`):** Batches A and B complete; Batch C combat code-complete through C3.3 (health/damage, basic attack, Shield Slam, telegraphs, unified Effect/Status framework); C4 Hollow Husk AI (part of what Batch C's plan called "Husk + MeleeEnemyAI") has been built out through 4 design slices (Slice 0 Abilities-assembly extraction, Slice 1 `MobDef`/`Faction`, Slice 2 `AiBrain`, Slice 3 `MobSpawner`), all closed. Batches D and E (loot/inventory, extraction/persistence) — **note the Extraction Vertical Slice below has separately delivered the extraction/carry/bank-or-lose portion of Batch E ahead of the rest of Batch D/E.**

### Extraction Vertical Slice — Production Ready, CLOSED
**Source:** `Extraction_Slice_Production_Readiness_2026-07-25.md` (Revision 2 — post-fix audit).

**What it proves:** pickup → carry → extract → bank; pickup → carry → die → lose; leave → lose; consecutive raids; empty-inventory extraction; interrupt/re-enter.

**Audit verdict (Revision 2, 2026-07-25):** **Production Ready.** No Critical or High defects found. Two Medium implementation issues from Revision 1 (a per-frame HUD string allocation during the extraction channel; a results-screen display that relied on event subscription order) were both fully resolved and re-verified:
- `ExtractionZone` now publishes the channel-progress event only when the integer percent changes, reset on stop/complete — verified 0% on first frame, immediate 0% on move/damage reset, exactly 100% before match end, restart at 0% on re-entry, **zero per-frame GC**.
- `RaidResultsPanel.OnStashChanged` refreshes correctly regardless of event subscription order; no stale values.

**Re-verified at close:** 18 assemblies (10 runtime + 8 test), zero cycles, zero dangling references, zero new edges; ownership unchanged; static balance clean.

**Accepted, documented debt (not defects):** server-authoritative loot/extraction still pending (expected — Networking is M12); in-memory stash / no save-load yet (expected — Persistence is M10); placeholder art and HUD string formatting (expected — Art is M13).

**Status:** this slice is **permanently CLOSED — not to be reopened unless a measurable implementation defect surfaces** during future gameplay work (per the project's Architecture Freeze-era governance rule of only reopening closed work for measurable triggers, not preference).

## QA Notes
The Extraction Slice audit is a model for what "Production Ready" verification looks like in this project: correctness, runtime ownership, lifetime, dependency graph, allocations/GC, performance, multiplayer implications, persistence implications, save/load implications, and edge cases were *all* explicitly checked and stated, not assumed. See `18_QA/QA_Strategy_Overview.md` (NOT YET WRITTEN) for the general pattern this should be generalized into.

## Appendix
Full sources: `Production_Plan.md` §14; `VerticalSlice1_Plan.md` (2026-07-20); `Extraction_Slice_Production_Readiness_2026-07-25.md` (Revision 2, 2026-07-25).

---
*Traceability: Cross-milestone · Vertical Slices ①(Combat/M1) and the standalone Extraction Slice · Owner Discipline: Production/Engineering/QA · Status: VS1 In Progress; Extraction Slice Production Ready/Closed.*

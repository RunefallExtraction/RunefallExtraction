---
Document: Production_Plan_Overview.md
Section: 01_Production
---

# Production Plan — Overview

## Document Metadata
- **Purpose:** Explain how and why the production roadmap was reconciled from an implementation-driven A–E plan to a GDD-driven M0–M13 plan, and state the operating rules that govern it now.
- **Audience:** Production, all discipline leads, new team members needing roadmap context.
- **Scope:** `Production_Plan.md` §1 (executive summary), §9 (MVP scope), §10 (full roadmap sequence). Per-milestone detail is in `Milestone_Index.md`; the full 317-chapter mapping is in `GDD_Coverage_Matrix.md`; governance rules are in `Production_Governance_and_Operating_Model.md`.
- **Dependencies:** `00_Executive/Roadmap_Summary.md`.
- **Related Documents:** `GDD_Coverage_Matrix.md`, `Milestone_Index.md`, `Production_Governance_and_Operating_Model.md`, `Risk_Register.md`, `Implementation_Dashboard.md`.
- **GDD Chapters Covered:** All 317 (index-level).
- **Current Implementation Status:** N/A (planning document). Created 2026-07-26; **Architecture Freeze in effect** at time of writing — this plan is roadmap reconciliation, not an architecture or code change.

## Overview
On 2026-07-26 the project's roadmap was rebuilt from scratch against the actual 317-chapter GDD, after discovering the prior A–E roadmap only scheduled about 1.5 of the GDD's ~14 gameplay pillars.

## Detailed Explanation

### The core finding that triggered this plan
The team had drifted from **GDD-driven** to **implementation-driven** planning. The work already done was excellent and on the critical path, but entire pillars had no milestone at all: the real World/Map, three of four champions, the Items/Equipment system, Gathering→Refining→Crafting, Progression (mastery/skills/collection/factions/achievements), Economy/Market/Insurance, Missions, PvP, Live Events, Monetization, FTUE, Settings/Accessibility/Localization, Art/Audio production, Persistence/Save-load, and the full server stack.

**Two structural risks the old roadmap created:**
1. **Persistence was never scheduled** — the stash was in-memory. Progression, Economy, Crafting, and account systems all require it; building them first would mean rework.
2. **Networking was scheduled last.** The GDD places it at Phase 1. Deferring it single-player-first is the right call (ADR-0005), but it must be scheduled explicitly, with every system keeping the server-authoritative seams it already has.

**The fix:** the reconciled roadmap (M0–M13, see `Milestone_Index.md`) schedules 100% of GDD chapters into exactly one milestone each, ordered by dependency. This is the **only** deliberate, documented deviation from the GDD's own chapter/phase order: **single-player-first, networking deferred** (ADR-0005).

### MVP scope (the smallest *complete* game, not the smallest codebase)

| Scope | Contents |
|---|---|
| **In MVP** | 1 real biome/region (not the full Ashen Reach) · 2 champions with full kits · a mob roster + 1 mini-boss · the full kill→loot→gather→refine→craft→equip→stash loop, single-player · basic Economy/Market · Progression (mastery + a few account skills) · Extraction + Storm · **Persistence** · FTUE · core UI · networked co-op raid (small scale) — because Runefall is fundamentally PvPvE, a truly honest MVP needs at least small-scale multiplayer + extraction PvP |
| **Post-MVP** | Full map, all 4 champions, full mob/boss roster, full crafting professions, factions/missions, live events, monetization |
| **Future** | Seasonal content, battle pass, cross-platform, controller, localization breadth |
| **Experimental** | Psychological-pressure elite design, predictive AI aiming, advanced market dynamics |

**Intermediate target before MVP:** a single-player vertical slice of the full loop (systems M1–M10 minus networking) — proves every system before the M12 retrofit. This is what `VerticalSlice1_Plan.md` and the Extraction Vertical Slice implement — see `Vertical_Slices_Overview.md`.

### Full production roadmap sequence (today → release)
```
M1 Combat (finish) → M3 Items → M4 World → M10 Persistence → M5 Mobs/Bosses
  → M6 Gather/Craft → M7 Loot/Economy → M8 Progression → M9 Storm/Raid-flow
  → [SP VERTICAL SLICE COMPLETE]
  → M12 Networking/Matchmaking → M11 Factions/Missions/PvP
  → M13 NPE/UI/Art/Audio/Monetization/Launch
```
Each milestone ends with: Gameplay Validation · Technical Validation · Playability Validation · GDD Coverage Check · Milestone Freeze (see `Production_Governance_and_Operating_Model.md` for the full gate list).

## Producer Notes
This document is deliberately an *overview*. Do not add per-milestone detail here — that belongs in `Milestone_Index.md`, which this document links to, per the repository's no-duplication rule.

## Appendix
Full source: `Production_Plan.md` §1, §9, §10 (2026-07-26).

---
*Traceability: GDD Ch. 1–317 (index-level) · All Milestones · Owner Discipline: Production · Status: Living planning document (Operating Model locked 2026-07-26 — see `Production_Governance_and_Operating_Model.md`).*

---
Document: Milestone_Index.md
Section: 01_Production
---

# Milestone Index (M0–M13)

## Document Metadata
- **Purpose:** The authoritative, per-milestone breakdown of the reconciled roadmap — what each milestone contains, why it's ordered where it is, and what depends on what.
- **Audience:** Production, all discipline leads.
- **Scope:** `Production_Plan.md` §3 (dependency graph), §4 (milestone table), §5–7 (missing systems/content/hidden dependency reports).
- **Dependencies:** `Production_Plan_Overview.md`, `GDD_Coverage_Matrix.md`.
- **Related Documents:** `Production_Checklists_Index.md` (NOT YET WRITTEN — the per-asset tactical layer under each milestone), `Risk_Register.md`.
- **GDD Chapters Covered:** All (index of milestone ownership; see `GDD_Coverage_Matrix.md` for the chapter-level table).
- **Current Implementation Status:** Snapshot 2026-07-26; individual milestone % figures should be read alongside `00_Executive/Current_Project_Status.md` for anything more recent.

## Overview
Fourteen milestones (M0–M13), each owning a disjoint set of GDD chapters, ordered so that no milestone is built on top of a system that doesn't exist yet.

## Detailed Explanation

### Dependency graph

```mermaid
flowchart TD
    F["Foundation<br/>DI / Events / Input / Camera / UI<br/>(M0 — Done)"] --> Combat["Combat System<br/>telegraph, damage, CC, ability delivery<br/>(M1)"]
    Combat --> Champions["Champions ×4 kits<br/>(M2)"]
    Combat --> World["World / Map<br/>(M4)"]
    World --> MobPlacement["Mob & Boss placement<br/>Spawn zones / raid events<br/>(M5)"]
    Champions --> Items["Items & Equipment<br/>gear model<br/>(M3)"]
    World --> Items
    Items --> Gathering["Gathering<br/>(M6)"]
    Gathering --> Refining["Refining<br/>(M6)"]
    Refining --> Crafting["Crafting<br/>(M6)"]
    Crafting --> Equipment["Equipment<br/>(M3/M6)"]
    Items --> LootTables["Loot tables<br/>(M7)"]
    LootTables --> Economy["Economy / Market<br/>(M7)"]
    Equipment --> Economy
    Persistence["Persistence<br/>(M10 — pulled early)"] --> Economy
    LootTables --> Extraction["Extraction + Storm<br/>raid loop (M9)"]
    Extraction --> Progression["Progression<br/>mastery / skills / collection<br/>(M8)"]
    Persistence --> Progression
    Economy --> Progression
    Progression --> Factions["Factions / Missions / PvP<br/>(M11)"]
    Factions --> Networking["Networking / Matchmaking /<br/>Server authority (M12)<br/>retrofits ALL of the above"]
    Networking --> Launch["Monetization / Live-Ops /<br/>NPE / Launch (M13)"]
```

**Critical dependency truths:**
- **Persistence underpins** Progression, Economy, Crafting, account state — build it before/with them.
- **World underpins** all spatial content (mob placement, gathering nodes, landmarks, extraction points).
- **Items/Equipment underpins** Loot, Crafting output, Economy value, and gear progression.
- **Networking retrofits everything** — kept behind server-authoritative seams so far; the retrofit is matchmaking/replication/persistence-sync, not gameplay rewrites.

### Milestone table

| Milestone | Pillar | GDD chapters | Kind | Notes |
|---|---|---|---|---|
| **M0** | Foundation | 191–213 | Foundation | **Done** |
| **M1** | Combat Foundation | 30–39, 241–243, 305 (extract) | System | ~55% at snapshot — finish shields/healing, feel, balance (further along per `Current_Project_Status.md`) |
| **M2** | Champions (×4 kits) | 21–29, 236–245 | Content on ability framework | Vanguard finish + Ranger/Riftmage/Shadow + relic slot |
| **M3** | Items & Equipment system | 57–73, 271 | **System** | Replaces placeholder `ItemDef`; gear quality, durability — **unblocks loot/craft/economy** |
| **M4** | World & Map | 11–20, 246–255 | System+Content | Real Ashen Reach map; everything spatial depends on it |
| **M5** | Mobs, Elites & Bosses | 74–83, 256–265 | Content on mob framework | Full roster + 3 bosses (mostly data now) |
| **M6** | Gathering→Refining→Crafting | 50–63, 266–270, 185 | Systems+Content | The production chain; needs M3 |
| **M7** | Loot, Economy & Market | 84–93, 280–285 | System+Content | Real loot tables, chests, market, insurance; needs M3+M10 |
| **M8** | Progression | 40–49, 273–279 | System+Content | Mastery, 15 skills, collection, faction rep; needs M10 |
| **M9** | Extraction, Storm & Raid Flow | 305, 104–113 (raid subset) | System | Storm timer, extraction states, raid events, pacing |
| **M10** | Persistence & Save/Load | 49, 92, 139 (JSON→DB) | **Cross-cutting** | **Pulled earlier — before M7/M8.** Stash/progression/economy save |
| **M11** | Factions, Missions, Social, PvP | 94–103 | System+Content | Contracts, PvP, social, comeback |
| **M12** | Multiplayer & Server Infra | 135–150, 214–234, 292–304 | Foundation | FishNet, matchmaking, orchestration, DB, anti-cheat, deploy |
| **M13** | NPE, UI, Art/Audio, Monetization, Live-Ops, Launch | 114–134, 151–172, 286–291, 306–317 | Content+Polish | FTUE, full UI, FMOD audio, VFX, cosmetics, settings, QA, launch |

**Ordering rationale:** M3 (items) is pulled ahead of the loot/craft/economy chain that consumes it. M10 (persistence) runs as soon as M7/M8 begin (or just before) — it was the single biggest unscheduled structural gap in the prior roadmap. Networking (M12) stays deferred but explicit. Art/audio polish happens per-pillar *and* in M13.

### Missing Systems Report (systems with no prior milestone before this reconciliation)
Items/Equipment model · Gear-quality (Mk0–V) · Durability/Repair · Gathering · Refining · Crafting · Recipe · Salvage · Market/Economy · Insurance · Progression (attunement, mastery, account skills, collection, faction rep, achievements) · World/Map system · Storm system · Persistence/Save-load · Missions · PvP · Live-event scheduler · Monetization · FTUE · Settings/Accessibility · Localization · Networking/Matchmaking/Orchestration · Anti-cheat.

### Missing Content Report
3 of 4 champion kits · ~18 remaining mobs + 3 bosses · 30+ resource materials · full armor/weapon/trinket/consumable catalogs · recipe catalog (Appendix M) · the Ashen Reach map (regions, landmarks, POIs, biomes) · loot/drop/container tables · missions · cosmetics · tutorial content.

### Hidden Dependency Report
- Loot drops (done) depend on the real Items system (M3) — current placeholder items must be replaced/backed by the gear model.
- Economy, Crafting, Progression all depend on Persistence (M10) — currently in-memory.
- All spatial content (mobs, nodes, extraction points, landmarks) depends on the World (M4) — currently greybox coordinates.
- The storm/extraction timing depends on the map's risk-ring radii (Ch. 305 uses r=690→150) — needs M4.
- The networking retrofit depends on every gameplay system honoring server-authoritative seams (so far respected).

## Producer Notes
This is the *planning* view. For the tactical, per-asset tracking under each milestone (every champion, every mob, every recipe as its own row), see `Production_Checklists_Index.md` (NOT YET WRITTEN this pass).

## Appendix
Full source: `Production_Plan.md` §3–7 (2026-07-26).

---
*Traceability: GDD Ch. 1–317 · Milestones M0–M13 · Owner Discipline: Production · Status: Living (updated per slice, per `Production_Governance_and_Operating_Model.md`).*

---
Document: Production_Governance_and_Operating_Model.md
Section: 01_Production
---

# Production Governance & Operating Model

## Document Metadata
- **Purpose:** State the permanent rules the project runs by: how milestones are gated, what "done" means for an asset, and what triggers a roadmap change.
- **Audience:** Everyone — this is the constitution of the production process.
- **Scope:** `Production_Plan.md` §13 (Governance) and §14 (Operating Model, locked 2026-07-26). Also incorporates the governance additions from `Production_Checklists.md` and `Production_Coverage_Report.md` §F, which extend the same rule set.
- **Dependencies:** `Production_Plan_Overview.md`.
- **Related Documents:** `Milestone_Index.md`, `Risk_Register.md`, `02_Technical/Architecture_Freeze_Policy.md` (NOT YET WRITTEN — the engineering-side equivalent of this document).
- **GDD Chapters Covered:** N/A (process document).
- **Current Implementation Status:** N/A — governance, not a system. **Locked 2026-07-26: PLANNING COMPLETE, execution mode.**

## Overview
As of 2026-07-26, planning is closed. No new planning documents are created — only the three standing ones (`Production_Plan.md`, `Production_Checklists.md`, `Production_Coverage_Report.md`) are improved. The roadmap changes only under four specific triggers.

## Detailed Explanation

### Governance (permanent, GDD Ch. 2 §13)
- The GDD is the single source of truth.
- Every GDD chapter belongs to exactly one milestone (see `GDD_Coverage_Matrix.md` — zero orphans).
- Reusable systems are built before content that depends on them; content is never built before its system.
- Persistence is built before the account systems that depend on it.
- Networking is scheduled explicitly — never silently deferred by default.
- Each production slice states its contribution type: Foundation / System / Content / Balancing / Validation / Polish.
- Each slice updates the coverage matrix.
- Each milestone ends with Playability + GDD-Coverage checks.
- **The Architecture Freeze remains in effect** throughout (see `02_Technical/Architecture_Freeze_Policy.md`, NOT YET WRITTEN).

### Operating Model (locked 2026-07-26 — execution mode)
**No new planning documents.** Improve only the three standing production documents. Documentation supports execution; it is not itself a workstream.

**The roadmap changes ONLY if:**
1. The GDD changes, or
2. A dependency is proven wrong, or
3. A measurable implementation issue forces a reorder, or
4. A critical production risk appears.

Nothing else — not preference, not "it would be cleaner," not momentum — is a valid reason to reorder the roadmap. This mirrors the engineering-side Architecture Freeze rule (reactive-only changes, requiring a measurable trigger).

### GDD chapter traceability
At any time, "what's the status of Chapter X?" is answerable via: `GDD_Coverage_Matrix.md` (§2) → milestone → `Production_Checklists.md` rows (runtime code / ScriptableObjects / prefabs / scenes / UI / animation / VFX / audio / validation / % complete).

### Asset Definition of Done
An asset is complete only when **every** required discipline is done — not just gameplay code. See the per-asset-type templates (Champion, Mob/NPC, Boss, Landmark/Region, Resource Node, UI Screen, VFX/Audio interaction) in `Production_Coverage_Report.md` §C. **No placeholder survives past its owning milestone unless explicitly tagged temporary.**

### Master Asset Database (schema)
`AssetID · Name · Category · Owner Milestone · Dependencies · Gameplay% · Eng% · Art% · Anim% · Audio% · VFX% · UI% · QA% · Stage · Status · GDD chapters · Docs`. This schema is not duplicated in this repository — it lives as the enumerated rows in `Production_Checklists.md` and `Production_Coverage_Report.md` §E, referenced from `01_Production/Master_Asset_Catalog.md` (NOT YET WRITTEN).

### Milestone acceptance gates (ALL must pass to Freeze a milestone)
Gameplay · Technical · Performance · Art · Animation · Audio · VFX · UI · QA · Playability · Production Coverage · GDD Coverage.

### Milestone readiness checklist (checked before opening a milestone)
System readiness · Dependencies · Design · Production · Art · Animation · Audio · VFX · UI readiness; plus a stated Risk and Recommendation. Content-heavy milestones additionally report: Framework Ready · Authoring Ready · Expected Code% vs. Data% · Expected runtime changes.

### Beta / Release exit criteria

| Gate | Requirements |
|---|---|
| **Beta exit** | No blocker bugs · networking stable · save compatibility verified · performance targets met · required Beta content complete · regression passing · gameplay enjoyable · tutorial complete |
| **Release exit** | Everything in Beta exit, plus: final art/animation/audio/VFX · localization · accessibility · optimization · QA · analytics · live-ops · monetization · support tools · certification |

### Per-milestone retrospective format (continuous improvement, not redesign)
What went well · what delayed · what proved reusable · what became more data-driven · what to change next · did implementation reveal a GDD weakness. This is the production-side counterpart to the engineering-side `Architecture_Retrospectives.md` (R-001–R-006) — see `02_Technical/Architecture_Retrospectives_Index.md` (NOT YET WRITTEN).

### Additional governance rules (from `Production_Checklists.md` and `Production_Coverage_Report.md` §F)
- Systems ship **with** their primary content — a system is never "done" while its content is entirely missing.
- A milestone is **never** frozen while any assigned GDD feature is incomplete — no "add remaining content later."
- Prefer finishing one pillar completely over starting another; a gameplay pillar is never postponed purely for implementation momentum.
- Anything outside the GDD is explicitly tagged **MVP / after-MVP / Experimental**.
- Every slice summary reports: GDD coverage, production coverage, gameplay %, technical %, remaining authored assets, remaining balancing, remaining polish, gameplay debt, technical debt, Foundation Health, Future Reuse Confidence, Gameplay Reuse Confidence.

## Producer Notes
This document and `02_Technical/Standing_Engineering_Rules.md` (NOT YET WRITTEN) are companion documents — production governance and engineering governance, locked around the same date (2026-07-25/26), enforcing the same "reactive-only change" philosophy from two different disciplines.

## Appendix
Full sources: `Production_Plan.md` §13–14; `Production_Checklists.md` (Governance note, added 2026-07-26); `Production_Coverage_Report.md` §F.

---
*Traceability: N/A (process) · Cross-cutting, all milestones · Owner Discipline: Production · Status: Locked 2026-07-26 (execution mode).*

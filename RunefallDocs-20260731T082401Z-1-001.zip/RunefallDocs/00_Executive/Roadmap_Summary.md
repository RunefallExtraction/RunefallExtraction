---
Document: Roadmap_Summary.md
Section: 00_Executive
---

# Roadmap Summary (M0–M13)

## Document Metadata
- **Purpose:** One-page view of the full production roadmap — all 14 milestones, what each covers, and current completion.
- **Audience:** Everyone; the entry point before reading the full `01_Production/Milestone_Index.md`.
- **Scope:** GDD coverage matrix and milestone list per `Production_Plan.md`. Per-milestone detail (deliverables, checklists, freeze criteria) lives in `01_Production`.
- **Dependencies:** `Executive_Overview.md`, `Current_Project_Status.md`.
- **Related Documents:** `01_Production/Milestone_Index.md` (NOT YET WRITTEN — full detail), `01_Production/GDD_Coverage_Matrix.md` (NOT YET WRITTEN — full 317-chapter mapping).
- **GDD Chapters Covered:** All 317 (this document is the top-level index of chapter→milestone assignment).
- **Current Implementation Status:** See per-milestone % below; source-dated 2026-07-26.

## Overview
The roadmap was reconciled on 2026-07-26 from an earlier, narrower A–E plan (which only scheduled ~1.5 of ~14 GDD pillars) into **M0–M13**, which schedules **100% of the GDD's 317 chapters** into exactly one milestone each, ordered by dependency. The one deliberate, documented deviation from the GDD's own chapter order is **single-player-first, networking deferred** (ADR-0005) — every system is still built with server-authoritative seams so the M12 networking retrofit does not require gameplay rewrites.

## Detailed Explanation

### Milestone list

| Milestone | Covers | GDD Ch. | Status |
|---|---|---|---|
| M0 | Foundation & framework (composition root, DI, event bus, input, camera, UI shell) | 1–10, 191–213 | ✅ Done |
| M1 | Combat (system + Vanguard content) | 30–39 | ◐ ~55% (Production_Checklists) / further along per `Current_Project_Status.md` (C3.3 code-complete) |
| M2 | Champions (4 individual production tracks) | 21–29 | ◐ ~15% |
| M3 | Items & Equipment (system + full catalog) | 64–73 | ◐ ~5% |
| M4 | World & Map: Ashen Reach (by ring) | 11–20 | ◐ ~2% (greybox only) |
| M5 | Enemies (by faction) + Bosses | 74–83 | ◐ ~10% |
| M6 | Gathering → Refining → Crafting (pipelines + content) | 50–63 | ○ 0% |
| M7 | Loot, Economy & Market | 84–93 | ◐ ~15% |
| M8 | Progression | 40–49 | ○ 0% |
| M9 | Extraction, Storm & Raid Flow | 104–113, 305 | ◐ ~40% |
| M10 | Persistence & Save/Load (cross-cutting) — **pulled early** | 49, 92, 139 | ○ 0% |
| M11 | Factions, Missions, Social, PvP | 94–103 | ○ 0% |
| M12 | Multiplayer & Server Infrastructure | 135–150, 214–234 | ⊘ Deferred (explicit) |
| M13 | NPE, UI, Art/Audio, Monetization, Live-Ops, Launch | 104–134, 151–162, 306–317 | ◐ ~10% |

**Overall project completion ≈ 6–8%** per the 2026-07-26 Production Coverage Report (Engineering ~20%, Design ~15%, Art/Audio/Animation near-zero) — note `Current_Project_Status.md` (also 2026-07-26, but later in the day / more implementation-current) reports **~12%**, reflecting C4 Hollow Husk AI, the Extraction Vertical Slice, and the Combat Sandbox all closing after the Coverage Report was written. Both figures are accurate to their timestamp; neither has been retroactively corrected — see `01_Production/Production_Coverage_Report_Summary.md` (NOT YET WRITTEN) for the full reconciliation.

### Key structural decisions behind the reordering
1. **Persistence (M10) pulled early** — the original roadmap never scheduled it; the stash was in-memory. Progression, Economy, and Crafting all require it, so building them first would mean rework.
2. **Networking (M12) explicitly scheduled, not silently deferred** — the GDD places networking at Phase 1, but the project deliberately builds single-player-first (ADR-0005) while preserving server-authoritative seams throughout, so M12 is a retrofit, not a rewrite.

## Producer Notes
This document is the **executive-level** roadmap only. The full 317-chapter → milestone mapping (no orphans) lives in `01_Production/GDD_Coverage_Matrix.md`, sourced verbatim from `Production_Plan.md` §2.

## Appendix
Full source: `Production_Plan.md` (2026-07-26), `Production_Checklists.md`, `Production_Coverage_Report.md`.

---
*Traceability: GDD Ch. 1–317 (full coverage) · Milestones: M0–M13 · Owner Discipline: Production · Status: See table above.*

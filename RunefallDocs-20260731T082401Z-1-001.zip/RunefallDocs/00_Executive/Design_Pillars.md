---
Document: Design_Pillars.md
Section: 00_Executive
---

# The Five Design Pillars

## Document Metadata
- **Purpose:** State the five non-negotiable design rules every feature, system, and content addition must satisfy.
- **Audience:** Everyone proposing or reviewing a feature — design, engineering, art, production.
- **Scope:** GDD Ch. 2 verbatim structure, reorganized for reference use.
- **Dependencies:** `Executive_Overview.md`.
- **Related Documents:** `Core_Loop_Overview.md` (03_Gameplay, NOT YET WRITTEN), `Production_Governance_and_Operating_Model.md` (01_Production, NOT YET WRITTEN).
- **GDD Chapters Covered:** Ch. 2.
- **Current Implementation Status:** N/A — design law, not a system. (For the *engineering* equivalent — Standing Engineering Rules distilled from build retrospectives — see `02_Technical/Standing_Engineering_Rules.md`, NOT YET WRITTEN.)

## Overview
Every valuable action, every economic transaction, every combat encounter, every progression system, and every monetization decision in Runefall must be checked against these five pillars before it ships. A feature that violates a pillar is a design bug, not a matter of taste.

## Detailed Explanation

### Pillar 1 — Risk is the Content
**Design Rule:** *If an action has high reward, it must have high risk. No "safe" farming of endgame content.*

| Design Element | Implementation |
|---|---|
| Rich Resource Nodes | Located in dangerous areas, contested by players and mobs |
| Bosses | Require team coordination and attract third-parties |
| Locked Vaults | Have long, loud opening channels (5+ seconds) |
| Extraction Points | Visible and contestable by all players |

### Pillar 2 — Everything is Player-Made and Player-Lost
**Design Rule:** *Players must feel their choices matter. Using a Mk III weapon in a raid is a calculated risk, not a given.*

| Element | Description |
|---|---|
| Faucets | Mobs, bosses, crates, gathering nodes, mission rewards |
| Sinks | Crafting, repair, market tax, insurance, hideout upgrades, consumables |
| Full Loot | All equipped and carried items drop on death |
| Player-Driven Market | Prices determined by supply/demand, not NPC fixed prices |

### Pillar 3 — Readable, Skill-Expressive Combat
**Design Rule:** *A naked player with superior positioning should be able to defeat a poorly-played Mk III player.*

| Element | Description |
|---|---|
| Telegraphs | All dangerous attacks have visible windup indicators (Lines, Cones, Circles, Rings) |
| Fixed Shapes | Never altered by cosmetics |
| Server-Authoritative | Every hit validated server-side |
| Skill Expression | The better player wins, not the one with higher numbers |
| Visual Clarity | Low poly art style ensures clear visual distinction between elements |

*Implementation cross-reference: this pillar is the direct design ancestor of the telegraph-honesty decision in `Batch_C3.2_Telegraph_Design.md` (cast-rooting, Option A) — a dishonest telegraph is a Pillar 3 violation, not a polish gap.*

### Pillar 4 — Progress Every Raid
**Design Rule:** *No raid is a "waste." Even a failed extraction progresses at least one system.*

| Timescale | Duration | Reset? | Description |
|---|---|---|---|
| Per-Raid | 35–40 min | Reset each raid | Attunement + Boons |
| Per-Champion | Lifetime | Never | Mastery → Talents → Awakenings |
| Account-Lifetime | Forever | Never (except seasonal) | 15 Skills, Collection Log, Faction Reputation |

### Pillar 5 — Fair Monetization
**Design Rule:** *The player's wallet should never determine their combat effectiveness.*

| Category | Description |
|---|---|
| Cosmetics Only | Skins, dyes, effects, transmogs |
| No Power | Never sell stats, gear, or advantages |
| Telegraph Integrity | Ability visuals never altered by skins |
| Safe Box | Small protected container (utility, not power) |
| Low Poly Art | Cosmetics are distinct but maintain combat readability |

## Designer Notes
When reviewing a new feature pitch, ask which pillar it serves and which pillar it risks weakening. A feature that serves none of the five is out of scope for Runefall regardless of how fun it might be in isolation.

## QA Notes
Pillar 3 (readability) and Pillar 5 (no power in cosmetics) are both directly testable: a telegraph must be pixel/shape-identical regardless of equipped skin; combat outcomes must be reproducible from public game state (no hidden paid stat).

## Appendix
Full source: `Part01_Vision_and_Pillars.md`, GDD Chapter 2.

---
*Traceability: GDD Ch. 2 · No Milestone (cross-cutting law) · Owner Discipline: Design · Status: N/A.*

---
Document: KPI_Targets.md
Section: 00_Executive
---

# Key Performance Indicator Targets

## Document Metadata
- **Purpose:** Record the GDD's defined success metrics, pre- and post-launch, and the economy health metrics that gate live-ops tuning.
- **Audience:** Production, LiveOps, Engineering (telemetry), Economy design.
- **Scope:** GDD Ch. 9 (KPIs). The engineering/dev-process KPI set (bug counts, test pass rate) is a separate, related table — see GDD Ch. 165, cross-referenced below.
- **Dependencies:** `Executive_Overview.md`.
- **Related Documents:** `01_Production/Risk_Register.md`, `27_Analytics/Analytics_Taxonomy.md` (NOT YET WRITTEN).
- **GDD Chapters Covered:** Ch. 9 (cross-references Ch. 165, the live-ops KPI view of these same targets).
- **Current Implementation Status:** Not Started — no telemetry pipeline exists yet to measure any of these (analytics taxonomy, GDD Ch. 313, is unassigned content — see `Repository_Index.md`).

## Overview
The GDD defines three KPI groups: pre-launch (alpha validation), post-launch (retention/engagement), and economy health. None are currently measurable — there is no shipped build and no telemetry pipeline (`27_Analytics` is empty in this repository and in the project).

## Detailed Explanation

### Pre-Launch Metrics (GDD Ch. 9.1)

| KPI | Target | Measurement |
|---|---|---|
| Player retention (Alpha) | 70% after 10 hours | Unique logins |
| Bug reports per player | < 1 per hour | Internal tracking |
| Server stability | 99.5% uptime | Uptime monitoring |

### Post-Launch Metrics (GDD Ch. 9.2)

| KPI | Target | Measurement |
|---|---|---|
| D1 Retention | >60% | First-day logins |
| D7 Retention | >30% | Week 1 logins |
| D30 Retention | >15% | Month 1 logins |
| DAU/MAU Ratio | >25% | Daily active users |
| Market liquidity | >10,000 listings/day | API metrics |
| Champion pick rate | 15–35% each | Server logs |
| Extracted value/hour | Increasing trend | Leaderboard data |

### Economy Metrics (GDD Ch. 9.3)

| KPI | Target | Measurement |
|---|---|---|
| Sink/Faucet Ratio | 1.0–1.2 | Dashboard telemetry |
| Average repair cost/player | >10% of income | Server logs |
| Insurance usage rate | 20–40% | Server logs |

## Programmer Notes
Note the D1/D7/D30/DAU-MAU targets here (Ch. 9.2) are **identical in value** to the engineering-facing "Player KPIs" table in GDD Ch. 165 (`TDD` set traceability) — the two chapters describe the same targets from two audiences (business/production here, dev-process there), not two different numbers. Do not create conflicting entries when `01_Production` documents Ch. 165.

## Designer Notes / Economy Notes
The Sink/Faucet Ratio target (1.0–1.2, i.e. sinks slightly exceeding faucets) is the primary lever against the #1 listed project risk, "Economy runaway inflation" — see `Risk_Register_Executive_Summary.md`.

## Telemetry
This entire document *is* a telemetry requirements list. No implementation exists yet. Building the pipeline that can measure these values is unassigned in the current milestone breakdown beyond being folded into M13 ("analytics taxonomy") — flagged as a planning gap in `Production_Coverage_Report.md`.

## Appendix
Full source: `Part01_Vision_and_Pillars.md`, GDD Chapter 9. Cross-reference: GDD Chapter 165 (`Runefall_Technical_Reference_Ch136-317.md` context).

---
*Traceability: GDD Ch. 9, 165 · Milestone: M13 (LiveOps/Analytics, per Production_Plan.md) · Owner Discipline: Production/LiveOps/Analytics · Status: Not Started.*

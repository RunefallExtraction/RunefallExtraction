---
Document: Risk_Register_Executive_Summary.md
Section: 00_Executive
---

# Risk Register — Executive Summary

## Document Metadata
- **Purpose:** Surface the project's top design/business risks and their mitigations at a glance, for readers who won't read the full production risk register.
- **Audience:** Everyone; especially Production and leadership.
- **Scope:** GDD Ch. 10 (design-level risk analysis). The production-process risk register (schedule/scope risk) is a related but distinct document — see `01_Production/Risk_Register.md`.
- **Dependencies:** `Executive_Overview.md`, `Design_Pillars.md`.
- **Related Documents:** `01_Production/Risk_Register.md` (NOT YET WRITTEN this pass), `Technical_Debt.md`-derived `02_Technical/Technical_Debt_Register.md` (NOT YET WRITTEN).
- **GDD Chapters Covered:** Ch. 10 (cross-references Ch. 166, the production risk register view of the same risks).
- **Current Implementation Status:** N/A — this is a risk log, not a system.

## Overview
The GDD identifies eight major risks spanning economy design, perception, netcode, security, retention, art scope, and mobile performance. Each has an assigned likelihood, impact, and mitigation strategy.

## Detailed Explanation

### Major Risks (GDD Ch. 10.1)

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Economy runaway inflation | Medium | High | Dashboard sinks, live tuning |
| P2W perception | High | High | Never sell power, transparent policy |
| Server desync | Medium | High | Server-authoritative, reconciliation |
| Cheating | High | Critical | EAC, encrypted memory, manual review |
| Low player retention | Medium | High | Rookie raids, scav runs, feedback loops |
| Art scope creep | Medium | Medium | Kitbash assets, trim-sheets, low poly style |
| Mobile performance | High | Medium | Target 30 FPS, lower LODs, optimize early |
| Touch controls feel bad | Medium | Medium | Mobile-first design, frequent playtesting |

### Mitigation Strategies (GDD Ch. 10.2)

**Economy Runaway:** live-ops dashboard with faucet/sink control; market tax adjustable; repair costs adjustable.

**P2W Perception:** no power sold for real money; clear visual indicators of paid vs. earned items; transparency in monetization.

**Server Desync:** server-authoritative movement validation; client-side reconciliation; ping limits (150 ms cap).

**Cheating:** PC — Easy Anti-Cheat (kernel-level); Mobile — Google Play Integrity / Apple App Attest (this specific mobile mitigation is a **V4.0 ruling**, GDD Ch. 317); encrypted memory; report queue with kill-cam review.

**Retention:** free daily scav runs; Smuggler's Tunnel comeback extract; gear-score matchmaking bands; continuous content updates.

## Current Implementation Status (cross-check against real progress)
- **Server desync / Cheating mitigations:** designed in `TDD-01_Networking.md` and `TDD-05_Security_and_AntiCheat.md` (server-authoritative model, EAC/attestation plan) but **Not Started** in code — Milestone M12 (Multiplayer & Server Infrastructure) is explicitly deferred (⊘) in `Production_Checklists.md` until the single-player-authoritative vertical slice is proven out first.
- **Economy runaway inflation mitigation:** the live-ops dashboard is GDD-specified (Ch. 168) but Not Started; Milestone M7 (Loot, Economy & Market) is ~15% per `Production_Coverage_Report.md`.
- **Retention mitigations (Rookie Raids/Scav runs):** referenced as an anti-churn cohort in `TDD-04_Matchmaking.md` design; Not Started in code (Milestone M11).
- **Mobile performance risk:** no mobile build has been attempted; Milestone M13.

## Producer Notes
This document intentionally does not restate the *production*-risk register (schedule slippage, scope risk, dependency risk) — that lives in `01_Production/Risk_Register.md` and is sourced from `Production_Plan.md` §7–8, not from the GDD.

## Appendix
Full source: `Part01_Vision_and_Pillars.md`, GDD Chapter 10. Cross-reference: GDD Chapter 166.

---
*Traceability: GDD Ch. 10, 166 · Cross-cutting, all milestones · Owner Discipline: Production/Design/Engineering · Status: Mitigations partially designed (TDD-01/TDD-05), Not Started in code.*

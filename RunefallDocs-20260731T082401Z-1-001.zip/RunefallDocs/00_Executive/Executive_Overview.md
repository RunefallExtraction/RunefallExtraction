---
Document: Executive_Overview.md
Section: 00_Executive
---

# Executive Overview

## Document Metadata
- **Purpose:** Give any new reader — engineer, artist, producer, outsourcing partner — a complete, correct picture of what Runefall: Extraction is, in under five minutes.
- **Audience:** Everyone. This is the entry point to the repository.
- **Scope:** What the game is (pitch, genre, inspirations, audience). Not how it's built (see `02_Technical`) or scheduled (see `01_Production`).
- **Dependencies:** None — this is a root document.
- **Related Documents:** `Design_Pillars.md`, `Target_Audience_and_Market.md`, `Roadmap_Summary.md`, `Current_Project_Status.md`.
- **Related Systems:** All.
- **Related Assets:** N/A.
- **GDD Chapters Covered:** Ch. 1 (Game Overview).
- **Current Implementation Status:** N/A (this document describes the design vision, not a buildable system).

## Overview
**Runefall: Extraction** is a PvPvE extraction RPG. Players drop into a shrinking, corrupted valley called **the Deadzone**, gather rune-magic treasure, fight other players and AI creatures, and must physically extract before the storm closes in. What a player carries out of a raid is banked forever; what they die with is lost to whoever loots their corpse.

**Core Tagline:** *"Risk everything. Extract or die. Progress forever."*

## Detailed Explanation

### The blend
The GDD defines Runefall as a deliberate combination of three proven loops, rendered in a fourth game's art style:

| Borrowed element | Source |
|---|---|
| High-stakes extraction loop | *Escape from Tarkov* |
| Top-down combat and camera | *Albion Online* |
| Permanent progression and economy | *Old School RuneScape* |
| Low poly stylized art direction | *Albion Online*-inspired |

### Genre classification (GDD Ch. 1.4)

| Category | Classification |
|---|---|
| Primary Genre | Extraction RPG |
| Secondary Genre | PvPvE, Action RPG, MMORPG (lite) |
| Sub-Genre | Full-loot survival, economy-driven MMO |
| Art Style | Low Poly Stylized (Albion Online inspired) |

### Broader inspiration map (GDD Ch. 4.4)

| Aspect | Primary Inspiration | Secondary Inspiration |
|---|---|---|
| Core Loop | Escape from Tarkov | Hunt: Showdown |
| Combat Camera | Albion Online | League of Legends |
| Progression | Old School RuneScape | Path of Exile |
| Economy | EVE Online | Albion Online |
| Tone | Dark Souls | The Witcher |
| Art Style | Albion Online | Fortnite (low poly) |

## Programmer Notes
The pitch above is the north star for every architecture decision cross-referenced in `02_Technical`: server-authoritative combat (skill expression must be real, not spoofable), a closed-loop economy (persistence and transactional integrity are first-class, not an afterthought), and full-loot risk (the extraction/death boundary is the single most important state transition in the codebase).

## Designer Notes
See `Design_Pillars.md` for the five non-negotiable design rules this pitch implies. Every new feature proposal should be checked against those pillars before it reaches a production checklist.

## QA Notes
There is no "safe" version of Runefall to test — every system must be validated under the assumption that failure (death, disconnect, server crash) can happen mid-transaction. See `18_QA/QA_Strategy_Overview.md` (NOT YET WRITTEN).

## Future Expansion
NOT DEFINED IN GDD beyond what is captured in `Roadmap_Summary.md` (M0–M13) and the Vertical Slice plans.

## Appendix
Full source: `Part01_Vision_and_Pillars.md`, GDD Chapter 1.

---
*Traceability: GDD Ch. 1 · No Milestone (foundational/all) · No Vertical Slice (foundational) · Owner Discipline: Production/Design · Status: N/A — descriptive document, not a system.*

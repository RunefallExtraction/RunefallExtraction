---
Document: Platform_and_Hardware_Targets.md
Section: 00_Executive
---

# Platform & Hardware Targets

## Document Metadata
- **Purpose:** Define the minimum and recommended hardware Runefall must run on, per platform.
- **Audience:** Engineering, QA, Art (performance budgets), Production (device support matrix).
- **Scope:** GDD Ch. 8 (target platforms & hardware). Performance budgets that stem from these targets live in GDD Ch. 156 / `17_Art/Performance_Budgets.md` (NOT YET WRITTEN).
- **Dependencies:** `Executive_Overview.md`.
- **Related Documents:** `02_Technical/Engine_and_Platform_Decisions.md` (NOT YET WRITTEN — covers the Unity 6.3 engine pin, ADR-0002/0004), `ProjectSettings_Checklist.md`.
- **GDD Chapters Covered:** Ch. 8.
- **Current Implementation Status:** Planned (platform targets are GDD-defined; no build has shipped to any of these device classes yet — see `Current_Project_Status.md`).

## Overview
Runefall targets PC (Windows) as primary, with Android and iOS as supported mobile platforms at a lower performance tier.

## Detailed Explanation

### PC — Minimum Specification

| Component | Specification |
|---|---|
| OS | Windows 10 64-bit |
| CPU | Intel Core i5-4460 / AMD FX-6300 |
| RAM | 8 GB |
| GPU | Nvidia GTX 960 / AMD Radeon R9 280 |
| Storage | 20 GB SSD |
| Network | Broadband internet |

### PC — Recommended Specification

| Component | Specification |
|---|---|
| OS | Windows 11 64-bit |
| CPU | Intel Core i7-8700 / AMD Ryzen 5 3600 |
| RAM | 16 GB |
| GPU | Nvidia GTX 1070 / AMD Radeon RX 5700 |
| Storage | 20 GB NVMe SSD |
| Network | Broadband internet (low latency) |

### Mobile — Minimum Specification

| Aspect | Android | iOS |
|---|---|---|
| OS | Android 8.0 (API 26) | iOS 14.0 |
| Device | Galaxy S8 / Pixel 3 | iPhone 8 / iPad 6th Gen |
| RAM | 4 GB | 3 GB |
| Storage | 2 GB | 2 GB |
| GPU | Adreno 506 / Mali-G72 | Apple A11 Bionic |

## Programmer Notes
**Reconciled fact (not in the original GDD hardware chapter, but load-bearing):** the GDD's engine pin (Ch. 135.1 / 208) is Unity 2022 LTS; the actual project has standardized on **Unity 6.3 (6000.3.6f1)** per the ratified cross-cutting decision (`README.md` in the TDD set, 2026-07-20) and ADR-0002. This document records the GDD's *hardware* targets, which are engine-independent; the engine/build-target decision itself belongs in `02_Technical/Engine_and_Platform_Decisions.md`.

## Technical Artist Notes
Performance budgets (draw calls, triangle counts, texture memory per platform tier) are a *consequence* of these hardware targets and are specified separately in GDD Ch. 156 — see `17_Art/Performance_Budgets.md` (NOT YET WRITTEN).

## Appendix
Full source: `Part01_Vision_and_Pillars.md`, GDD Chapter 8.

---
*Traceability: GDD Ch. 8 · Milestone: cross-cutting (M13 NPE/Platform, per `Production_Checklists.md`) · Owner Discipline: Engineering · Status: Planned.*

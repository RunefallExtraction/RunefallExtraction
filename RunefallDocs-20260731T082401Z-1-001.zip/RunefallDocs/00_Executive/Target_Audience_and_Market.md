---
Document: Target_Audience_and_Market.md
Section: 00_Executive
---

# Target Audience & Competitive Positioning

## Document Metadata
- **Purpose:** Define who Runefall is for, and how it differentiates from its closest competitors.
- **Audience:** Production, Marketing, Design, LiveOps.
- **Scope:** GDD Ch. 1.3 (target audience) and Ch. 7 (key differentiators).
- **Dependencies:** `Executive_Overview.md`.
- **Related Documents:** `23_Research/Competitive_Positioning.md` (NOT YET WRITTEN — will expand Ch. 7 with market research; NOT DEFINED IN GDD beyond the comparison table below).
- **GDD Chapters Covered:** Ch. 1.3, Ch. 7.
- **Current Implementation Status:** N/A.

## Overview
Runefall targets players who already enjoy high-stakes extraction and open-world PvPvE games, and differentiates primarily on **permanence** (OSRS-style progression that never wipes) and **combat readability** (top-down, telegraph-based — not a shooter).

## Detailed Explanation

### Target audience segments (GDD Ch. 1.3)

| Segment | Description |
|---|---|
| Primary | Players aged 18–35 who enjoy high-stakes PvPvE games (Tarkov, Hunt: Showdown, Albion Online) |
| Secondary | RPG players who enjoy deep crafting, economy, and permanent progression |
| Tertiary | Competitive players seeking skill-expressive combat |
| Mobile Players | Seeking a premium extraction experience on mobile |

### Key differentiators vs. competitors (GDD Ch. 7)

| Aspect | Runefall | Competitors |
|---|---|---|
| Progression | OSRS-style permanent | Seasonal wipes (Tarkov) |
| Combat | Top-down telegraph-based | First-person/third-person shooter |
| Economy | Player-driven market, full-loot | Mixed NPC/player economy |
| Accessibility | Rookie raids, scav runs | Steep learning curve |
| Social | Proximity voice, companies | Squad-only communication |
| Art Style | Low poly stylized (Albion) | Realistic or high fantasy |

## Designer Notes
The "Accessibility" differentiator (Rookie Raids, Scav runs) is a direct retention mitigation — see `Risk_Register_Executive_Summary.md`, "Low player retention" risk. It is also the anti-churn cohort mentioned in `TDD-04_Matchmaking.md` (protected matchmaking pools separate from mains).

## Future Expansion / Recommendations
A full competitive market analysis (player counts, pricing benchmarks, feature-by-feature teardown of Tarkov/Hunt: Showdown/Albion Online) is **NOT DEFINED IN GDD** and does not exist in the uploaded project documentation. If produced, it belongs in `23_Research/Competitive_Positioning.md` and must be clearly marked as a **Recommendation** (see repository-wide Recommendation format) rather than folded into this document, since it would not come from the GDD or the implementation.

## Appendix
Full source: `Part01_Vision_and_Pillars.md`, GDD Chapters 1.3 and 7.

---
*Traceability: GDD Ch. 1.3, 7 · No Milestone (foundational) · Owner Discipline: Design/Production · Status: N/A.*

---
Document: Audio_Overview.md
Section: 11_Audio
---

# Audio Design

## Document Metadata
- **Purpose:** Audio categories, sound design principles, and the middleware plan.
- **Audience:** Audio, Engineering.
- **Scope:** GDD Ch. 157; Ch. 312 (audio middleware — referenced, detailed in Part 19 addenda).
- **Dependencies:** `03_Gameplay/Combat/Combat_Data.md` (combat sound tables), `03_Gameplay/Extraction_Storm/Storm_System.md` (storm audio cross-reference).
- **Related Documents:** `04_Characters` (per-champion ability sound briefs).
- **GDD Chapters Covered:** Ch. 157, 312.
- **Current Implementation Status:** **Not Started.** No audio middleware integrated, no SFX/music assets.

## Overview
Four audio categories, four sound design principles — telegraph-first, matching the same readability mandate that governs combat and VFX.

## Detailed Explanation

### Audio categories (Ch. 157.1)
Ambient (environment sounds) · SFX (abilities, combat, interactions) · Music (background) · UI (menu sounds).

### Sound design principles (Ch. 157.2)
- **Telegraph** — sound cues for abilities (the audio half of the telegraph-honesty mandate).
- **Feedback** — sound for player actions.
- **Atmosphere** — immersive ambient sounds.
- **Readability** — clear, distinct sounds.

### Audio middleware (Ch. 312, cross-referenced)
The GDD specifies **FMOD** as the audio middleware. Per `Part19_Completion_Addenda.md`'s voice-chat/communications spec (Ch. 309), storm proximity is designed as a **single global parameter** (distance to storm wall) that drives the rumble layer, wind, and music tension together — one unified signal rather than separate ambient cues, implementing the storm's Ch. 305.4 audio warning.

## Producer Notes
`01_Production/Milestone_Index.md` notes FMOD should be "hooked early" (in M1) even though full audio production completes in M13 — establishing the middleware integration point before hundreds of ability/mob sounds need to plug into it is cheaper than retrofitting it later.

## Appendix
Full source: `Part15_Art_and_Audio.md` Ch. 157; `Part19_Completion_Addenda.md` Ch. 309, 312.

---
*Traceability: GDD Ch. 157, 312 · Milestone M13 (hook point in M1) · Owner Discipline: Audio/Engineering · Status: Not Started.*

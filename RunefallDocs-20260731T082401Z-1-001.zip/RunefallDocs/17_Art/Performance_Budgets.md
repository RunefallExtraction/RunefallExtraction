---
Document: Performance_Budgets.md
Section: 17_Art
---

# Performance Budgets

## Document Metadata
- **Purpose:** The authoritative per-platform performance budget every art asset and effect must respect.
- **Audience:** Art, VFX, Technical Art, Engineering.
- **Scope:** GDD Ch. 156.
- **Dependencies:** `00_Executive/Platform_and_Hardware_Targets.md`, `Art_Direction_Overview.md`.
- **Related Documents:** `02_Technical/Project_Settings_Reference.md` (the engine-settings side of the same budgets — quality tiers configured in Unity), `10_VFX/VFX_Overview.md` (particle emission caps).
- **GDD Chapters Covered:** Ch. 156.
- **Current Implementation Status:** Not Started — no content exists yet to measure against these budgets; the numbers themselves are already reflected in `02_Technical/Project_Settings_Reference.md`'s quality-tier checklist.

## Overview
Four performance tiers, each with a hard cap on triangles, draw calls, texture memory, and a target frame rate.

## Detailed Explanation

### Performance budgets

| Platform | Tris | Draw Calls | Texture Memory | FPS |
|---|---|---|---|---|
| PC (High) | 500,000 | 2,000 | 2GB | 60 |
| PC (Low) | 250,000 | 1,000 | 1GB | 30 |
| Mobile (High) | 200,000 | 500 | 500MB | 30 |
| Mobile (Low) | 100,000 | 250 | 250MB | 20 |

These are the same four tiers `00_Executive/Platform_and_Hardware_Targets.md` defines hardware minimums for — this table is what those hardware minimums must be able to sustain.

## Designer Notes
Every per-asset budget elsewhere in this repository (champion polycount 8,000–12,000 tris, mob polycount 3,000–5,000 tris — `Art_Direction_Overview.md`) is a per-instance slice of this total-scene budget, not an independent number. When authoring content, the relevant question is always "how many of these can be on screen at once within the platform total," not just "is this one asset within its own polycount range."

## Appendix
Full source: `Part15_Art_and_Audio.md`, GDD Chapter 156.

---
*Traceability: GDD Ch. 156 · Milestone M13 (+ validated per-pillar throughout) · Owner Discipline: Art/Engineering · Status: Not Started.*

---
Document: Art_Direction_Overview.md
Section: 17_Art
---

# Art Direction Overview

## Document Metadata
- **Purpose:** The overall art style, production pipeline, and technical specification every asset in the game follows.
- **Audience:** Art, Technical Art, Engineering.
- **Scope:** GDD Ch. 151 (art overview), 152 (low poly style spec), 154 (champion art direction — cross-reference), 155 (mob art direction — cross-reference), 160 (modular kitbash), 161 (UI art — cross-reference), 162 (production schedule).
- **Dependencies:** `07_World/Risk_Rings.md` (biome art), `04_Characters` (per-champion art specs already embedded there), `05_Enemies`/`06_Bosses` (per-mob art specs).
- **Related Documents:** `Biome_Art_Direction.md`, `Performance_Budgets.md`, `26_Pipelines/Art_Production_Pipeline.md` (NOT YET WRITTEN).
- **GDD Chapters Covered:** Ch. 151, 152, 160, 162.
- **Current Implementation Status:** **Not Started.** Everything currently in the game is greybox/placeholder geometry.

## Overview
Low poly stylized art (Albion Online reference), flat-shaded with hard edges and minimal textures, produced through a defined concept→blockout→sculpt→retopo→UV→texture→import pipeline.

## Detailed Explanation

### Art style (Ch. 151.1)
Reference: Albion Online. Colors: high contrast, saturated. Silhouettes: clean, readable.

### Production pipeline (Ch. 151.2)
`Concept (2D sketches) → Blockout (Unity greybox) → High-poly (3D sculpt) → Low-poly (retopology) → UV (unwrap) → Texture (solid colors + minimal detail) → Import (Unity asset)`.

### Low poly style rules (Ch. 152.1)
- **Flat Shading** — no smooth normals.
- **Hard Edges** — all edges are hard.
- **Minimal Textures** — solid colors with vertex colors.
- **Clean Shapes** — simple, readable geometry.
- **Color Blocking** — large color areas.

### Technical specifications (Ch. 152.2)

| Aspect | Specification |
|---|---|
| Polycount (Heroes) | 8,000–12,000 tris |
| Polycount (Mobs) | 3,000–5,000 tris |
| Polycount (Props) | 100–500 tris |
| Texture Resolution | 1024×1024 (heroes), 512×512 (props) |
| Shader | Unity URP Lit with flat shading |

*(Cross-check: `04_Characters/Vanguard/Vanguard_Design.md` specifies 10,000 tris, within this heroes range. `05_Enemies/Enemies_Overview.md` mob polycounts, e.g. Husk Grunt 1,800 tris, sit below this 3,000–5,000 range — flagged for reconciliation once mob art is actually authored, not silently corrected here.)*

### Modular kitbash system (Ch. 160)
Purpose: efficient, consistent asset creation via reusable parts. Categories: Buildings (walls, roofs, doors, windows), Props (crates, barrels, lanterns, fences), Terrain (rocks, trees, grass, water).

### Art production schedule (Ch. 162)

| Phase | Duration | Assets |
|---|---|---|
| Concept | 4 weeks | All concept art |
| Modeling | 8 weeks | All 3D assets |
| Texturing | 4 weeks | All textures |
| Animation | 6 weeks | All animations |
| Integration | 4 weeks | Unity import |

## Producer Notes
This 26-week schedule is a GDD-authored estimate, not a commitment reconciled against the actual production roadmap (`01_Production/Milestone_Index.md`) — art work in practice ships per-pillar alongside each milestone (per the Production Discipline Matrix in `01_Production/Production_Governance_and_Operating_Model.md`), not as one monolithic 26-week block.

## Appendix
Full source: `Part15_Art_and_Audio.md`, GDD Chapters 151, 152, 160, 162.

---
*Traceability: GDD Ch. 151, 152, 160, 162 · Milestone M13 (+ per-pillar throughout) · Owner Discipline: Art/Technical Art · Status: Not Started.*

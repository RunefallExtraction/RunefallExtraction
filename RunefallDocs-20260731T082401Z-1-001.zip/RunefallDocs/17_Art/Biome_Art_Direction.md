---
Document: Biome_Art_Direction.md
Section: 17_Art
---

# Biome Art Direction

## Document Metadata
- **Purpose:** Pointer document — biome art direction (GDD Ch. 153) is already fully documented in `07_World/Risk_Rings.md` under "Biome art specifications," including the full palette/props/design-role table for Outer/Mid/Core. Per the repository's no-duplication rule, this document does not repeat that table.
- **Audience:** Art, Design.
- **Scope:** GDD Ch. 153 — see `07_World/Risk_Rings.md` for the full content.
- **Dependencies:** `07_World/Risk_Rings.md`.
- **Related Documents:** `Art_Direction_Overview.md`.
- **GDD Chapters Covered:** Ch. 153.
- **Current Implementation Status:** Not Started (matches `07_World/Risk_Rings.md`).

## Overview
Biome art direction is a *world* concern before it's an *art discipline* concern in this GDD's own structure — Ch. 153 sits inside Part 15 (Art & Audio) but describes the same three rings defined in Part 02 (World & Map) Ch. 12. This repository files the authoritative table once, in `07_World/Risk_Rings.md`, since that's the document a reader would already be at when the question "what does this ring look like" comes up.

## See Also
`07_World/Risk_Rings.md` — full palette (hex values), prop lists, and design-role notes for the Outer (autumn pine frontier), Mid (ashen farmland), and Core (crystallized wasteland) biomes.

---
*Traceability: GDD Ch. 153 · Milestone M4 (world) / M13 (art pass) · Owner Discipline: Art/Design · Status: Not Started — see `07_World/Risk_Rings.md`.*

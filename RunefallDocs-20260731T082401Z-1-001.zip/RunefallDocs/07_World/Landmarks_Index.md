---
Document: Landmarks_Index.md
Section: 07_World
---

# Landmarks, Rivers, Bridges & Roads

## Document Metadata
- **Purpose:** Every named landmark (location, type, role), plus the hydrology/bridge/road network connecting them.
- **Audience:** Design, Art, Production, Engineering (world/spawn systems).
- **Scope:** GDD Ch. 15 (rivers), 16 (bridges), 17 (roads), 18 (landmarks — index-level; full per-landmark art/sound/gathering/spawn detail lives in the GDD itself and is not reproduced verbatim here), 19 (props/vegetation), 20 (gathering hotspots).
- **Dependencies:** `Ashen_Reach_Overview.md`, `Risk_Rings.md`.
- **Related Documents:** `06_Bosses/Bosses_Overview.md` (Sunken Chapel/Foundry/Shattered Spire are boss arenas), `22_References/GDD_Chapter_Index.md` (NOT YET WRITTEN).
- **GDD Chapters Covered:** Ch. 15, 16, 17, 18, 19, 20.
- **Current Implementation Status:** **Not Started.** Only greybox coordinates exist; no landmark has real buildings, art, or spawns implemented.

## Overview
Twelve landmarks (13 counting both Rune Vault chambers separately) sit across the three rings, connected by a river system, 6 bridges, and the Caravan Road spine.

## Detailed Explanation

### Landmark index

| # | Landmark | Zone | Location (X,Y,Z) | Cell | Type |
|---|---|---|---|---|---|
| 1 | Falcrest (Town A) | Outer-7 | (−375, +55, −416) | E3 | Safe Town |
| 2 | Emberwatch (Town B) | Outer/Mid-1 | (+349, +20, +314) | K11 | Safe Town |
| 3 | Northern Quarry | Mid-12 | (−98, +30, +367) | G12 | Ore Hotspot |
| 4 | Old Sawcamp | Outer-9 | (−463, +45, +82) | D9 | Wood Hotspot |
| 5 | Fisher's Hollow | Outer-8 | (−489, +25, −178) | D6 | Fishing + Bridge |
| 6 | The Sunken Chapel | Mid-3 | (+404, +15, −71) | L8 | Dungeon — Matron of Thorns |
| 7 | The Foundry | Mid-5 | (+322, +20, −300) | K5 | Dungeon — Grumnir |
| 8 | Bandit Palisade | Mid-12 | (+50, +25, +356) | H12 | Bandit Camp |
| 9 | Caravan Road | Mid Spine | (road path) | E3–K11 | Route |
| 10 | The Shattered Spire | Core | (0, −12, 0) | H8 | World Boss / Vault |
| 11a | Rune Vault West | Core-9 | (−125, −5, 0) | G8 | Locked Vault |
| 11b | Rune Vault East | Core-3 | (+125, −5, 0) | I8 | Locked Vault |
| 12 | Smuggler's Tunnel | Mid-6 | (0, +10, −330) | H4 | Solo Extract |

### Landmark detail — Falcrest (representative full example)
Highest town (+55m), on a pine bench above the SW river bend, single switchback road climbing to the main gate, sheer drops on west/south walls. **11 buildings:** Gatehouse (portcullis, guard NPCs) · Refinery Hall (Smelter+Sawmill) · Alchemy & Kitchen · Forge/Workshop (crafting + Anvil repair + Rune enchanting) · Merchant Post (vendor, 55% buyback, market terminal) · Bank/Stash Vault · Mission Board Hall (4 faction trader kiosks) · Champion Hall Shrine · 3× Houses/Stables (flavour). No gathering or enemy spawns inside (safe town); T1 ore+herb cluster just outside north walls; wolves patrol the approach road; 2–3 low-value flavour crates. **Role:** West hub, primary new-player town, start of the West Gathering Loop, paired player-spawn cluster on the ridge NE of it.

**Every other landmark follows this same template** (overview, elevation/terrain, buildings, art spec, cover/chokepoints, gathering, enemy spawns, crates, role, sound design) — the full per-landmark breakdown for Emberwatch, Northern Quarry, Old Sawcamp, Fisher's Hollow, Sunken Chapel, The Foundry, Bandit Palisade, Caravan Road, The Shattered Spire, the two Rune Vaults, and Smuggler's Tunnel lives in `Part02_World_and_Map.md` Ch. 18.3–18.14 and is not reproduced verbatim in this index — this document is the navigational index, not a duplicate of the source.

### Hydrology, bridges & roads (Ch. 15–17)
A river system runs through the map (full course detail in Ch. 15); **6 bridges** cross it at defined chokepoints (Ch. 16); the **Caravan Road** is the primary high-risk traversal spine connecting Falcrest (E3) to Emberwatch (K11) through the Mid ring, doubling as landmark #9 in its own right and the route the Bandit Convoy live event travels (`03_Gameplay` cross-reference, GDD Ch. 111).

### Props, vegetation & gathering hotspots (Ch. 19–20)
Low poly prop and vegetation specification per biome (Ch. 19) and the gathering hotspot placement plan (Ch. 20) — both are asset-catalog-level detail belonging to `26_Pipelines/Art_Production_Pipeline.md` and `03_Gameplay/Loot_Economy` once those are expanded; flagged here as GDD chapters owned by this world index but not yet expanded into their own documents.

## Producer Notes
Every landmark's buildings, gathering nodes, enemy spawns, crates, and extraction points are explicitly called out in `01_Production/Production_Checklists.md`'s M4 checklist as needing all of: build/art, gathering nodes, enemy spawns, crates, extraction, events, and sound — per-landmark, not just once for the whole map.

## Appendix
Full source: `Part02_World_and_Map.md`, GDD Chapters 15–20.

---
*Traceability: GDD Ch. 15–20 · Milestone M4 · Owner Discipline: Design/Art/Engineering · Status: Not Started (greybox coordinates only).*

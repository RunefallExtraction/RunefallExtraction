---
Document: Ashen_Reach_Overview.md
Section: 07_World
---

# Ashen Reach — World Overview

## Document Metadata
- **Purpose:** The map's shape, scale, coordinate system, the three risk rings, and topography.
- **Audience:** Design, Engineering (world/terrain systems), Art, Production.
- **Scope:** GDD Ch. 11 (dimensions/axes/units), 12 (risk rings), 13 (topography/elevation), 14 (coordinate/sector grid).
- **Dependencies:** `00_Executive/Executive_Overview.md`.
- **Related Documents:** `Risk_Rings.md`, `Landmarks_Index.md`, `03_Gameplay/Extraction_Storm/Storm_System.md` (the same r=690→150→0 geometry the storm collapses through).
- **GDD Chapters Covered:** Ch. 11, 12, 13, 14.
- **Current Implementation Status:** **Greybox only** (~2%). Coordinates and cell/sector grid exist as design math; no real terrain, biome art, or elevation model is built.

## Overview
The map — Ashen Reach — is a rounded pentagon approximated as a circle of radius ≈690m for math (≈1.495 km²), divided into three concentric risk rings.

## Detailed Explanation

### Dimensions & coordinate system (Ch. 11)
Playable bounds: X ∈ [−700, +700], Z ∈ [−700, +700]; beyond r=690 is impassable cliff/void. 1 world unit = 1 meter. Current greybox is built at radius 60 units (conversion factor 0.087 = 60/690).

**Axes (Unity convention):** +X East, −X West, +Z North, −Z South, +Y Up. Compass/clock/angle: 12:00=North=0°, 3:00=East=90°, 6:00=South=180°, 9:00=West=270°, measured clockwise from North.

**Origin:** (0, y, 0) is the tip of The Shattered Spire at map center; ground elevation at origin ≈ −12m (the Core bowl sits below the outer plateau). Polar placement: `X = r × sin(θ)`, `Z = r × cos(θ)`, Y read from the elevation model.

### The three risk rings (Ch. 12 — see `Risk_Rings.md` for full detail)
Core (0–150m, T4 loot) → Mid (150–450m, T2–T3) → Outer (450–690m, T1). Full breakdown in the companion document.

### Topography & elevation (Ch. 13)
**Overall valley tilt:** West side = high pine highlands (Falcrest side) — natural high ground, sightlines, sniping. East side = burnt lowlands (Emberwatch side) — faster, flatter approaches. Center = low crater bowl (Core). Design intent: asymmetric topography creates tactical differences — West defensive/sightline-focused, East offensive/speed-focused.

| Zone | Location | Y range | Terrain |
|---|---|---|---|
| West Pine Highlands | Outer, W-NW (r 500–690, θ 250–330°) | +55→+80 | Ridgelines, pine benches, boulder fields |
| North Frontier Shelf | Outer, N (θ 330–030°) | +35→+55 | Rolling mossy hills, farmsteads |
| East Burnt Lowlands | Outer, E-SE (θ 060–150°) | +20→+35 | Flatter ash fields, sparse cover |
| South Cliff Belt | Outer/Mid, S (θ 150–210°) | +30→+45, then sheer | Cliffs + Smuggler's Shelf |
| Mid Rolling Farmland | Mid ring (r 150–450) | +5→+25 | Terraced fields, ruined villages |
| Crater Rim | Mid→Core line (r≈150) | +10→−4 | 15–20m glass cliff ringing the bowl |
| Core Bowl | Core (r 0–150) | −18→−4 | Cracked black glass, floating debris, violet crystal |

**Climbable shelves (Fitness-gated shortcuts):** CS-1 West Ridge Shelf (Fisher's Hollow→Old Sawcamp, Fitness 10) · CS-2 North Quarry Face (Fitness 15) · CS-3 South Cliff Belt above Smuggler's Tunnel (Fitness 20) · CS-4 Crater Ramp E into Core (Fitness 25). Stamina drains during climb (less drain at higher Fitness skill); cannot climb while encumbered (>90kg); falling from a climb is lethal.

**Overlooks (PvP positioning):** Falcrest Overlook (views West Loop), Emberwatch Terrace (views East Approach + Caravan Road), Quarry Rise (views Northern Quarry + North Frontier) — tactical advantage but exposed, no quick escape.

### Coordinate & sector grid (Ch. 14)
**Cartesian cell grid:** 100m × 100m cells, columns A–N (West→East), rows 1–14 (South→North); 196 cells total. Notation `Col+Row` (e.g. H8 = center cell). **Polar sector grid** (design/seeding): 12 clock sectors × 3 rings = 36 zones, named `[Ring]-[Clock]` (e.g. Mid-2). **Y sampling:** spawners place X,Z from tables then raycast down (`Physics.Raycast` from Y=200 downward) to snap to terrain height.

## Producer Notes
The storm's collapse geometry (`03_Gameplay/Extraction_Storm/Storm_System.md`, GDD Ch. 305) uses these exact same radii (r=690→150→0) — any future change to ring boundaries must be reconciled in both places.

## Appendix
Full source: `Part02_World_and_Map.md`, GDD Chapters 11–14.

---
*Traceability: GDD Ch. 11–14 · Milestone M4 · Owner Discipline: Design/Engineering/Art · Status: Greybox only (~2%).*

---
Document: Risk_Rings.md
Section: 07_World
---

# The Three Risk Rings

## Document Metadata
- **Purpose:** Full detail on the Core/Mid/Outer ring system — the spatial expression of Pillar 1 (Risk is the Content).
- **Audience:** Design, Art (biome direction), Engineering.
- **Scope:** GDD Ch. 12.
- **Dependencies:** `Ashen_Reach_Overview.md`.
- **Related Documents:** `17_Art/Biome_Art_Direction.md` (NOT YET WRITTEN — deeper art spec), `03_Gameplay/Extraction_Storm/Storm_System.md`.
- **GDD Chapters Covered:** Ch. 12.
- **Current Implementation Status:** Not Started — design only.

## Overview
Three concentric rings, each with a distinct biome, loot tier, and elevation band, separated by two major chokepoints.

## Detailed Explanation

### Ring definitions

| Ring | Radius band | Width | Biome | Loot Tier | Ground Y band |
|---|---|---|---|---|---|
| Core — Deadzone | 0 → 150m | 300m Ø | Crystallized wasteland, black glass, floating debris | T4 | −18 → −4m |
| Mid — Danger Zone | 150 → 450m | 300m Ø | Ashen farmland, ruined villages, palisades | T2–T3 | −4 → +25m |
| Outer — Spawn Belt | 450 → 690m | 240m Ø | Autumn pine frontier, mist, farmsteads | T1 | +20 → +80m |

### Ring boundaries (in-world)
**Outer → Mid line:** broken palisade, ~10–15m drop, crossed by ledges/ramps/Caravan Road gates. Visual: low poly wooden palisade fading grey→dark brown. Design intent: the first major chokepoint.
**Mid → Core line:** crater rim, a 20m glassy cliff, only a handful of ramps/bridges down into the bowl. Visual: dark obsidian cliffs with violet emissive runes. Design intent: the second major chokepoint — the final barrier to endgame content.

### Biome art specifications

| Ring | Theme | Palette | Props | Design role |
|---|---|---|---|---|
| Outer | Autumn pine frontier | #8B9A6B, #D4A76A, #6B7B5A | Pine/birch trees, mossy boulders, wooden fences, hay bales | Insertion belt; safe-ish farming; Falcrest & Emberwatch towns |
| Mid | Ashen farmland, ruined villages | #8B8B8B, #D4A76A, #A85A3A | Burnt trees, ruined stone walls, wooden palisades, overturned caravans | Most PvP happens here; dungeons, camps, Caravan Road |
| Core | Crystallized wasteland | #2A2A3A, #7A5ADA, #5ADADA | Obsidian shards, floating crystal debris, violet crystal growths, cyan rune-veins | Endgame; world boss, Rune Vaults, Boss-Vault extract |

## Designer Notes
The two chokepoints are deliberate PvP funnels, not incidental terrain — every landmark near a ring boundary (per `Landmarks_Index.md`) is a candidate contested zone by design.

## Appendix
Full source: `Part02_World_and_Map.md`, GDD Chapter 12.

---
*Traceability: GDD Ch. 12 · Milestone M4 · Owner Discipline: Design/Art · Status: Not Started.*

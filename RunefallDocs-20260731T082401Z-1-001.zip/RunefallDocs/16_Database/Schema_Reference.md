---
Document: Schema_Reference.md
Section: 16_Database
---

# Database Schema Reference

## Document Metadata
- **Purpose:** The durable and transient data stores — PostgreSQL relational schema, Redis session/cache, TimescaleDB time-series — and the integrity rules keeping a full-loot economy dupe-proof.
- **Audience:** Engineering.
- **Scope:** `TDD-03_Database_and_Persistence.md` in full.
- **Dependencies:** `15_Backend/Server_and_Orchestration.md`.
- **Related Documents:** `03_Gameplay/Progression/Progression_Overview.md` (Ch. 49 storage), `03_Gameplay/Loot_Economy/Market_and_Economy.md` (Ch. 92 storage) — both reference this same schema rather than duplicating it.
- **GDD Chapters Covered:** Ch. 139, 200–202, 49.
- **Current Implementation Status:** **Schema drafted, not provisioned.** Milestone M10, explicitly pulled ahead of Progression (M8) and Economy (M7) in the reconciled roadmap because both depend on it.

## Overview
Only banked/extracted state is durable — in-raid state lives in server memory until extraction. All economic mutations are ACID transactions with idempotency keys.

## Detailed Explanation

### PostgreSQL 16 — relational (verbatim DDL from the source TDD)
```sql
CREATE TABLE players (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT UNIQUE NOT NULL, email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  last_login TIMESTAMP NOT NULL DEFAULT NOW(),
  total_gold_earned INT DEFAULT 0, total_extractions INT DEFAULT 0,
  total_deaths INT DEFAULT 0, total_kills INT DEFAULT 0,
  leaderboard_score INT DEFAULT 0 );

CREATE TABLE stash (
  player_id UUID PRIMARY KEY REFERENCES players(id) ON DELETE CASCADE,
  items JSONB NOT NULL DEFAULT '[]',
  gold INT NOT NULL DEFAULT 0, gems INT NOT NULL DEFAULT 0,
  updated_at TIMESTAMP NOT NULL DEFAULT NOW() );

CREATE TABLE market_listings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id UUID REFERENCES players(id) ON DELETE CASCADE,
  item_id TEXT NOT NULL, quantity INT NOT NULL, price INT NOT NULL,
  listed_at TIMESTAMP NOT NULL DEFAULT NOW(), sold_at TIMESTAMP,
  status TEXT NOT NULL DEFAULT 'active' );
```

### Additional tables (referenced across the GDD; DDL to finalize in migrations)

| Table | Key columns | Notes |
|---|---|---|
| `skills` | player_id FK, one row/skill or JSONB map of 15 skills | Account progression (`03_Gameplay/Progression`) |
| `mastery` | player_id FK, champion, level, talent_points, talents JSONB | Per-champion mastery |
| `collection_log` | player_id FK, entry_id, obtained_at | Collection log |
| `faction_reputation` | player_id FK, faction, rep, tier | Faction standing |
| `market_transactions` | id, listing_id, buyer_id, price, tax, ts | 5% tax audit trail |
| `insurance_records` | id, player_id, item_id, premium, payout, status | Insurance |

**Design notes:** `stash.items` and `mastery.talents` are JSONB for flexible shapes; a GIN index on `stash.items` if item-level queries emerge; index `market_listings(status, item_id, price)` for market browsing. Money columns are integers (Gold/Gems) — no floats, anywhere.

### Redis 7 — session & cache
Session tokens/presence, matchmaking ephemeral state (`14_Networking/Matchmaking_Design.md`), hot market cache, rate-limit counters. TTLs on all ephemeral keys.

### TimescaleDB — metrics & combat logs
A hypertable of per-event combat rows: timestamp, match_id, attacker_id, attacker_champion, target_id, target_champion, ability, damage, damage_type, cc_type, position, killing_blow, source — exactly the schema referenced in `03_Gameplay/Combat/Combat_Data.md`'s combat logging section. Also stores server/infra metrics (CPU, memory, player count) for the live-ops dashboard.

### Access patterns
**Raid entry:** load `stash` (Redis-cached) → server holds working inventory in memory → on extraction, write extracted items back to `stash` in one transaction with an idempotency key → invalidate cache. **Death:** no stash write of carried items (they drop in-raid); update `players` death/kill counters. **Market list/buy:** transactional move of item + gold between `stash` rows, insert `market_transactions`, apply 5% tax; idempotency key prevents double-sell.

### Integrity rules
Wrap stash/market/insurance mutations in a single SQL transaction with a unique idempotency key per client action, making retries no-ops. Never trust client item state — the server reconciles against `stash`/authoritative in-raid inventory before persisting. Corpse loot is exclusive-access (2-player queue) to prevent double-loot.

## Programmer Notes
Three decisions are explicitly flagged as owed in the source TDD: the migration tool (recommend a dedicated tool independent of Nakama, e.g. Flyway/Liquibase), whether `skills` is normalized (15 rows) or a single JSONB blob (recommend JSONB for read simplicity, revisit for analytics), and data residency per region (GDPR/compliance — see `29_Legal/Compliance_and_Legal.md`).

## Appendix
Full source: `TDD-03_Database_and_Persistence.md`.

---
*Traceability: GDD Ch. 139, 200–202, 49 · Milestone M10 (pulled ahead of M7/M8) · Owner Discipline: Engineering · Status: Schema drafted, not provisioned.*

---
*(Note: this file was regenerated on 2026-08-01 after `16_Database`'s original copy became inaccessible in Drive — content reproduced faithfully from the version authored earlier this session, not re-derived or altered.)*

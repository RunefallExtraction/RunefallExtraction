---
Document: Monetization_Overview.md
Section: 28_Monetization
---

# Monetization Overview

## Document Metadata
- **Purpose:** The complete monetization design — philosophy, every revenue stream, and the metrics that govern it.
- **Audience:** Design, Production, Monetization, Legal.
- **Scope:** GDD Ch. 114 (philosophy), 115 (Gems), 116 (Membership), 117 (Safe Box pricing), 118 (Cosmetics catalog), 119 (Transmog), 120 (The Four Shops), 121 (Fair Monetization Rules), 122 (Battle Pass — cross-ref), 123 (Metrics).
- **Dependencies:** `00_Executive/Design_Pillars.md` (Pillar 5), `29_Legal/Compliance_and_Legal.md` (the legal constraints on this system).
- **Related Documents:** `20_LiveOps/Battle_Pass.md` (the gameplay-side view of Ch. 106/122, same system), `03_Gameplay/Loot_Economy/Market_and_Economy.md` (Safe Box gameplay rules, Ch. 91).
- **GDD Chapters Covered:** Ch. 114–123.
- **Current Implementation Status:** **Not Started.** Design-complete only.

## Overview
Five revenue streams — Gems, Membership, Battle Pass, Cosmetics, Safe Box — all governed by one non-negotiable rule: never sell power.

## Detailed Explanation

### Monetization philosophy (Ch. 114)

| Principle | Description |
|---|---|
| No Power | Never sell stats, gear, or advantages |
| Cosmetics Only | Sell time and cosmetics, never power |
| Telegraph Integrity | Ability visuals never altered by skins |
| Fair Pricing | Reasonable prices, no pay-to-win |
| Transparency | Clear communication about monetization |

**Expected revenue mix:** Gems 30% · Membership 25% · Battle Pass 20% · Cosmetics 15% · Safe Box 10%.

### Gems — hard currency (Ch. 115)

| Gems | Price | Bonus |
|---|---|---|
| 100 | $0.99 | — |
| 500 | $4.99 | +10% |
| 1,000 | $9.99 | +20% |
| 2,500 | $24.99 | +30% |
| 5,000 | $49.99 | +40% |
| 10,000 | $99.99 | +50% |

Used for cosmetics, Battle Pass, and Safe Box.

### Membership — subscription (Ch. 116)
$9.99/month, 30-day duration. Benefits: +20% XP, +10% loot, 50 daily Gems, a monthly exclusive cosmetic item, +10 Battle Pass tier skip, +2 Safe Box slots.

**Note on "+10% loot":** this reads close to a loot-rate advantage — worth explicitly checking against Ch. 121's "No Loot Boost" rule (below) during implementation; the GDD does not itself reconcile the apparent tension between these two chapters, and this document flags it rather than resolving it silently.

### Safe Box pricing (Ch. 117, gameplay rules cross-referenced to Ch. 91 / `03_Gameplay/Loot_Economy/Market_and_Economy.md`)

| Slot config | Cost | Total slots |
|---|---|---|
| 2×2 | 500 Gems (starting size) | 4 |
| 3×3 | 1,000 Gems | 9 |
| 4×4 | 2,000 Gems | 16 |

### Cosmetics catalog (Ch. 118)

| Type | Price range (Gems) |
|---|---|
| Champion Skins | 900–1,500 |
| Weapon Skins | 600–1,200 |
| Armor Skins | 600–1,200 |
| Mounts | 1,200–2,000 |
| Emotes | 200–500 |
| Effects (death effects, trails) | 300–800 |
| Titles | 500–1,000 |

Champion skins listed by name/theme cross-reference `04_Characters` (e.g. Vanguard's Royal Sentinel/Molten Warden/Rift-Touched skins are the same three already documented in `04_Characters/Vanguard/Vanguard_Design.md`).

### Transmog (Ch. 119)
50 Gems per slot; changes the *appearance* of an equipped item to any previously-collected skin for that item — collection (via drop/craft) unlocks the appearance permanently, application costs Gems each time.

### The Four Shops (Ch. 120)

| Shop | Items | Currency | Location |
|---|---|---|---|
| Vendor | Basic items, consumables | Gold | Both towns |
| Market | Player-listed items | Gold | Both towns (the player-driven market, `03_Gameplay/Loot_Economy/Market_and_Economy.md`) |
| Gem Shop | Cosmetics, gems | Gems | Both towns |
| Faction Shop | Faction-specific items | Reputation | Faction HQs — requires Honored tier (`03_Gameplay/Progression/Progression_Overview.md` §45) |

### Fair Monetization Rules (Ch. 121)
No Power · **No Loot Boost** (no pay-to-increase-loot) · No Progression Boost (no pay-to-skip-progression) · Transparency · Limited Cosmetics (cosmetics never affect gameplay). Enforcement: regular monetization audits, community feedback, corrections as needed.

### Battle Pass (Ch. 122)
Same system documented in full in `20_LiveOps/Battle_Pass.md` (GDD Ch. 106) — not duplicated here.

### Monetization metrics (Ch. 123)

| Metric | Target |
|---|---|
| ARPU | $5 |
| ARPPU | $15 |
| Conversion Rate | 10% |
| D1 Retention | 60% |
| D7 Retention | 30% |

*(These retention figures are identical to the D1/D7 targets already in `00_Executive/KPI_Targets.md` — the same underlying metric viewed from the monetization dashboard.)*

## Designer Notes
The one internal tension worth flagging for whoever implements this system: Membership's "+10% loot" (Ch. 116.2) sits awkwardly next to Fair Monetization Rule "No Loot Boost" (Ch. 121.1). Per this repository's rule to document rather than silently resolve GDD inconsistencies, this is noted here for a design decision before implementation — not resolved unilaterally in this document.

## Appendix
Full source: `Part12_Monetization.md`, GDD Chapters 114–123.

---
*Traceability: GDD Ch. 114–123 · Milestone M13 · Owner Discipline: Design/Monetization/Legal · Status: Not Started; one internal GDD inconsistency flagged (Membership loot bonus vs. Fair Monetization Rule).*

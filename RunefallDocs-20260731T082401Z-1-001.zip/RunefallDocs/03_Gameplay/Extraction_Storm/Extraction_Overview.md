---
Document: Extraction_Overview.md
Section: 03_Gameplay/Extraction_Storm
---

# Extraction — Design & Implementation

## Document Metadata
- **Purpose:** The complete extraction specification — GDD Ch. 305's single source of truth for the title mechanic — reconciled against what's actually built (the closed Extraction Vertical Slice).
- **Audience:** Design, Engineering, QA.
- **Scope:** GDD Ch. 305.1–305.3, 305.5 (raid timeline, extraction point types, edge cases); implementation reconciliation from ADR-0018 and the Extraction Slice production-readiness audit.
- **Dependencies:** `Core_Loop_Overview.md`.
- **Related Documents:** `Storm_System.md`, `02_Technical/Architecture_Decision_Log_Index.md` (ADR-0018), `01_Production/Vertical_Slices_Overview.md`.
- **GDD Chapters Covered:** Ch. 305.1, 305.2 (raid timeline — shared with `Storm_System.md`), 305.3, 305.5.
- **Current Implementation Status:** **Partial, and the implemented part is Production Ready.** A generic, single-extraction-point version of the carry→channel→bank-or-lose loop is closed (Extraction Vertical Slice, 2026-07-25). The GDD's full spec below — four extraction *types*, the raid timeline, and most edge cases — is largely **Not Started**.

## Overview
GDD Ch. 305 exists because extraction — the title mechanic — had only ever been specified in fragments across earlier chapters. It is now the single source of truth. The current codebase implements a deliberately minimal *generic* version of one of its four extraction types.

## Detailed Explanation

### Why this chapter exists (Ch. 305.1)
Prior to V4.0, extraction was specified only in fragments: the raid-loop diagram (Ch. 3), Smuggler's Tunnel (Ch. 18.14), the Boss-Vault (Ch. 18.12), and map icons (Ch. 127). Ch. 305 consolidates all of it.

### Raid timeline (Ch. 305.2 — shared with `Storm_System.md`)

| Time | Event |
|---|---|
| 00:00 | Edge spawn (Outer ring, paired spawn clusters, minimum 180m between parties) |
| 00:00–05:00 | Grace window: primary extracts closed, PvP enabled but spawn clusters protected by a 60s no-aggro shield |
| 05:00 | Primary extracts open; rumor icons reveal the raid's active secondary extracts |
| 25:00 | Storm warning horn; storm wall becomes visible at map edge (r = 690) |
| 30:00 | Storm begins collapsing inward at ≈3.7 m/s toward r = 150 (reaches the crater rim at ≈35:00) |
| 35:00 | Storm holds at the crater rim for 3 minutes — the Core becomes the last stage |
| 38:00 | Final collapse to r = 0 over 2 minutes |
| 40:00 | Raid ends; anyone not extracted is killed by the storm (counts as death, full loot drops and is destroyed) |

### Extraction point types (Ch. 305.3)

| Type | Count per raid | Location | Rules |
|---|---|---|---|
| Primary Anchor | 2 (always active) | Outer ring, opposite lobes (rotates by seed among 4 fixed sites) | 8s channel, interruptible by damage, loud horn + light pillar visible map-wide while channeling |
| Secondary Extract | 2–3 of 6 (seeded) | Mid ring | 6s channel; each has a condition (e.g. costs 1 Rune Key; a pair extract requires 2 players channeling together) |
| Smuggler's Tunnel | 1 (always active) | South cliffs | Solo only, 5s channel, no backpack — equipped gear + pockets + Safe Box only |
| Boss-Vault Extract | 0–1 (opens on Hollow King kill) | The Shattered Spire | 10s channel inside the vault — the highest-risk, highest-value exit |

**Design rules:** every extract is visible and contestable (Pillar 1 — Risk is the Content); channels reset fully on interruption; extraction is per-player, not per-party; extracted players leave the simulation immediately and their results commit server-side.

### Edge cases (Ch. 305.5)
- **Disconnection while channeling:** channel cancels; the player body persists per the reconnect window (GDD Ch. 310 / `TDD-01_Networking.md`).
- **Extract inside the storm:** allowed — extracts never close early, but you must survive the channel under storm damage.
- **Party split:** survivors see extracted allies as "OUT — value banked" on the party frame.

### What's actually implemented (reconciliation)
The **Extraction Vertical Slice** (ADR-0018, closed 2026-07-25) implements a single, generic extraction point — not any of the four typed extracts above:
- **One `ExtractionZone`**, 5-second interruptible channel (not the 8s/6s/5s/10s per-type durations above), resets to 0% on movement or damage.
- **No storm** — nothing forces the extraction decision yet; a player can idle at the zone indefinitely.
- **No multiple extract types** — Primary Anchor, Secondary Extract, Smuggler's Tunnel, and Boss-Vault Extract are all GDD-specified but **Not Started**.
- **No per-player vs. per-party distinction test** yet — only single-player has been verified.
- **Carry→bank / die→lose is real and audited:** `RaidInventory` transfers to `Stash` on extraction, clears on death — this is the one piece of Ch. 305 that is genuinely production-ready today.

This is a textbook example of the project's "concrete until a second consumer" engineering rule (`02_Technical/Standing_Engineering_Rules.md` Rule 1) applied to gameplay: build the *one* generic mechanic that proves the loop, defer the GDD's four-type richness until there's a reason (a second real extraction scenario) to generalize.

## Producer Notes
When Milestone M9 (Extraction, Storm & Raid Flow) opens for real, the work is not "build extraction" — extraction's core loop already exists — it's "add the storm, then differentiate the single generic zone into the four typed extracts the GDD specifies."

## QA Notes
Every edge case verified in the Extraction Slice audit (pickup→carry→extract→bank, pickup→carry→die→lose, leave→lose, consecutive raids, empty-inventory extraction, interrupt/re-enter) should be re-verified per extraction *type* once the four types are differentiated — the current tests only cover the generic single-zone case.

## Appendix
Full source: `Part19_Completion_Addenda.md`, GDD Chapter 305.1–305.3, 305.5; `Architecture_Decisions.md` ADR-0018; `Extraction_Slice_Production_Readiness_2026-07-25.md`.

---
*Traceability: GDD Ch. 305 · Milestone M9 · Owner Discipline: Design/Engineering/QA · Status: Generic single-zone loop Production Ready; typed extracts Not Started.*

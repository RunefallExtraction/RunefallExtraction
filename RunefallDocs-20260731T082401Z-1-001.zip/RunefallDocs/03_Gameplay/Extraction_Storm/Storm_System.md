---
Document: Storm_System.md
Section: 03_Gameplay/Extraction_Storm
---

# The Storm System

## Document Metadata
- **Purpose:** The storm mechanic specifically — the "ultimate equalizer" that forces the extraction decision — and its HUD/readability spec.
- **Audience:** Design, Engineering, Art/VFX, Audio.
- **Scope:** GDD Ch. 305.2 (timeline — full table in `Extraction_Overview.md`), 305.4 (HUD & readability).
- **Dependencies:** `Extraction_Overview.md` (shares the raid timeline).
- **Related Documents:** `TDD-02_Server_and_Orchestration.md` (storm is server-owned per the `config.json` `stormTimer`/`stormDuration` fields), `07_World/Risk_Rings.md` (NOT YET WRITTEN — the r=690→150→0 geometry this system collapses through).
- **GDD Chapters Covered:** Ch. 305.2, 305.4.
- **Current Implementation Status:** **Not Started.** The server config already reserves fields for it (`TDD-02`), but no storm logic, damage, or visuals exist in the actual codebase yet.

## Overview
The storm is Runefall's answer to "what forces the Decision Point in the Raid Loop" (`Core_Loop_Overview.md`). It is unmitigable by design — no shield, resist, or ability reduces storm damage — because it exists specifically to end stalling.

## Detailed Explanation

### Storm mechanics (Ch. 305.2)
- **Warning:** horn + visible wall at the map edge (r = 690) at 25:00.
- **Collapse:** begins at 30:00, moving inward at ≈3.7 m/s toward r = 150, reaching the crater rim at ≈35:00.
- **Hold:** the storm holds at the crater rim (r = 150) for 3 minutes (35:00–38:00) — the Core becomes the last playable stage.
- **Final collapse:** to r = 0 over 2 minutes (38:00–40:00).
- **Raid end:** at 40:00, anyone not extracted is killed by the storm — this counts as a death, and full loot drops and is destroyed (not banked to a corpse for others to loot — the storm itself consumes it).

**Damage:** 40 HP/s inside the wall, ramping **+10 HP/s every 30 seconds of continued exposure**. Per GDD Ch. 2, this is the deliberate "ultimate equalizer" — no shield, resistance, or ability mitigates it.

### HUD & readability (Ch. 305.4)
Extraction points render as green icons with state: **closed** (grey) · **open** (green) · **contested** (orange pulse — someone is channeling) · **storm-lost** (red X, once the storm has passed them). The storm itself renders as the biome-tinted wall (per `17_Art/Biome_Art_Direction.md`, NOT YET WRITTEN) with a **100m warning shimmer** before the wall itself.

**Audio cross-reference:** storm proximity is designed as a single global parameter (distance to storm wall) that drives the rumble layer, wind, and music tension together (GDD Ch. 309, voice/comms spec) — implements the Ch. 305.4 audio warning as one unified signal rather than separate cues.

## Programmer Notes
The server `config.json` (`TDD-02_Server_and_Orchestration.md`) already reserves `stormTimer: 2100` (35 min) and `stormDuration: 300` (5 min collapse) fields, confirming the storm is designed to be **server-owned and authoritative** from day one — client-side, this will be a pure visual/audio response to server-broadcast storm-radius state, following the same phase-event pattern combat abilities already use (`02_Technical/Architecture_Decision_Log_Index.md` ADR-0012/0013).

## Designer Notes
The storm timeline numbers (25:00 warning → 30:00 collapse start → 35:00 hold → 38:00 final collapse → 40:00 end) were reconciled in GDD Ch. 305 against Chapter 3's "35+5 minute" raid-loop diagram specifically because they had drifted in earlier GDD versions — treat Ch. 305's numbers as authoritative over any older raid-timing reference.

## Future Expansion
Nothing here is built yet. When M9 opens, this is one of the two biggest gaps versus "the loop is provably playable" (the other being the four typed extraction points in `Extraction_Overview.md`).

## Appendix
Full source: `Part19_Completion_Addenda.md`, GDD Chapter 305.2, 305.4.

---
*Traceability: GDD Ch. 305.2, 305.4 · Milestone M9 · Owner Discipline: Design/Engineering/Art/Audio · Status: Not Started (server config reserves fields for it).*

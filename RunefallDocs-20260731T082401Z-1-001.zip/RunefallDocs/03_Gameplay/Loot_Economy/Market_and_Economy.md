---
Document: Market_and_Economy.md
Section: 03_Gameplay/Loot_Economy
---

# Economy & Market

## Document Metadata
- **Purpose:** The full player-driven economy design — market mechanics, insurance, the Safe Box, data storage, and the live tuning dashboard.
- **Audience:** Design (economy), Engineering, Production.
- **Scope:** GDD Ch. 87 (economy overview), 88–89 (market + UI), 90 (insurance), 91 (safe box), 92 (data storage), 93 (tuning dashboard).
- **Dependencies:** `Loot_Overview.md`.
- **Related Documents:** `00_Executive/KPI_Targets.md` (Sink/Faucet Ratio target), `00_Executive/Risk_Register_Executive_Summary.md` ("Economy runaway inflation" risk), `01_Production/Milestone_Index.md` (M7, needs M3+M10).
- **GDD Chapters Covered:** Ch. 87–93.
- **Current Implementation Status:** **Not Started.** Design-complete; the DB schema is drafted in `TDD-03_Database_and_Persistence.md` but no market/insurance/safe-box code exists.

## Overview
The economy is player-driven with minimal NPC interference: prices are set by supply and demand, not fixed vendor prices, and is deliberately tuned sink-heavy (Sink/Faucet Ratio target 1.0–1.2) to avoid inflation.

## Detailed Explanation

### Economy philosophy & metrics (Ch. 87)
Principles: Player-Driven pricing · Full Loot (items cycle through the economy) · Sinks > Faucets (controlled inflation) · 5% Market Tax gold sink · No fixed NPC prices.

| Metric | Target |
|---|---|
| Sink/Faucet Ratio | 1.0–1.2 |
| Market Liquidity | >10,000 listings/day |
| Average Repair Cost | >10% of income |
| Insurance Usage | 20–40% |

**Gold flow:**
```mermaid
flowchart LR
    subgraph Faucets["FAUCETS (Gold In)"]
        MD["Mob Drops — 30%"]
        CH["Chests — 20%"]
        MI["Missions — 25%"]
        PS["Player Sales — 25%"]
    end
    Faucets --> Economy((Economy))
    Economy --> Sinks
    subgraph Sinks["SINKS (Gold Out)"]
        MT["Market Tax — 5%/transaction"]
        RC["Repair Costs — 30%"]
        IN["Insurance — 20%"]
        CC["Crafting Costs — 20%"]
        CO["Consumables — 10%"]
    end
```

### The Market (Ch. 88–89)
Players post buy/sell listings; prices set by supply/demand; 5% tax on sales; full price-history tracking; search/filter by item, tier, quality.

| Mechanic | Description |
|---|---|
| List Item | Post item for sale at desired price |
| Buy Item | Purchase at listed price |
| Cancel Listing | Remove listing, item returned |
| Buyback | Sell to vendor for 55% of market value |
| Price History | Track trends over time |

**Market UI tabs:** Browse (search/filter/sort) · Sell (post new listing) · My Listings (cancel/edit) · History (past trades).
**Filters:** Item Type, Tier (T1–T4), Quality (Mk 0–Mk V), Price Range, Seller (Any/Friends Only).

### Insurance (Ch. 90)
Protects a portion of lost items on death. **Cost:** 15% of item value per raid. **Return:** 50% of insured value on death, if the item is not looted by another player. If the item is successfully extracted, the insurance simply expires (no payout, no refund). No insurance = full loss on death if not looted.

### Safe Box (Ch. 91)
A small 2×2 (4-slot) container whose contents are **never** lost on death — the one exception to full loot. Recommended use: Health Potions, Mana Potions, one high-value item, one mission item. *(Cross-reference: the monetization view of the Safe Box is GDD Ch. 117 — do not conflate the free gameplay Safe Box with any paid expansion of it; see `28_Monetization/Monetization_Overview.md`, NOT YET WRITTEN, once that reconciliation is documented.)*

### Economy data storage (Ch. 92)
PostgreSQL tables: `market_listings` (id, seller_id, item_id, quantity, price, listed_at, status, sold_at), `market_transactions` (id, listing_id, buyer_id, seller_id, item_id, quantity, price, total_amount, tax, seller_earnings, timestamp), `insurance_records` (player_id, item_id, insured_value, paid, claim, timestamp). This is the same DB layer as `TDD-03_Database_and_Persistence.md`'s `market_listings`/`market_transactions`/`insurance_records` tables — cross-reference, don't duplicate, once `02_Technical/Data_Model/Database_Schema.md` exists.

### Economy tuning dashboard (Ch. 93)
Live-ops dashboard showing Gold In, Gold Out, Sink/Faucet ratio, and Market Listings count, with adjustable tuning controls: Market Tax (default 5%), Repair Costs (default 100%), Insurance Cost (default 15%), Buyback Rate (default 55%).

## Designer Notes
Every number on this page (5% tax, 15% insurance cost, 50% insurance payout, 55% buyback rate) is a **tuning default**, not a fixed constant — the whole point of the Ch. 93 dashboard is that these move without a code deploy. Treat this document as the day-one values, not permanent law.

## QA Notes
The insurance "expires on success, pays 50% on unlooted death" rule is easy to get backwards in implementation — test both branches explicitly, plus the "looted by another player" edge case where insurance should NOT pay out.

## Appendix
Full source: `Part09_Loot_Economy_Market.md`, GDD Chapters 87–93.

---
*Traceability: GDD Ch. 87–93 · Milestone M7 (needs M3+M10) · Owner Discipline: Design/Engineering · Status: Not Started.*

---
Document: Loot_Overview.md
Section: 03_Gameplay/Loot_Economy
---

# Loot — Overview & Drop Tables

## Document Metadata
- **Purpose:** How loot works — sourcing, mechanics, and every drop table for mobs, bosses, and containers.
- **Audience:** Design, Engineering (`LootService`/`LootTableDef`), Production.
- **Scope:** GDD Ch. 84 (looting overview), 85 (drop tables), 86 (container tables).
- **Dependencies:** `03_Gameplay/Core_Loop_Overview.md`.
- **Related Documents:** `Market_and_Economy.md`, `05_Enemies/Enemies_Overview.md` (NOT YET WRITTEN), `08_Items/Materials_and_Resources.md` (NOT YET WRITTEN).
- **GDD Chapters Covered:** Ch. 84, 85, 86.
- **Current Implementation Status:** Partial — a generic loot drop pipeline exists (`LootDropRequestedEvent` → `LootSpawner`) and the Extraction Vertical Slice proves pickup→carry→bank end-to-end with a minimal 3-field `ItemDef` (ADR-0018); the actual per-source drop tables below are largely **Not Started** (only Husk Grunt and Bandit Archer have real loot wired, per `01_Production/GDD_Coverage_Matrix.md`).

## Overview
Loot is the primary reward mechanism. Every kill, chest, and node provides loot, weighted so that danger zones yield better loot.

## Detailed Explanation

### Looting philosophy (Ch. 84.1)
Risk = Reward (danger zones → better loot) · Randomness (weighted loot tables) · Player-Driven (loot enters the player economy) · Full Loot (everything drops on death) · Variety.

### Loot sources (Ch. 84.2)

| Source | Loot type | Tier range | Notes |
|---|---|---|---|
| Mob Kill | Materials, Items | T1–T4 | Depends on mob tier |
| Boss Kill | High-tier Items, Relics | T3–T5 | Rare drops |
| Chest | Items, Gold | T1–T4 | Locked chests = better loot |
| Node | Resources | T1–T4 | Depends on node tier |
| Player Kill | Full inventory | Variable | Full loot |

### Loot mechanics (Ch. 84.3)
Loot range 2m from source · loot time 1s per item · auto-sort by type · "Loot All" collects everything in area.

### Mob drop tables (Ch. 85.1)

| Mob | Common (60%) | Uncommon (25%) | Rare (10%) | Epic (4%) | Legendary (1%) |
|---|---|---|---|---|---|
| Wolf | Hide, Raw Meat | Bone | — | — | — |
| Boar | Hide, Raw Meat | Bone | — | — | — |
| Stag | Thick Hide, Venison | Antler | — | — | — |
| Bear | Thick Hide, Bear Meat | Thick Bone | — | — | — |
| Husk Grunt | Corrupted Bone | Rift Essence | — | — | — |
| Husk Brute | Corrupted Bone, Corrupted Hide | Rift Essence | Rune Crystal | — | — |
| Bandit Cutthroat | Bandit Insignia | Gold | Scrap | — | — |
| Bandit Archer | Bandit Insignia | Gold | Arrow | — | — |
| Bandit Elite | Bandit Insignia, Gold | Silver Key | Rune Crystal | — | — |
| Rune Construct | Tech Parts | Rune Crystal | — | — | — |
| Construct Sentinel | Tech Parts, Rune Crystal | Void Crystal | Void Essence | — | — |
| Rift Wraith | Rift Essence | Void Essence | Rune Crystal | — | — |
| Core Beast | Void Hide, Corrupted Meat | Void Bone | Void Essence | — | — |

### Boss drop tables (Ch. 85.2)

| Boss | Common (50%) | Uncommon (30%) | Rare (15%) | Epic (4%) | Legendary (1%) |
|---|---|---|---|---|---|
| Matron of Thorns | Thorn Heart | Corrupted Leather | Rune Crystal | Relic (3%) | — |
| Grumnir | Forge Ember | Silver Ore | Gold Ore | Relic (4%) | — |
| Hollow King | Void Essence | Rune Crystal | Gold Ore | Relic (8%) | Legendary Item |

### Container tables (Ch. 86)

| Chest | Tier | Loot | Locked? | Key |
|---|---|---|---|---|
| Wooden Crate | 1 | T1 Resources | No | — |
| Iron Chest | 2 | T2 Resources, Gold | No | — |
| Silver Chest | 3 | T3 Resources, Gold, Key | Yes | Silver Key |
| Gold Chest | 4 | T4 Resources, Gold, Key | Yes | Gold Key |
| Rune Vault | 5 | T4 Resources, Relics, Legendary | Yes | Rune Key |

**Chest locations:** Falcrest/Emberwatch (2–3 Wooden Crates each, flavour loot) · Northern Quarry (2 Iron Chests, locked) · Old Sawcamp (1–2 Iron Chests, locked) · Fisher's Hollow (1 Wooden Crate) · Sunken Chapel (2 Iron Chests + 1, locked) · The Foundry (2 Iron Chests, locked) · Bandit Palisade (3–4 + 2 Iron Chests, locked) · The Shattered Spire (2 Gold Chests) · Rune Vault (1 each, requires Rune Key).

## Designer Notes
The mob/boss drop-rarity bands (Common/Uncommon/Rare/Epic/Legendary with fixed percentages) are the template every future mob's loot table should follow — no mob should invent its own rarity scheme.

## Appendix
Full source: `Part09_Loot_Economy_Market.md`, GDD Chapters 84–86.

---
*Traceability: GDD Ch. 84–86 · Milestone M7 (system), owned per-source in M5 · Owner Discipline: Design/Engineering · Status: Pipeline partial; per-source tables mostly Not Started.*

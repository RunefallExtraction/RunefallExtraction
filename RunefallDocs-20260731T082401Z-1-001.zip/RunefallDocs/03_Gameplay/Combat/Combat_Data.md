---
Document: Combat_Data.md
Section: 03_Gameplay/Combat
---

# Combat — Data & Formulas

## Document Metadata
- **Purpose:** Every combat formula and reference table a designer or engineer needs: damage model, crowd control, shields/healing, movement/encumbrance, combat logging schema, and sound design.
- **Audience:** Design (balance), Engineering (implementing `DamageResolver`/`EffectDef`/`CharacterMotor`), Audio.
- **Scope:** GDD Ch. 32–38.
- **Dependencies:** `Combat_Overview.md`.
- **Related Documents:** `02_Technical/Architecture_Decision_Log_Index.md` (ADR-0010, 0011, 0014), `02_Technical/Technical_Debt_Register.md` (TD-04, TD-05, TD-09).
- **GDD Chapters Covered:** Ch. 32 (damage model), 33 (crowd control), 34 (shields & healing), 35 (movement & encumbrance), 36 (combat logging), 37 (sound design), 38 (loading-screen tips).
- **Current Implementation Status:** Damage model and CC (stagger/knockback only) implemented; shields, healing, movement/encumbrance, combat logging, and sound design are all **Not Started** in code (design-complete only).

## Overview
This document is reference data — the numbers and tables combat code and balance passes are built against.

## Detailed Explanation

### Damage model (Ch. 32)

| Type | Description | Affected by |
|---|---|---|
| Physical | Weapons, melee, arrows | Armor |
| Magical | Spells, abilities | Magic Resist |
| True | Special abilities | Nothing (ignores defenses) |

**Damage formula:** `Final Damage = Base Damage × (100 / (100 + Defense)) × (1 + Modifiers)`, where Defense is Armor (Physical) or Magic Resist (Magical), and Modifiers are damage buffs/debuffs.

**Damage scaling by tier:** T1 10–30 (basic attacks, early abilities) · T2 30–80 (rank 2 abilities, early gear) · T3 80–150 (rank 3, mid gear) · T4 150–300 (rank 4, endgame gear).

**Example:** 20 Armor → ~17% reduction (100 damage → 83 damage). Same formula for Magic Resist.

**Damage scaling by champion:**

| Champion | Physical | Magical | Scaling stat |
|---|---|---|---|
| Vanguard | High | None | Strength |
| Ranger | Medium | None | Dexterity |
| Riftmage | None | High | Intelligence |
| Shadow | High | None | Dexterity |

**Current implementation:** `DamageResolver` (ADR-0010/0011) implements this formula; verified via the Combat Sandbox against Husks and Bandit Archers.

### Crowd control (Ch. 33)

| CC Type | Description | Duration | Counterplay |
|---|---|---|---|
| Stagger | Interrupts actions, brief stun | 0.3–0.75s | Dodge telegraph |
| Knockback | Pushes target away | Instant | Cannot be resisted |
| Slow | Reduces move speed 30–50% | 2–4s | Cleanse, mobility |
| Stun | Completely disables target | 1–3s | Cleanse, immunity |
| Root | Prevents movement | 1–3s | Can still act |
| Silence | Prevents ability casting | 2–4s | Can still attack |

**CC duration formula:** `CC Duration = Base Duration × (1 − CC Resistance)`, where `CC Resistance = (Skill/100) × 0.5` (max 50% at Skill 100).

**Diminishing returns:** 1st application 100% duration · 2nd (within 10s) 50% · 3rd (within 10s) 25% · 4th+ immune (3s grace period).

**CC resistance by champion:** Vanguard 10% (immune during Unbreakable R) · Ranger 5% (immune during Evasive Roll W) · Riftmage 5% (no immunity) · Shadow 5% (no immunity).

**Current implementation:** Stagger and Knockback are implemented (ADR-0014, C3.3) via `EffectDef` modules (`CastInterruptModule`, `MovementBlockModule`, `KnockbackImpulseModule` — knockback is currently unresistable, matching the GDD table). Slow, Stun, Root, Silence, and the diminishing-returns/resistance formula above are **deferred** (Technical Debt TD-05 — the resistance hook exists on `EffectDef.Resistable` but resistance is 0 until the skill system exists).

### Shields & Healing (Ch. 34) — Not Started

| Shield type | Description | Example |
|---|---|---|
| Personal | Absorbs damage on self | Bulwark (Vanguard W) |
| Directional | Blocks from one direction | Bulwark front arc |
| Team | Protects allies in area | Guardian Idol |

`Shield HP = Base Shield × (1 + Shield Power)`; shields absorb 100% of damage until depleted.

| Healing type | Description | Example |
|---|---|---|
| Instant | Immediate HP restore | Potions |
| Over-Time (HoT) | HP restored over duration | Guardian Idol |
| Lifesteal | HP gained from damage dealt | Bloodstone |
| Healing Received | Increases incoming heals | Support abilities |

`Heal Amount = Base Heal × (1 + Healing Power)`; `Lifesteal = Damage × Lifesteal Percentage`.

### Movement & Encumbrance (Ch. 35) — Not Started

`Move Speed = Base Speed × (1 + Speed Modifiers) × (1 − Encumbrance)`; `Encumbrance = (Carry Weight / Max Carry Weight) × 0.5` (max 50% slow).

**Base move speeds:** Vanguard 5.5 m/s (7.15 sprint) · Ranger 6.0 m/s (7.8 sprint) · Riftmage 5.5 m/s (7.15 sprint) · Shadow 6.2 m/s (8.06 sprint).

**Encumbrance table:** 0–20kg = 0% penalty · 20–40kg = −10% · 40–60kg = −20% · 60–80kg = −30% · 80–100kg = −40% · 100kg+ = −50%. **Design intent:** full-loot means players must choose between gear and mobility.

**Movement modifiers:** Sprint +30% (until stamina depleted) · Slow −30–50% (2–4s) · Root 0% (1–3s) · Stealth +15% (6s) · Off-road −20–40%.

### Combat logging (Ch. 36) — Not Started
Every combat event logs: timestamp, match ID, attacker ID/champion, target ID/champion, ability, damage, damage type, CC type, position, killing-blow flag, source (player/mob/boss/trap) — stored in TimescaleDB per `02_Technical` (TDD-03).

**Report system:** Cheating → review, ban if confirmed · Griefing → warning, temp ban · Toxicity → warning, mute, ban · Exploiting → ban + rollback.

**Kill-cam:** replays the last 5 seconds before death, server-recorded, client-replayed on the death screen — for learning, cheater identification, and suspicious-death reporting.

### Sound design (Ch. 37) — Not Started
Categories: ability cast, telegraph, impact, block, dodge, death. Per-champion Q/W/E/R ability sound briefs and damage/CC sound tables exist in the GDD but no audio middleware or assets exist yet (see `11_Audio/Audio_Overview.md`, NOT YET WRITTEN).

### Loading-screen combat tips (Ch. 38) — Not Started
Champion-specific and general gameplay tips authored in the GDD (e.g. "Yellow telegraphs are winding up. Red telegraphs are about to hit.") — content exists, no UI screen consumes it yet.

## QA Notes
The damage formula and CC diminishing-returns table above are the two most important numbers to regression-test once the skill/progression system (which drives CC Resistance) exists — a single formula error there silently breaks every future CC-based encounter design.

## Appendix
Full source: `Part04_Combat.md`, GDD Chapters 32–38.

---
*Traceability: GDD Ch. 32–38 · Milestone M1 (damage/CC), M8 (resistance), M13 (audio) · Owner Discipline: Design/Engineering/Audio · Status: Damage+Stagger/Knockback implemented; everything else Not Started.*

---
Document: Progression_Overview.md
Section: 03_Gameplay/Progression
---

# Progression — Full Design Overview

## Document Metadata
- **Purpose:** The complete progression design: three timelines (per-raid, per-champion, account), and every system within them.
- **Audience:** Design, Engineering, Production.
- **Scope:** GDD Ch. 40–49 in full.
- **Dependencies:** `00_Executive/Design_Pillars.md` (Pillar 4 — Progress Every Raid).
- **Related Documents:** `01_Production/GDD_Coverage_Matrix.md` (M8), `01_Production/Milestone_Index.md`.
- **GDD Chapters Covered:** Ch. 40 (overview), 41 (attunement/boons), 42 (mastery), 43 (15 account skills), 44 (collection log), 45 (faction reputation), 46 (progression UI), 47 (seasonal), 48 (achievements), 49 (data storage).
- **Current Implementation Status:** **Not Started.** Design-complete; zero code. Milestone M8, gated on Persistence (M10) landing first.

## Overview
"Never delete player progress. Every raid advances at least one system." Three timelines nest inside each other: **Per-Raid** (resets), **Per-Champion** (never resets), **Account** (never resets except seasonal cosmetics).

## Detailed Explanation

### The three timelines (Ch. 40)

| System | Scope | Resets? | Description |
|---|---|---|---|
| Attunement | Per-Raid | Yes | Temporary power within a raid |
| Boons | Per-Raid | Yes | Temporary buffs from shrines |
| Mastery | Per-Champion | No | Champion-specific XP → levels |
| Talents | Per-Champion | No | Unlockable passive bonuses |
| Awakenings | Per-Champion | No | Ultimate ability enhancements |
| Account Skills | Account | No | 15 skills, levels 1–100 |
| Collection Log | Account | No | Tracks everything collected |
| Faction Reputation | Account | No | 4 factions, reputation system |
| Seasonal | Account | Yes (seasonal) | Cosmetics, titles only |
| Achievements | Account | No | Challenge completions |

### 41 — In-raid: Attunement & Boons
**Attunement** (temporary power, reset on death/extraction) sources: Crystal Shrines, Boss Kills, Elite Mobs, Events (Rift Surge, Blood Moon).

| Attunement | Effect | Duration | Source |
|---|---|---|---|
| Crystal | +5% damage | 5 min | Crystal Shrine |
| Void | +10% HP | 5 min | Void Shrine |
| Ember | +10% move speed | 5 min | Ember Shrine |
| Rune | −10% ability cooldowns | 5 min | Rune Shrine |

**Boons:** Healing (+50% healing received, Chapel) · Damage (+20% damage, Foundry) · Speed (+20% move speed, Spire) · Shield (+50 HP shield, Vault).

### 42 — Per-champion: Mastery, Talents, Awakenings
Max level 100; XP = 50% of extracted value + kill XP; level formula `200 + 100 × Level^1.5`; 1 talent point per level; never resets.

**XP sources:** Kill (Player) 50 · Kill (Mob) 10–30 · Kill (Boss) 100–500 · Extraction (Base) 50 · Extracted Value 50% of value · Mission Complete 100–500 · First Boss Kill 200.

**Mastery rewards (by level band):** 1–10 +1% damage/level · 11–20 +1% HP/level · 21–30 +1% move speed/level · 31–40 +1% CDR/level · 41–50 +1% shield power/level · 51–60 +1% healing power/level · 61–70 +1% CC resist/level · 71–80 +1% damage reduction/level · 81–90 +1% mana regen/level · 91–100 +2% all stats/level.

**Talents:** unlock at mastery levels 5/15/25/35/45/55/65/75/85/95, granting 1/1/2/2/3/3/4/4/5/5 talent points respectively (10 tiers, cumulative).

**Awakenings** (ultimate enhancement at level 100): Vanguard — Unbreakable+ (+2s duration, +10% DR) · Ranger — Arrow Storm+ (+1 wave, +10% damage) · Riftmage — Cataclysm+ (+2m radius, +20% damage) · Shadow — Death Mark+ (+2s duration, +10% damage amp).

### 43 — Account: 15 Skills
XP formula: `100 + 50 × Level^1.5`.

| Skill | Category | Focus |
|---|---|---|
| Fitness | Utility | Stamina, climbing speed |
| Sprinting | Utility | Sprint speed, stamina efficiency |
| Awareness | Utility | Detection range, minimap reveal |
| Stealth | Utility | Stealth detection, noise reduction |
| Marksmanship | Combat | Ranged damage, accuracy |
| Melee | Combat | Melee damage, attack speed |
| Magic | Combat | Spell damage, mana efficiency |
| Armor | Combat | Armor effectiveness |
| Health | Combat | HP, regen |
| Gathering | Gathering | Gathering speed, yield |
| Refining | Crafting | Refining efficiency |
| Crafting | Crafting | Crafting quality, speed |
| Fishing | Gathering | Fishing speed, rare catches |
| Cooking | Crafting | Buff duration, effectiveness |
| Survival | Utility | Resists, recovery |

Each skill has a base value and a small per-level bonus (e.g. Fitness: Stamina Regen 1 base, +0.5/level; Marksmanship: Ranged Damage 1 base, +0.02/level) — the full per-skill bonus table (30 rows) is in the GDD Ch. 43.2 and is reproduced in full in the source document for balance authoring.

### 44 — Collection Log
Tracks everything: items, mobs, bosses, landmarks, achievements, missions — by category (Armor, Weapons, Resources, Consumables, Mobs, Bosses, Landmarks), each with completion bonuses. Bosses and Landmarks additionally grant titles/cosmetics and lore entries respectively.

### 45 — Faction Reputation
Four factions:

| Faction | Symbol | Colors | Focus |
|---|---|---|---|
| Warden | Shield | Blue/Gold | Protection, Law |
| Cult of Runes | Rune | Violet/Cyan | Magic, Knowledge |
| Iron Syndicate | Anvil | Red/Orange | Crafting, Trade |
| Shadow Circle | Dagger | Black/Grey | Stealth, Assassination |

**Tiers:** Neutral (0) → Friendly (1–1,000, faction vendor access) → Honored (1,001–5,000, discounts + exclusive items) → Revered (5,001–10,000, unique gear + special missions) → Exalted (10,001+, title + cosmetic + hidden content).

**Reputation gain/loss:** Complete Mission +50–500 · Kill Enemy Faction Mob +10–50 · Kill Enemy Faction Player +50–200 · Collect Faction Items +10–100 · Kill Friendly Faction Player −100–500 · Fail Mission −50–100 · Join Faction (first time) +100.

### 46 — Progression UI
Six screens, all accessed via `H →`: Skills, Mastery, Talents, Collection, Factions, Achievements.

### 47 — Seasonal Progression
3-month (quarterly) seasons. Account skills, mastery, and collection log **never** reset — only seasonal Battle Pass tiers and seasonal missions reset; seasonal cosmetics/titles are account-wide and permanent once earned.

### 48 — Achievements
Categories: Combat, Gathering, Crafting, Extraction, Economy, Social, Collection — each rewarding titles/cosmetics, with Collection granting a unique title+cosmetic on full completion.

### 49 — Progression Data Storage
PostgreSQL tables: `players` (id, username, created_at), `skills` (player_id, skill_id, level, xp), `mastery` (player_id, champion_id, level, xp, talent_points, talents JSONB), `collection_log` (player_id, item_id, collected_at), `faction_reputation` (player_id, faction_id, reputation). This is the same schema documented in `TDD-03_Database_and_Persistence.md` / `02_Technical/Data_Model/Database_Schema.md` (NOT YET WRITTEN) — cross-reference rather than duplicate when that document exists.

## Producer Notes
Progression (M8) is explicitly scheduled **after** Persistence (M10) in the reconciled roadmap (`01_Production/Milestone_Index.md`) — every system on this page needs durable storage before it can exist at all, which is why M10 was pulled forward in the 2026-07-26 roadmap reconciliation.

## Appendix
Full source: `Part05_Progression.md`, GDD Chapters 40–49.

---
*Traceability: GDD Ch. 40–49 · Milestone M8 (blocked on M10) · Owner Discipline: Design/Engineering · Status: Not Started.*

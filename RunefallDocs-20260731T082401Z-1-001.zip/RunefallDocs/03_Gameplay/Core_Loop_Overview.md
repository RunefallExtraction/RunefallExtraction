---
Document: Core_Loop_Overview.md
Section: 03_Gameplay
---

# Core Gameplay Loops

## Document Metadata
- **Purpose:** Define the two nested loops that make up all of Runefall's gameplay: the moment-to-moment Raid Loop and the session-to-session Economy Loop.
- **Audience:** Design, Production, Engineering — the loop every system in `03_Gameplay` ultimately serves.
- **Scope:** GDD Ch. 3 (verbatim structure, diagrams redrawn as Mermaid).
- **Dependencies:** `00_Executive/Executive_Overview.md`, `00_Executive/Design_Pillars.md`.
- **Related Documents:** `Extraction_Storm/Extraction_Overview.md` (NOT YET WRITTEN), `Loot_Economy/Loot_Overview.md` (NOT YET WRITTEN), `01_Production/Vertical_Slices_Overview.md`.
- **GDD Chapters Covered:** Ch. 3.
- **Current Implementation Status:** Partial — the Raid Loop's combat/loot/extract-or-die spine is proven end-to-end at greybox level (Extraction Vertical Slice, closed); the storm/collapse mechanic and the full Economy Loop (refine/craft/market/repair) are Not Started.

## Overview
Everything in Runefall nests inside two loops: a 35–40 minute **Raid Loop** (what happens during one match) and a persistent **Economy Loop** (what happens between matches, across a whole play session or career).

## Detailed Explanation

### 3.1 The Raid Loop (moment-to-moment, 35–40 minutes)

```mermaid
flowchart TD
    Q[Queue] --> PS[Party Select] --> ES[Edge Spawn] --> TI[Traverse Inward]
    TI --> EX[Exploration]
    subgraph EX[Exploration]
        direction LR
        GH[Gather Hotspots]
        OC[Open Crates]
        FM[Fight Mobs]
        FP[Fight Players]
    end
    EX --> DP{Decision Point}
    DP -->|Push for more: risk| EX
    DP -->|Extract now: bank| EXT[Extract]
    EX -->|Killed| DIE[Die] --> CL[Corpse Looted]
    EXT --> RS[Results Screen]
    CL --> RS
    RS --> BT[Back to Town]
```
**Duration:** 35 minutes of open raid + 5 minutes storm collapse = **40 minutes total**.

**Current implementation vs. plan:** the spine `Exploration → Decision Point → Extract/Die → Results` is real and closed (Extraction Vertical Slice, `01_Production/Vertical_Slices_Overview.md`). Party Select (matchmaking) is M12, not started. The storm timer that forces the Decision Point is GDD Ch. 305 and is **not yet built** — extraction currently has no time pressure forcing it.

### 3.2 The Economy Loop (session-to-session)

```mermaid
flowchart LR
    EM[Extract Materials] --> RR[Refine Raw]
    RR --> CC[Craft Components]
    CC --> EG[Equip Gear]
    EG --> RA[Raid Again]
    RA --> EOD[Extract or Die]
    EOD --> EM
    EM --> SM[Sell on Market]
    SM --> BM[Buy Materials]
    BM --> RG[Repair Gear]
    RG --> RA
```

**Faucets** (where value enters the economy): mobs, bosses, crates, gathering nodes, missions.
**Sinks** (where value leaves the economy): crafting, repair, 5% market tax, insurance, consumables.

This is the loop the KPI target "Sink/Faucet Ratio 1.0–1.2" (`00_Executive/KPI_Targets.md`) is measuring — it must run slightly sink-heavy to avoid the "economy runaway inflation" risk (`00_Executive/Risk_Register_Executive_Summary.md`).

**Current implementation status:** entirely **Not Started** beyond the raw extract-materials step (the Extraction Vertical Slice banks generic loot to a stash, but there is no refine, craft, market, repair, or insurance system yet — these are Milestones M6 and M7).

## Designer Notes
The two loops are deliberately coupled through exactly one point: what you extract from the Raid Loop is the only input to the Economy Loop, and what you equip from the Economy Loop is what you risk in the next Raid Loop. Every progression/economy system elsewhere in this repository should be checked against whether it strengthens or dilutes that single coupling point.

## QA Notes
The Raid Loop's "Extract" vs. "Die" branch is the single most-tested transition in the codebase to date — see the Extraction Vertical Slice's audit (`01_Production/Vertical_Slices_Overview.md`) for the specific scenarios verified (pickup→carry→extract→bank; pickup→carry→die→lose; leave→lose; consecutive raids; empty-inventory extraction; interrupt/re-enter).

## Future Expansion
The storm mechanic (GDD Ch. 305) that puts real time pressure on the Decision Point, and the full Economy Loop (Gathering→Refining→Crafting→Market→Repair, Milestones M6/M7), are the two biggest gaps between "the loop is provably playable" and "the loop is the actual designed game."

## Appendix
Full source: `Part01_Vision_and_Pillars.md`, GDD Chapter 3.

---
*Traceability: GDD Ch. 3 · Milestone M9 (storm) / M6+M7 (economy) · Owner Discipline: Design/Engineering · Status: Partial (Raid Loop spine proven; storm and economy loop Not Started).*

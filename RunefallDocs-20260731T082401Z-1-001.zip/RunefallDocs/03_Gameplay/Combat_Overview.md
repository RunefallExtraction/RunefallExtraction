---
Document: Combat_Overview.md
Section: 03_Gameplay/Combat
---

# Combat — Design Overview

## Document Metadata
- **Purpose:** The combat design philosophy, the telegraph language every ability speaks, and the balance-tuning process — the *player-facing* half of combat. Engineering architecture lives in `02_Technical/Architecture_Decision_Log_Index.md` (ADR-0010 through ADR-0014).
- **Audience:** Design (primary), Engineering, QA.
- **Scope:** GDD Ch. 30 (overview), 31 (telegraph language), 39 (balance tuning).
- **Dependencies:** `00_Executive/Design_Pillars.md` (Pillar 3 — Readable, Skill-Expressive Combat).
- **Related Documents:** `Combat_Data.md` (damage/CC/shields/movement formulas), `02_Technical/Architecture_Decision_Log_Index.md` (ADR-0010–0014, ADR-0017), `02_Technical/Assembly_Map.md`.
- **GDD Chapters Covered:** Ch. 30, 31, 39.
- **Current Implementation Status:** Partial — the windup→telegraph→impact→damage flow, telegraph shapes (Cone/Circle live; Line/Ring stubbed), and server-authoritative-ready hit detection are implemented (C1–C3.3). Balance tuning has not begun (no live game to tune yet).

## Overview
Runefall's combat is designed for skill expression through positioning, timing, and decision-making — not gear stat checks. Every dangerous ability telegraphs honestly before it lands.

## Detailed Explanation

### Combat philosophy (Ch. 30.1)
- **Telegraph-Driven** — all dangerous abilities have visual warnings.
- **Server-Authoritative** — all hits validated server-side.
- **Positioning Matters** — flanking, high ground, and cover are critical.
- **Skill Over Stats** — a skilled player beats a geared player.
- **Visual Clarity** — the low poly art style ensures readability.

### Combat flow (Ch. 30.2)
`Windup (Cast) → Telegraph (Visual) → Impact (Hit) → Damage (Apply)`
- Windup: 0.1–1.0s ability cast time.
- Telegraph: appears during windup as a fill indicator.
- Impact: damage/CC applied on the active frame.
- Damage: calculated server-side, factoring resistances.

**Current implementation:** this exact 4-phase flow is what `AbilitySystem`'s phase FSM implements (`Windup → Active → Recovery → Cooldown`, ADR-0012) — the GDD's design and the shipped engineering model line up directly.

### The telegraph language (Ch. 31)
Four fixed telegraph shapes — **never altered by cosmetics**:

| Shape | Description | Example abilities |
|---|---|---|
| Line | Narrow rectangle, direction-based | Shield Slam*, Piercing Arrow, Arcane Bolt, Shadow Strike |
| Cone | Triangle, direction-based | Multishot, Fan of Knives |
| Circle | Round, area-based | Arrow Storm, Void Zone, Cataclysm |
| Ring | Circular border, area-based | (future abilities) |

*Shield Slam is documented elsewhere as a Cone (6m/120°) in the actual implementation — see `04_Characters/Vanguard/Vanguard_Design.md` (NOT YET WRITTEN) for the reconciliation; the GDD's Ch.31 table appears to categorize it under Line examples inconsistently with its own Ch.22 ability description. Flagged, not silently resolved.

**Champion telegraph colors:**

| Champion | Color | Hex |
|---|---|---|
| Vanguard | Steel Blue | #5A6B7A |
| Ranger | Forest Green | #6B8B4A |
| Riftmage | Violet | #5A3A8A |
| Shadow | Cyan-Black | #4ADADA + #2A2A3A |

**Windup fill indicator** (design intent: players time dodges off this):

| Phase | Color | Visual |
|---|---|---|
| Start | Yellow | 0% fill |
| Middle | Orange | 50% fill |
| Ready | Red | 100% fill |

**Current implementation:** the fill indicator exists as geometry-growth (not the yellow→orange→red color progression yet — that's tracked as Technical Debt TD-08, "Telegraph polish," deferred to the Polish milestone). Cast-rooting (ADR-0013, Option A) is the implemented answer to telegraph honesty — the character is locked during windup so the telegraph's promise always matches the impact.

**Telegraph art spec (Ch. 31.4):** low poly decals, flat-shaded; fill animates from center or edge; 70% opacity; duration matches windup (0.1–1.0s); 2x-brightness white edge highlight.

### Combat balance tuning (Ch. 39)

| Parameter | Tuning range per patch |
|---|---|
| Damage | ±10–20% |
| Cooldown | ±0.5–2s |
| Mana Cost | ±5–15 |
| HP | ±50–100 |
| Move Speed | ±0.1–0.3 m/s |
| Armor | ±2–5 |
| Magic Resist | ±2–5 |

**Balance data sources:** pick rates, win rates (extraction success), K/D ratios, extracted value, player feedback, combat logs.
**Cadence:** hotfix (as needed, critical bugs/exploits) · patch (monthly, numbers tuning) · seasonal (quarterly, meta shifts).

## Designer Notes
Pillar 3 (`00_Executive/Design_Pillars.md`) is the direct design ancestor of every rule on this page — telegraph shapes are fixed specifically so a naked player with better positioning can beat a geared player who reads telegraphs worse.

## Programmer Notes
See `02_Technical/Architecture_Decision_Log_Index.md` ADR-0010 (geometric hit detection, not physics), ADR-0012 (unified ability model), ADR-0013 (telegraph as one-way view assembly) for how this design is actually implemented.

## Future Expansion
Balance tuning cadence (hotfix/patch/seasonal) has no live game to apply to yet — this section of the GDD becomes actionable only post-launch or in closed playtesting.

## Appendix
Full source: `Part04_Combat.md`, GDD Chapters 30, 31, 39.

---
*Traceability: GDD Ch. 30, 31, 39 · Milestone M1 · Owner Discipline: Design/Engineering · Status: Partial (flow + telegraphs implemented; balance tuning not started).*

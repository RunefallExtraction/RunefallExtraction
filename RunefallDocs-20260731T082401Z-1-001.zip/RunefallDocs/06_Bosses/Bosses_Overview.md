---
Document: Bosses_Overview.md
Section: 06_Bosses
---

# Bosses — Full Roster

## Document Metadata
- **Purpose:** All three bosses — two mini-bosses and the world boss — mechanics, arenas, and rewards.
- **Audience:** Design, Engineering, Art, Audio, Production.
- **Scope:** GDD Ch. 80 (Matron of Thorns), 81 (Grumnir), 82 (Hollow King).
- **Dependencies:** `05_Enemies/Enemies_Overview.md`.
- **Related Documents:** `07_World/Landmarks_Index.md` (NOT YET WRITTEN — arena locations), `01_Production/GDD_Coverage_Matrix.md` (App E boss drop tables, also in `03_Gameplay/Loot_Economy/Loot_Overview.md`).
- **GDD Chapters Covered:** Ch. 80, 81, 82.
- **Current Implementation Status:** **Not Started.** All three bosses are design-complete only.

## Overview
Three bosses gate the highest-value loot in the game: two mini-bosses in the Mid ring and one world boss at the Core.

## Detailed Explanation

### Matron of Thorns (mini-boss, Ch. 80)

| Attribute | Value |
|---|---|
| Tier | 5 (Mini-Boss) |
| Zone | Sunken Chapel |
| HP | 1,500 |
| Damage | 30–50 |
| Speed | 3 m/s |
| Reward | Thorn Heart, high-tier loot |

**Abilities:** Thorn Whip (cone, 40 dmg, 4s CD) · Corruption Circle (30/s DoT circle, 6s CD) · Spore Burst (self-centered ring, 20 dmg, 8s CD) · Summon Thornlings (3 adds, 15s CD). **Phase 1 (100–50% HP):** Thorn Whip + Corruption, summons Thornlings at 75%. **Phase 2 (50–0%):** all abilities more frequent, Spore Burst added, more aggressive.

### Grumnir the Forgemaster (mini-boss, Ch. 81)

| Attribute | Value |
|---|---|
| Tier | 5 (Mini-Boss) |
| Zone | The Foundry |
| HP | 1,800 |
| Damage | 35–55 |
| Speed | 2.5 m/s |
| Reward | Forge Ember, high-tier loot |

**Abilities:** Hammer Smash (cone, 50 dmg, 5s CD) · Molten Wave (line, 40 dmg, 6s CD) · Forge Shield (self, 50% damage reduction, 10s CD) · Summon Adds (Husk Brutes, 20s CD). **Phase 1:** Hammer Smash + Molten Wave, summons adds at 70%. **Phase 2:** Forge Shield activates, all abilities more frequent.

### The Hollow King (world boss, Ch. 82)

| Attribute | Value |
|---|---|
| Tier | 5 (World Boss) |
| Zone | The Shattered Spire |
| HP | 10,000 |
| Damage | 50–100 |
| Speed | 2 m/s |
| Reward | Boss Vault, best-in-slot loot |

**Abilities:** Void Slam (circle, 80 dmg, 8s CD) · Soul Drain (self ring, 50/s life drain, 12s CD) · Rift Beam (line, 100 dmg, 10s CD) · Summon Wraiths (5 Rift Wraiths, 20s CD) · Corruption Burst (circle, 60 dmg, 15s CD). **Three phases:** Phase 1 (100–65% HP) Void Slam + Rift Beam, summons Wraiths at 80%. Phase 2 (65–30%) all abilities more frequent, Soul Drain added. Phase 3 (30–0%) shortest cooldowns, Corruption Burst added, most aggressive.

### Boss drop tables (cross-reference — full table in `03_Gameplay/Loot_Economy/Loot_Overview.md`)
Matron: Thorn Heart (common) → Corrupted Leather → Rune Crystal → Relic (3%). Grumnir: Forge Ember → Silver Ore → Gold Ore → Relic (4%). Hollow King: Void Essence → Rune Crystal → Gold Ore → Relic (8%) → Legendary Item (1%).

## Producer Notes
All three bosses reuse the same combat/ability/effect frameworks proven by Vanguard's Shield Slam and the Husk Grunt — a boss "phase" is architecturally an HFSM super-state transition (per `02_Technical/Architecture_Decision_Log_Index.md` and the AI design docs), not a new system. Building a boss should mostly be `MobDef`/`AbilityDef` authoring plus arena-specific art, not new engineering.

## Appendix
Full source: `Part08_Mobs_and_AI.md`, GDD Chapters 80–82.

---
*Traceability: GDD Ch. 80–82 · Milestone M5 · Owner Discipline: Design/Engineering/Art · Status: Not Started.*

---
Document: Launch_Checklist.md
Section: 19_Release
---

# Launch Checklist

## Document Metadata
- **Purpose:** The final go/no-go checklist for shipping Runefall.
- **Audience:** Production, all discipline leads.
- **Scope:** GDD Ch. 172 (Final Checklist, Part 16), 304 (Phase 11 Launch Ready deliverable, Part 18).
- **Dependencies:** `01_Production/Production_Governance_and_Operating_Model.md` (Beta/Release exit criteria — the more detailed, currently-governing version of this same gate).
- **Related Documents:** `18_QA/QA_Strategy_Overview.md`.
- **GDD Chapters Covered:** Ch. 172, 304.
- **Current Implementation Status:** N/A — this is a launch-time checklist, relevant only once the project nears release. Currently at ~12–16% overall completion (`00_Executive/Current_Project_Status.md`), far from this gate.

## Overview
Two versions of essentially the same launch checklist exist in the GDD — a high-level category list (Ch. 172) and a more granular per-system checklist grouped by category (Ch. 304). Both are superseded in practice by the more detailed, actively-governing Beta/Release exit criteria already documented in `01_Production/Production_Governance_and_Operating_Model.md`; this document exists to close the loop on those two GDD chapters rather than to introduce a third, competing checklist.

## Detailed Explanation

### Final checklist categories (Ch. 172.1)

| Category | Items |
|---|---|
| Technical | Server, database, infrastructure |
| Content | Champions, world, mobs |
| UI | All screens, HUD |
| Audio | Sound, music |
| Art | All assets |
| Testing | QA, bug fixes |
| Marketing | Trailer, website, social |
| Legal | EULA, privacy policy, terms |

### Phase 11 completion checklist (Ch. 304.1)
Grouped: Server Orchestration (spawning/termination works) · Anti-Cheat (EAC integrated, server validation enabled) · Live-Ops (dashboard implemented, metrics/server list displayed) · Testing (all tests passing, bug count < 10 critical) · Launch (final build created, deployment tested, monitoring working).

### The governing version
`01_Production/Production_Governance_and_Operating_Model.md`'s Beta exit criteria (no blocker bugs, networking stable, save compatibility verified, performance targets met, required Beta content complete, regression passing, gameplay enjoyable, tutorial complete) and Release exit criteria (all of Beta, plus final art/animation/audio/VFX, localization, accessibility, optimization, QA, analytics, live-ops, monetization, support tools, certification) are the actively-maintained, more granular successor to both GDD checklists above — use that document, not this one, as the living gate.

## Producer Notes
This document is kept short and pointer-heavy deliberately: three checklists saying almost the same thing would be a maintenance liability, not added rigor. The Governance document is the one to update as the project actually approaches launch.

## Appendix
Full source: `Part16_Dev_Roadmap.md` Ch. 172; `Part18_Implementation_Plan.md` Ch. 304.

---
*Traceability: GDD Ch. 172, 304 · Milestone M13 (launch) · Owner Discipline: Production/All · Status: N/A — not yet relevant at current project stage.*

---
Document: Battle_Pass.md
Section: 20_LiveOps
---

# Battle Pass

## Document Metadata
- **Purpose:** The seasonal Battle Pass structure — tiers, cost, free vs. premium tracks.
- **Audience:** Design, Production, Monetization.
- **Scope:** GDD Ch. 106.
- **Dependencies:** `Live_Events_Overview.md` (seasonal wrapper).
- **Related Documents:** `28_Monetization/Monetization_Overview.md` (NOT YET WRITTEN), `00_Executive/Design_Pillars.md` (Pillar 5 — Fair Monetization; the Battle Pass must sell only cosmetics/convenience, never power).
- **GDD Chapters Covered:** Ch. 106.
- **Current Implementation Status:** Not Started.

## Overview
A 100-tier, 3-month seasonal Battle Pass with a free track (50% of rewards) and a premium track (100% of rewards, 1,000 Gems).

## Detailed Explanation

### Battle Pass structure (Ch. 106.1)

| Aspect | Description |
|---|---|
| Tiers | 100 |
| Duration | 3 months (seasonal) |
| Cost | 1,000 Gems (Premium) |
| Free Track | 50% of rewards |
| Premium Track | 100% of rewards |

### Reward bands (Ch. 106.2)

| Tiers | Free rewards | Premium rewards |
|---|---|---|
| 1–20 | Gold, Consumables | Cosmetics, Gems |
| 21–40 | Materials, Consumables | Weapon Skins, Gems |
| 41–60 | Gems, Titles | Armor Skins, Gems |
| 61–80 | Cosmetics, Gems | Mount Skins, Gems |
| 81–100 | Title, Emote | Legendary Skin, Gems |

## Designer Notes
Every reward category listed here (skins, gems, titles, emotes, cosmetics) is cosmetic or currency — consistent with Pillar 5's "never sell power" rule. When this system is authored, the same check that governs `28_Monetization/Monetization_Overview.md` applies here: no tier reward may grant a combat stat, gear tier, or any advantage a non-paying player cannot also earn through play.

## Appendix
Full source: `Part11_Live_Events.md`, GDD Chapter 106.

---
*Traceability: GDD Ch. 106 · Milestone M13 · Owner Discipline: Design/Monetization · Status: Not Started.*

---
Document: Live_Events_Overview.md
Section: 20_LiveOps
---

# Live Events Overview

## Document Metadata
- **Purpose:** The five dynamic raid events, their schedule, and the seasonal content wrapper around them.
- **Audience:** Design, Production, Engineering, Art/Audio.
- **Scope:** GDD Ch. 104 (dynamic events), 105 (seasonal content), 107 (event scheduler), 108–112 (each event in detail), 113 (event UI).
- **Dependencies:** `03_Gameplay/Extraction_Storm/Extraction_Overview.md`.
- **Related Documents:** `Battle_Pass.md`, `07_World/Landmarks_Index.md` (Caravan Road, the Bandit Convoy's route).
- **GDD Chapters Covered:** Ch. 104, 105, 107–113.
- **Current Implementation Status:** **Not Started.** Design-complete only. Milestone M9 (raid events specifically) / M13 (seasonal meta-wrapper).

## Overview
Five dynamic events fire during raids on independent schedules, adding risk/reward variety on top of the base loop; seasonal content (quarterly) wraps a Battle Pass and seasonal cosmetics/missions around the whole game.

## Detailed Explanation

### The five events (Ch. 104.1, schedule Ch. 104.2)

| Event | Frequency | Duration | Timing | Effect |
|---|---|---|---|---|
| Blood Moon | 3/day | 15 min | Random | +50% mob spawns, +25% loot quality, red-tinted sky |
| World Boss Roam | 2/day | 10 min | Scheduled | Hollow King (or variant) walks a pre-defined route between waypoints, creating high-risk zones |
| Rift Surge | 5/day | 5 min | Random | 3–5 random rift spawns, Rift-Touched enemies, bonus loot |
| Bandit Convoy | 2/day | 10 min | Random | Bandit caravan moves along Caravan Road (Falcrest → Emberwatch), drops bandit chests/resources on defeat |
| Unique Cache | 1/day | 5 min | Random | Hidden treasure cache, visible on minimap, requires a key/lockpick, high-tier loot + gems |

### Blood Moon detail (Ch. 108)
Mob spawn rate ×1.5, mob density ×1.5, loot quality ×1.25, bonus boss-spawn chance. Visual: red-tinted sky (#4A2A2A), red glow on mobs, red particles.

### World Boss Roam path (Ch. 109)
Core (Shattered Spire, 0 min) → Northern Quarry (3 min) → Old Sawcamp (5 min) → Fisher's Hollow (7 min) → return to Core (10 min) — a slow walk between waypoints; the boss's AoE abilities attract players along the whole route.

### Event scheduler (Ch. 107)
A daily schedule UI listing today's events with reminders (`[SET REMINDER]`).

### Seasonal content (Ch. 105)
3-month (quarterly) seasons, each with a 100-tier Battle Pass, seasonal cosmetics, seasonal titles, and seasonal missions — see `Battle_Pass.md` and the account-progression note in `03_Gameplay/Progression/Progression_Overview.md` §47 confirming account skills/mastery/collection never reset seasonally, only the Battle Pass tiers and seasonal missions do.

## Producer Notes
`01_Production/GDD_Coverage_Matrix.md` splits ownership of Ch. 104–113 between M9 (the raid-time event mechanics, since they fire inside a live raid and depend on the same server-authoritative raid loop) and M13 (the meta/season wrapper) — this document covers both halves in one place since the GDD itself treats them as one continuous topic.

## Appendix
Full source: `Part11_Live_Events.md`, GDD Chapters 104, 105, 107–113.

---
*Traceability: GDD Ch. 104, 105, 107–113 · Milestone M9 (mechanics) / M13 (season wrapper) · Owner Discipline: Design/Engineering/Art/Audio · Status: Not Started.*

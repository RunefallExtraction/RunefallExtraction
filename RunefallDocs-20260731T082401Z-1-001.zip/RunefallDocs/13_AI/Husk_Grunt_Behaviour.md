---
Document: Husk_Grunt_Behaviour.md
Section: 13_AI
---

# Husk Grunt — Behavior Detail

## Document Metadata
- **Purpose:** The one fully-implemented, fully-verified mob AI in the project — documented as the template for every future mob.
- **Audience:** Design, Engineering, QA.
- **Scope:** The C4 Slice 1–3 design/implementation story (`Batch_C4_Slice1_Design.md`, `Architecture_Retrospectives.md` R-003–R-005) reconciled against the GDD's Husk Grunt spec (`05_Enemies/Enemies_Overview.md`, GDD Ch. 76).
- **Dependencies:** `AI_Gameplay_Overview.md`, `05_Enemies/Enemies_Overview.md`.
- **Related Documents:** `02_Technical/Architecture_Retrospectives_Index.md` (R-003 MobDef/Faction, R-004 AiBrain, R-005 MobSpawner).
- **GDD Chapters Covered:** Ch. 76.2 (Husk Grunt stats).
- **Current Implementation Status:** **Implemented and verified** — the one complete mob in the codebase.

## Overview
Husk Grunt is tier 2, HP 80, Damage 12, Speed 3 m/s, aggro range 15m, leash range 20m, behavior "roams in groups, attacks on sight" per the GDD. This document tracks how that spec became working AI.

## Detailed Explanation

### The data model (C4 Slice 1 — see R-003)
`MobDef` was audited field-by-field against the GDD and reduced from ~12 initially-proposed fields to the ones the mob stat tables actually author: MaxHealth, MoveSpeed, AggroRange, LeashRange, Abilities, Prefab, Faction. Fields inherited "by analogy" from `ChampionDef` (Armor, MagicResist, RotationSpeed) were removed because the GDD's mob tables don't author them — mob durability is HP + tier only.

### The brain (C4 Slice 2 — see R-004)
The entire Husk Grunt AI runtime is **one class (`AiBrain`) + one property (`ICombatant.Faction`)** — not a framework. `AiBrain` orchestrates perceive → chase → attack → leash → return using the exact same `HealthComponent`/`AbilitySystem`/`CharacterMotor`/`EffectController`/`CombatantRegistry` a champion uses. It owns no combat, locomotion, or effect logic itself — only the sense/think/act sequencing.

### The spawner (C4 Slice 3 — see R-005)
`MobSpawner` configures a spawned Husk Grunt's health/faction/motor/abilities/brain from its `MobDef`, and despawns it on death. A `MotorConfig` struct (definition-agnostic) lets the same `CharacterMotor` be configured from either a `ChampionDef` or a `MobDef` without `Locomotion` depending on `Data` — cutting a dependency edge while adding this content.

### Verification (Combat Sandbox)
Verified in three composition scenarios (melee pack alongside 2 more Husks, mixed with Bandit Archers, solo) with the AI's aggro/leash/return cycle confirmed to behave correctly under all three. Root-cause bugs found and fixed during this verification: committed-return leash behavior (the mob wasn't reliably returning to its spawn point after leashing) and kiting commit-window interaction (melee AI committing to an attack while being kited by a player).

## QA Checklist
- [x] Aggro on sight within 15m range
- [x] Attacks on sight once aggrod
- [x] Leashes at 20m, returns to spawn
- [x] Verified in pack composition (multiple Husks)
- [x] Verified in mixed composition (Husks + Bandit Archers)
- [ ] Art (currently greybox capsule)
- [ ] Animation
- [ ] Audio (moan/hiss/claw/death-cry per GDD Ch. 76.2)
- [ ] Loot table wired to real drop data (currently placeholder)

## Appendix
Full source: `Batch_C4_Slice1_Design.md`; `Architecture_Retrospectives.md` R-003, R-004, R-005; `Part08_Mobs_and_AI.md` Ch. 76.2.

---
*Traceability: GDD Ch. 76.2 · Milestone M5 (this mob: Done) · Owner Discipline: Design/Engineering/QA · Status: Implemented and verified; art/animation/audio pending.*

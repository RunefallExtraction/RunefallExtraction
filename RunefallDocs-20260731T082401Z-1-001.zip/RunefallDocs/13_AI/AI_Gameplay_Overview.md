---
Document: AI_Gameplay_Overview.md
Section: 13_AI
---

# AI — Gameplay Overview

## Document Metadata
- **Purpose:** The gameplay-facing view of enemy AI — what it does and how it feels to fight — as distinct from the engineering architecture (covered in `02_Technical`).
- **Audience:** Design, QA, Production.
- **Scope:** GDD Ch. 74–83 (mob behaviors), App R (behavior trees) — reconciled against what actually shipped.
- **Dependencies:** `05_Enemies/Enemies_Overview.md`, `06_Bosses/Bosses_Overview.md`.
- **Related Documents:** `02_Technical/Architecture_Retrospectives_Index.md` (R-002–R-005, the full AI engineering story), `Husk_Grunt_Behaviour.md`.
- **GDD Chapters Covered:** Ch. 74–83, App R.
- **Current Implementation Status:** One mob (Husk Grunt) has real AI, verified in the Combat Sandbox alongside Bandit Archer.

## Overview
The GDD describes mob behavior per-species (pack hunting, fleeing, territorial, etc. — see `05_Enemies/Enemies_Overview.md`); the actual AI that ships behind all of it is a single, generic, reusable brain — not a bespoke system per mob type.

## Detailed Explanation

### GDD's behavior tree expectation (App R)
The GDD's Appendix R sketches a generic behavior tree: a Selector choosing between an Attack sequence (check target in range → attack → wait cooldown), a Chase sequence (check target in aggro range → move to target → wait), and an Idle sequence (patrol → wait). This is the *design* shape every mob's AI should follow.

### What actually shipped (the Husk Grunt loop)
Per `02_Technical/Architecture_Retrospectives_Index.md` R-004: the Husk Grunt's entire AI is **perceive → chase → attack → leash → return**, implemented as one `AiBrain` class (~150 lines) that *uses* every system a champion already has — `HealthComponent`, `AbilitySystem`, `CharacterMotor`, `EffectController`, `CombatantRegistry` — and *owns* only the orchestration between them. This matches the GDD's Selector/Attack/Chase/Idle shape closely, but was reached by composition rather than by building a generic behavior-tree engine.

### Verified in the Combat Sandbox
Husk Grunt (melee) and Bandit Archer (ranged) were both verified together in three composition scenarios (melee pack, ranged group, mixed), with four real bugs found and fixed during that verification: projectile XZ hit detection, committed-return leash behavior, kiting commit-window + cast-commit interaction, and directional telegraph delivery type. This is the current, honest bar for "an AI mob is done" — not just "compiles," but verified under multiple real composition scenarios.

## Producer Notes
Because the AI runtime is thin and general (not per-mob bespoke code), authoring the remaining ~11 mobs and 3 bosses in `05_Enemies`/`06_Bosses` is expected to be primarily **data** (a `MobDef` + `Faction` + prefab + `AbilityDef`s for its attacks) rather than new AI engineering — see the Producer Notes in `05_Enemies/Enemies_Overview.md` for the same point made from the content side.

## QA Notes
Every future mob AI verification should follow the Combat Sandbox pattern: verify in multiple *composition* scenarios (solo, pack, mixed with other mob types), not just in isolation — three of the four bugs found in the Husk Grunt/Bandit Archer sandbox only appeared under specific multi-mob compositions.

## Appendix
Full source: `Part08_Mobs_and_AI.md` App R (behavior tree shape); `Architecture_Retrospectives.md` R-002–R-005 (actual implementation); `Project_Status.md` (Combat Sandbox verification log).

---
*Traceability: GDD Ch. 74–83, App R · Milestone M5 · Owner Discipline: Design/Engineering/QA · Status: 2 of ~13 mobs verified; pattern proven and reusable.*

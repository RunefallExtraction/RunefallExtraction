---
Document: Art_Production_Pipeline.md
Section: 26_Pipelines
---

# Art Production Pipeline

## Document Metadata
- **Purpose:** Pointer document — the core art pipeline (concept→blockout→sculpt→retopo→UV→texture→import) and production schedule already live in `17_Art/Art_Direction_Overview.md`. This document adds the one piece not covered there: station/interaction pipelines from GDD App P.
- **Audience:** Art, Technical Art, Engineering.
- **Scope:** GDD Ch. 151.2 (pipeline — see `17_Art/Art_Direction_Overview.md`), 162 (schedule — see same), App P (station interaction details, not covered elsewhere).
- **Dependencies:** `17_Art/Art_Direction_Overview.md`.
- **Related Documents:** `03_Gameplay/Loot_Economy` (crafting/refining, the systems these stations belong to — currently Not Started, M6).
- **GDD Chapters Covered:** Ch. 151.2, 162, App P.
- **Current Implementation Status:** Not Started.

## Overview
The general art pipeline and production schedule are documented in `17_Art/Art_Direction_Overview.md` — see that document for the full pipeline stages and the 26-week schedule. This document covers the one remaining piece: crafting-station interaction timings (App P), a pipeline concern that sits between art (station models/animations) and gameplay (crafting UI, `09_UI/UI_Screen_Catalog.md`).

## Detailed Explanation

### Station interaction details (App P)

| Station | Interaction | Duration |
|---|---|---|
| Smelter | Press F → insert ores | 2s |
| Sawmill | Press F → feed logs | 2s |
| Alchemy | Press F → stir cauldron | 3s |

These are the authored interaction timings for the M6 (Gathering→Refining→Crafting) crafting stations referenced in `01_Production/GDD_Coverage_Matrix.md` — the full station roster (Forge/Leather/Tailor/Alchemy/Kitchen, per `09_UI/UI_Screen_Catalog.md`'s Crafting UI section) presumably extends this same pattern, though only these three specific timings are authored in the source appendix.

## Producer Notes
This is a thin document by design — it exists to close out App P's coverage without duplicating the fuller pipeline content already in `17_Art/Art_Direction_Overview.md`. See that document first for anything about the general art production process.

## Appendix
Full source: `17_Art/Art_Direction_Overview.md` (pipeline/schedule); `Part17_Appendices.md` App P (station interactions).

---
*Traceability: GDD Ch. 151.2, 162, App P · Milestone M6 (stations) / M13 (general pipeline) · Owner Discipline: Art/Engineering · Status: Not Started.*

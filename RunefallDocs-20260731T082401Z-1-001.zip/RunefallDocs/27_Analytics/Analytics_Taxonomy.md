---
Document: Analytics_Taxonomy.md
Section: 27_Analytics
---

# Analytics & Telemetry Event Taxonomy

## Document Metadata
- **Purpose:** The event schema behind every KPI/dashboard target in the GDD — what actually gets measured, in what shape.
- **Audience:** Engineering, Production, LiveOps, Data.
- **Scope:** GDD Ch. 313.
- **Dependencies:** `00_Executive/KPI_Targets.md` (the metrics this schema measures), `16_Database/Schema_Reference.md` (TimescaleDB, the storage target).
- **Related Documents:** `01_Production/Production_Governance_and_Operating_Model.md` (Release exit criteria include analytics).
- **GDD Chapters Covered:** Ch. 313.
- **Current Implementation Status:** **Not Started.** This chapter is explicitly new in V4.0 — it exists because Ch. 9/93/123/165/167/168 define KPIs and dashboards but historically had no underlying event schema.

## Overview
Eight core event tables, all landing in TimescaleDB, fire-and-forget from game servers so telemetry never blocks simulation.

## Detailed Explanation

### Core event tables

| Event | Key fields | Feeds |
|---|---|---|
| `session_start`/`session_end` | account, platform, client_version, region | DAU/MAU, session length |
| `raid_start` | match_id, seed, party_size, gear_score, champion | Pick rates, matchmaking band health |
| `raid_end` | outcome (extract/death/storm/dc), extract_type, duration, value_in, value_out | Extraction rate, value/hour — directly feeds `00_Executive/KPI_Targets.md`'s "Extracted value/hour" metric |
| `kill` | killer/victim (mob or player), position, ability, distance | Balance tuning, heatmaps |
| `economy_tx` | type (craft/repair/market/insurance/vendor), item, amount, direction | Faucet/sink ratio — directly feeds the Sink/Faucet Ratio KPI (`03_Gameplay/Loot_Economy/Market_and_Economy.md`) |
| `ftue_step` | step id, duration, completed | New-player-experience funnel |
| `monetization` | sku, price_local, currency, platform | Monetization KPIs (`28_Monetization/Monetization_Overview.md`) |
| `perf_sample` | fps_avg, fps_1pct_low, device_tier, cell | Real-world validation of `17_Art/Performance_Budgets.md` targets |

### Rules
- Events are fire-and-forget from game servers — never block simulation — and batched at 5-second intervals.
- Position data is quantized to the 100m cell grid (`07_World/Ashen_Reach_Overview.md`) for heatmaps; full-precision positions stay in combat logs only (`03_Gameplay/Combat/Combat_Data.md`'s combat-logging schema), not in the analytics stream.
- **No PII in analytics events** — account IDs are internal IDs only; deletion/retention is governed by `29_Legal/Compliance_and_Legal.md`.

## Programmer Notes
This schema is the missing link between `00_Executive/KPI_Targets.md` (what to measure) and `16_Database/Schema_Reference.md` (where TimescaleDB lives) — building the ingestion pipeline that turns these eight event types into the KPI dashboard is itself unscheduled work (flagged as a planning gap in `Production_Coverage_Report.md`), belonging to M13.

## Appendix
Full source: `Part19_Completion_Addenda.md`, GDD Chapter 313.

---
*Traceability: GDD Ch. 313 · Milestone M13 · Owner Discipline: Engineering/Data/LiveOps · Status: Not Started.*

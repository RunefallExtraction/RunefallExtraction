---
Document: VFX_Overview.md
Section: 10_VFX
---

# VFX Direction

## Document Metadata
- **Purpose:** VFX categories and principles governing every particle effect in the game.
- **Audience:** VFX Artists, Engineering (`VFXPool`).
- **Scope:** GDD Ch. 158; App N (Ability VFX Reference).
- **Dependencies:** `17_Art/Art_Direction_Overview.md` (NOT YET WRITTEN — shared low poly style).
- **Related Documents:** `03_Gameplay/Combat/Combat_Overview.md` (telegraph VFX), `02_Technical/Architecture_Decision_Log_Index.md` (ADR-0013 — the one concrete VFX system that exists, telegraphs).
- **GDD Chapters Covered:** Ch. 158, App N.
- **Current Implementation Status:** **Not Started** as a general system. The one shipped VFX-adjacent piece is the telegraph geometry-growth fill (ADR-0013) — deliberately not shader-based yet (Technical Debt TD-08).

## Overview
Three VFX categories, three governing principles — all in service of readability first, performance second, and a consistent low poly style.

## Detailed Explanation

### VFX categories (Ch. 158.1)
- **Ability VFX** — telegraphs, impacts, trails.
- **Environment VFX** — particles, weather, magic.
- **UI VFX** — transitions, notifications.

### VFX principles (Ch. 158.2)
- **Readability** — clear telegraphs (the same Pillar 3 mandate that governs telegraph shapes in `03_Gameplay/Combat/Combat_Overview.md`).
- **Performance** — optimized particles, respecting the per-platform emission caps (`00_Executive/Platform_and_Hardware_Targets.md`).
- **Style** — low poly stylized, consistent with the rest of the art direction.

### Ability VFX reference (App N)
The GDD's Appendix N maps specific abilities to their VFX treatment (e.g. Shield Slam → cone decal + impact flash; Piercing Arrow → line decal + arrow trail; Arcane Bolt → line decal + bolt projectile; Shadow Strike → line decal + dash trail) — this is the authoring reference for VFX artists building each champion's kit, cross-referenced from `04_Characters`.

## Implementation Status (cross-check)
The current telegraph system (ADR-0013) deliberately uses geometry-growth fill instead of a shader/VFX-graph fill, specifically to stay dependency-free and deterministic while gameplay systems were the priority. TD-08 (`02_Technical/Technical_Debt_Register.md`) tracks the shader-based polish swap as a Polish-milestone (M13) item — the `ITelegraph` interface already makes that swap gameplay-free when it happens.

## Appendix
Full source: `Part15_Art_and_Audio.md` Ch. 158; `Part17_Appendices.md` App N.

---
*Traceability: GDD Ch. 158, App N · Milestone M13 (+ per-ability polish throughout) · Owner Discipline: VFX/Engineering · Status: Not Started (telegraph fill is the one exception, greybox).*

---
Document: Setting_and_Tone.md
Section: 21_Lore
---

# Setting & Tone

## Document Metadata
- **Purpose:** Runefall's tone, mood, and visual/atmospheric reference points. This is the entirety of what the GDD defines about setting — see the Overview for what's explicitly out of scope.
- **Audience:** Design, Art, Narrative (if a narrative discipline is ever staffed).
- **Scope:** GDD Ch. 4.
- **Dependencies:** `00_Executive/Executive_Overview.md`.
- **Related Documents:** `07_World/Risk_Rings.md` (the biome color palette below is the same one reproduced there).
- **GDD Chapters Covered:** Ch. 4.
- **Current Implementation Status:** N/A — tone/mood reference, not a system.

## Overview
**Important scope note:** the GDD defines Runefall's *tone and atmosphere* in real detail (this document) but has **no dedicated narrative, backstory, or lore chapters** — no history of the world, no named factions' founding stories beyond their one-line thematic description (`03_Gameplay/Progression/Progression_Overview.md` §45), no character backstories beyond the champion identity paragraphs (`04_Characters`). Deeper lore is **NOT DEFINED IN GDD**. This document is the complete, honest picture of "setting" as the GDD actually specifies it — a mood and visual reference, not a fictional history.

## Detailed Explanation

### Artistic tone (Ch. 4.1)
Primary reference: low poly stylized (Albion Online-inspired).

| Inspiration | Aspect borrowed |
|---|---|
| Albion Online | Clean, readable, colorful low poly aesthetic |
| OSRS Wilderness | The desolate, lawless feel |
| Dark Souls | Somber, atmospheric, hostile |
| — (explicit "No") | Realistic textures, photorealistic lighting, high-poly models |

### Color palette by biome (Ch. 4.2)

| Biome | Primary | Accent | Mood |
|---|---|---|---|
| Outer (Pine Frontier) | #8B9A6B, #D4A76A | #6B7B5A, #A68B5A | Misty, serene, dangerous |
| Mid (Ashen Farmland) | #8B8B8B, #D4A76A | #A85A3A, #6B4A3A | Burnt, desolate, tense |
| Core (Crystallized Wasteland) | #2A2A3A, #7A5ADA | #5ADADA, #4A3A6A | Awe, dread, otherworldly |

*(These hex values match `07_World/Risk_Rings.md`'s biome table exactly — the two documents describe the same palette from two GDD chapters that happen to agree.)*

### Camera & feel (Ch. 4.3)
Reference: Albion Online. Perspective: top-down 3/4 view. Zoom range: 18–22m (PC), 12–15m (Mobile). Follow: smooth with slight lag. Occlusion: obstacles fade between camera and player.

### Tone & atmosphere (Ch. 4.5)
Two primary tones, held simultaneously: **"Hostile Wild"** (corrupted valley, unforgiving AI, constant threat) and **"High-Stakes Tension"** (risk vs. reward, full loot, player choice). Two secondary tones: **"Somber Mystery"** (ancient ruins, forgotten magic, unseen horrors) and **"Hopeful Ambition"** (permanent progression, player economy, community & craft). The primary tones drive moment-to-moment raid tension; the secondary tones color the *reason* players keep coming back between raids.

## Designer Notes
Because there is no deeper lore bible, any future narrative work (faction histories, named NPCs, a world timeline) is genuinely new design work, not an extraction/documentation task — it should be scoped and staffed as such rather than assumed to already exist somewhere in the GDD.

## Appendix
Full source: `Part01_Vision_and_Pillars.md`, GDD Chapter 4.

---
*Traceability: GDD Ch. 4 · Cross-cutting (Art/Design reference) · Owner Discipline: Design/Art · Status: N/A — reference document.*

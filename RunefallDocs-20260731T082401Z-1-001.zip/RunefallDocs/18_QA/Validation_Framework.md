---
Document: Validation_Framework.md
Section: 18_QA
---

# Validation Framework

## Document Metadata
- **Purpose:** The editor-time guardrail system that catches asset-wiring and data-authoring bugs before Play Mode.
- **Audience:** Engineering, QA, Design (anyone authoring ScriptableObject content).
- **Scope:** ADR-0016 (`02_Technical/Architecture_Decision_Log_Index.md`), extended by the C4 mob validators.
- **Dependencies:** `QA_Strategy_Overview.md`.
- **Related Documents:** `02_Technical/Architecture_Decision_Log_Index.md` (ADR-0016).
- **GDD Chapters Covered:** N/A (project-specific tooling, not in the GDD).
- **Current Implementation Status:** **Implemented.** Introduced 2026-07-24, actively used since.

## Overview
A recurring bug class — null/missing references in generated assets — motivated a permanent, extensible editor validator rather than a one-off fix.

## Detailed Explanation

### Why it exists
A C2 asset-wiring null bug recurred more than once. Rather than patch the specific instance again, the project built a framework that makes the whole *class* of bug catchable before Play Mode, for any current or future asset type.

### How it works
- `IProjectValidator` — an interface any validator implements, auto-discovered via `TypeCache` (no manual registration list to keep in sync).
- `ValidationReport` — a consolidated PASS/FAIL result structure.
- One menu command: `Runefall ▸ Validate ▸ Run All Validators`.

Adding a new validator is a new class only — the runner itself never changes (open/closed principle, consistent with `02_Technical/Standing_Engineering_Rules.md` Rule 6, contracts ship with their first implementation).

### Validators that exist today
- **Asset-wiring validator** — the original C2-recurrence guard: asserts generated `ChampionDef`/prefab/effect references are fully wired.
- **Duplicate-definition-id validator** — catches two definitions accidentally sharing an id.
- **`MobDefValidator`** (added in C4 Slice 1) — missing prefab; empty `Abilities`; `MoveSpeed`/`MaxHealth` ≤ 0; `AggroRange` ≤ 0; `LeashRange` < `AggroRange`; prefab missing required components (`HealthComponent`, `EffectController`, `AbilitySystem`, `CharacterMotor`, `AiBrain`).
- **`AiBrainDefValidator`** (added in C4 Slice 1, alongside the above) — missing/invalid entry state, duplicate state ids, null state nodes, transitions referencing non-existent state ids, unreachable states (via BFS from the entry state). Transition cycles are valid for an FSM and are *not* flagged.

## QA Notes
Invalid AI/data assets now surface as validator **errors** before Play Mode, not as silent null-reference exceptions discovered during manual testing — this shifts an entire bug class left, from "found by a human clicking Play" to "found by a menu command a human runs before committing."

## Producer Notes
Every future content type (recipes, missions, factions) that gets its own Definition ScriptableObject is expected to get its own validator following this same pattern — it's cheap (one class) and the payoff (catching authoring mistakes before they reach Play Mode or, worse, a build) compounds as content volume grows.

## Appendix
Full source: `Architecture_Decisions.md` ADR-0016; `Batch_C4_Slice1_Design.md` §7 (the two new validators added alongside MobDef).

---
*Traceability: N/A (tooling) · Cross-cutting, all content authoring · Owner Discipline: Engineering/QA · Status: Implemented, actively extended per new content type.*

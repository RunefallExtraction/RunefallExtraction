---
Document: QA_Strategy_Overview.md
Section: 18_QA
---

# QA Strategy Overview

## Document Metadata
- **Purpose:** Reconcile the GDD's illustrative testing sample code with the actual, working test discipline the project has followed since Batch C.
- **Audience:** QA, Engineering, Production.
- **Scope:** GDD Ch. 303 (Testing & QA Strategy — illustrative `TestRunner` sample), 304 (Phase 11 Launch Ready checklist). Reconciled against actual practice: every Batch/Slice design doc's own "Test Plan" section and the Mandatory Slice Closure Gates.
- **Dependencies:** `02_Technical/Standing_Engineering_Rules.md` (Slice Closure Gates).
- **Related Documents:** `Validation_Framework.md`, `01_Production/Production_Governance_and_Operating_Model.md` (Beta/Release exit criteria).
- **GDD Chapters Covered:** Ch. 303, 304.
- **Current Implementation Status:** **The GDD's own sample is not what shipped — a stronger process exists instead.** No dedicated QA discipline beyond what's described below; testing is currently integrated into each engineering slice, not a separate QA function.

## Overview
The GDD's Ch. 303 `TestRunner` sample is a single illustrative MonoBehaviour with ~15 placeholder tests (`TestCombatDamage() { /* TODO */ return true; }`), explicitly a **sketch**, not the actual test suite. Per `02_Technical/Coding_Standards.md`, GDD sample code is illustrative and must be adapted, not copied — and in this case, adaptation meant replacing it with something more rigorous.

## Detailed Explanation

### What the GDD sketches (Ch. 303.1)
A `TestRunner` MonoBehaviour that coroutine-runs a fixed list of named tests (network, combat, champion, gathering, crafting, economy, progression, performance) and reports pass/fail counts. Every test body in the sample is a `// TODO` stub returning `true`.

### What the project actually does instead
Every populated assembly has real EditMode + PlayMode test asmdefs (`02_Technical/Coding_Standards.md` §7 — deterministic, no `Thread.Sleep`, `Method_State_Expectation` naming). More importantly, **every implementation slice defines and executes its own test plan as part of design**, not as an afterthought — e.g. `Batch_C3_ShieldSlam_Design.md` specifies phase-timing, multi-target-cone-damage, and cooldown tests before implementation begins; `Batch_C3.2_Telegraph_Design.md` specifies PlayMode/EditMode/manual-Unity test plans per feature. This is enforced structurally by the **Mandatory Slice Closure Gates** (`02_Technical/Standing_Engineering_Rules.md`): a slice cannot close without static validation, a whole-project dependency audit, a whole-project ownership audit, a scalability review, and a written retrospective.

### Phase 11 / Launch Ready checklist (Ch. 304.1)
The GDD's launch checklist groups readiness into Server Orchestration, Anti-Cheat, Live-Ops, Testing, and Launch categories, with the bar "All tests passing, bug count < 10 critical." This maps directly onto the Beta/Release exit criteria already documented in `01_Production/Production_Governance_and_Operating_Model.md` — this document doesn't duplicate that gate list, it's the same list.

## QA Notes
There is currently no separate QA discipline or role distinct from engineering — testing is embedded in every slice's design and closure gates. This is appropriate at the current team size and stage; `01_Production/Milestone_Index.md` and `Production_Governance_and_Operating_Model.md` both flag QA/testing as an M13 cross-cutting concern once the project scales toward Beta, at which point a dedicated QA function and the real automated regression suite the GDD gestures at should be built.

## Appendix
Full source: `Part18_Implementation_Plan.md` Ch. 303–304.

---
*Traceability: GDD Ch. 303, 304 · Cross-cutting (embedded per-slice today; M13 for dedicated QA) · Owner Discipline: QA/Engineering · Status: Process exists and is stronger than the GDD's own sketch; no dedicated QA role yet.*

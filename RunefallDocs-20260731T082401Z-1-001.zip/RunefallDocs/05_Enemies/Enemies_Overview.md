---
Document: Enemies_Overview.md
Section: 05_Enemies
---

# Enemies — Full Roster

## Document Metadata
- **Purpose:** Every non-boss enemy family and its members: Beasts, Husks, Constructs, Bandits, Rift-Touched.
- **Audience:** Design, Engineering, Art, Audio, Production.
- **Scope:** GDD Ch. 74–79, 83.
- **Dependencies:** `03_Gameplay/Combat/Combat_Data.md` (damage model these stats plug into).
- **Related Documents:** `06_Bosses/Bosses_Overview.md`, `13_AI/AI_Gameplay_Overview.md` (NOT YET WRITTEN), `02_Technical/Architecture_Retrospectives_Index.md` (R-002–R-005 — the Husk AI implementation story).
- **GDD Chapters Covered:** Ch. 74 (overview), 75 (Beasts), 76 (Husks), 77 (Constructs), 78 (Bandits), 79 (Rift-Touched), 83 (spawn zones).
- **Current Implementation Status:** Partial — Husk Grunt and Bandit Archer have real AI + loot + spawn wired (Combat Sandbox verified); everything else in this roster is design-complete, **Not Started**.

## Overview
Six mob categories populate the Deadzone, tiered 1–5 by zone and difficulty, each with distinct behavior patterns.

## Detailed Explanation

### Mob philosophy & tiers (Ch. 74)
Categories: Beasts (natural animals, basic AI) · Husks (corrupted undead, aggressive) · Constructs (rune-powered machines, tactical) · Bandits (humanoid, strategic) · Rift-Touched (rift-corrupted, powerful) · Bosses (mini-bosses + world boss).

| Tier | Zone | Difficulty | Loot | Examples |
|---|---|---|---|---|
| 1 | Outer | Easy | T1 | Wolf, Boar |
| 2 | Outer/Mid | Medium | T1–T2 | Bear, Stag, Husk Grunt |
| 3 | Mid | Hard | T2–T3 | Husk Brute, Construct, Bandit |
| 4 | Core | Very Hard | T3–T4 | Rift-Touched, Construct Sentinel |
| 5 | Boss | Extreme | T4+ | Mini-bosses, World Boss |

**Spawn mechanics:** fixed spawn points near landmarks · 3–8 mobs per point · 30–120s respawn · 5–15m patrol radius · 10–20m aggro range (mob-dependent) · 20–40m leash range.

### Beasts (Ch. 75)

| Beast | Tier | HP | Damage | Speed | Zone | Behavior |
|---|---|---|---|---|---|---|
| Wolf | 1 | 50 | 8 | 5 m/s | Outer | Pack (3–5), circle and bite |
| Boar | 1 | 60 | 10 | 4.5 m/s | Outer | Solo/pair, charges when aggrod |
| Stag | 2 | 80 | 6 | 6 m/s | Outer/Mid | Flees when approached, fights if cornered |
| Bear | 2 | 150 | 15 | 4 m/s | Outer/Mid | Territorial, charges |
| Rift Wolf | 3 | 120 | 20 | 6 m/s | Mid | Pack (2–4), faster and deadlier |
| Rift Bear | 4 | 250 | 30 | 4.5 m/s | Core | (Corrupted variant of Bear) |
| Core Beast | 4 | 200 | 25 (Phys+Magic) | 5 m/s | Core | Territorial, rift effects |

### Husks (Ch. 76)
Corrupted undead — Husk Grunt (T2), Husk Brute (T3), Husk Archer (T3), Husk Elite (T4). **Husk Grunt is the one fully implemented mob in the codebase** — see the Implementation section below.

### Constructs (Ch. 77)
Rune-powered, tactical — Rune Construct (T3), Construct Sentinel (T4).

### Bandits (Ch. 78)
Humanoid, strategic — Bandit Cutthroat, Bandit Archer, Bandit Elite (all T2–T3). **Bandit Archer has real AI + loot + spawn wired**, alongside Husk Grunt, in the verified Combat Sandbox.

### Rift-Touched (Ch. 79)
Corrupted by rift energy — Rift Wraith, Core Beast (T4, shared with Beasts family in some GDD tables).

### Mob spawn zones (Ch. 83)
Spawn density scales with ring: Outer 3–5 mobs/spawn (50–80 total) · Mid 4–8/spawn (100–150 total) · Core 3–6/spawn (30–50 total).

## Implementation Status (cross-check)
Per `02_Technical/Architecture_Retrospectives_Index.md` (R-002 through R-005), the Husk AI runtime was deliberately built as **one class (`AiBrain`) + one property (`Faction`)** — not a framework — reusing the same `HealthComponent`/`AbilitySystem`/`CharacterMotor`/`EffectController` every champion already uses. This means adding the rest of the roster above is expected to be almost entirely **data** (a new `MobDef` + prefab) rather than new engineering, once M5 opens — the pattern is proven, not speculative.

## Producer Notes
`04_Characters` established the same lesson for champions: Vanguard's Shield Slam proved the ability framework once; every other ability/mob is data on top of it. The Husk Grunt did the equivalent for AI. Both milestones (M2, M5) are now primarily *content* work, not *systems* work.

## Appendix
Full source: `Part08_Mobs_and_AI.md`, GDD Chapters 74–79, 83.

---
*Traceability: GDD Ch. 74–79, 83 · Milestone M5 · Owner Discipline: Design/Engineering/Art · Status: 2 of ~13 mobs implemented; rest Not Started (data-only work expected).*

---
Document: Architecture_Freeze_Policy.md
Section: 02_Technical
---

# Architecture Freeze Policy

## Document Metadata
- **Purpose:** State, as a standalone policy document, the single most important standing rule currently governing engineering work: the Architecture Freeze.
- **Audience:** Every engineer; especially anyone proposing a structural/architectural change.
- **Scope:** This is a focused extract of the Freeze policy already fully stated in `Architecture_Retrospectives_Index.md` — kept here as its own document because it's referenced constantly and deserves a stable, short, linkable location. **No content is duplicated beyond what's needed for this policy to stand alone; for the full retrospective narrative that led to it, see the source document.**
- **Dependencies:** `Architecture_Retrospectives_Index.md`, `Standing_Engineering_Rules.md`.
- **Related Documents:** `Architecture_Decision_Log_Index.md`.
- **GDD Chapters Covered:** N/A (process).
- **Current Implementation Status:** **In effect since 2026-07-25.** Not lifted as of the latest project status.

## Overview
The foundational architecture is considered **complete**. Architecture changes are now reactive, not proactive — a subsystem may be changed only when implementation exposes a measurable trigger.

## Detailed Explanation

### The governing principle
*Nothing exists before it owns a real, measurable responsibility.* This principle is applied consistently across classes, interfaces, runtime components, definitions, and assemblies — the consistency, not any particular class or assembly count, is the achievement.

### The six measurable triggers (only these justify a change)
1. Ownership ambiguity
2. Duplicated responsibility
3. Coupling that prevents extension
4. An objective dependency-graph improvement
5. A measurable runtime or memory bottleneck
6. A repeated implementation pattern across multiple real consumers

**If none of the six apply: build gameplay.** Do not reopen a closed slice without objective evidence of a trigger. "A cleaner design is imaginable" is explicitly **not** a valid trigger.

### Frozen subsystems (stable unless implementation proves a deficiency)
Core DI + event system · Definition architecture · Validation framework · Locomotion architecture · Ability architecture · AI ownership model · Mob architecture · Assembly structure · Dependency direction · Ownership rules · Review process.

### Priority shift under the Freeze
Effort now goes to: gameplay, combat feel, champions, mobs, bosses, progression, loot, extraction flow, matchmaking, networking, persistence, content pipeline, tools, balancing, performance, production readiness. **Success is measured by playable features, not refined infrastructure.**

### What is unchanged under the Freeze
The engineering standard itself does not relax: composition over new frameworks; concrete until a 2nd consumer; measurable ownership over speculative flexibility; delete over preserve-for-maybe; every construct justifies itself through an owned responsibility; every change must improve the project **objectively, not aesthetically.**

## Producer Notes
This policy has a direct production-side counterpart: `01_Production/Production_Governance_and_Operating_Model.md`'s "the roadmap changes only if..." rule, locked the following day (2026-07-26). Both documents encode the same discipline — reactive-only change, gated by measurable triggers — from two different disciplines.

## QA Notes
When reviewing a proposed architectural change, the first question is simply: which of the six triggers does this satisfy? If the answer is "none, but it would be cleaner," the proposal does not meet the bar under the current Freeze.

## Appendix
Full source: `Architecture_Retrospectives.md`, "🔒 ARCHITECTURE FREEZE" section.

---
*Traceability: Cross-cutting, all of Engineering · Owner Discipline: Engineering/Architecture · Status: In effect since 2026-07-25.*

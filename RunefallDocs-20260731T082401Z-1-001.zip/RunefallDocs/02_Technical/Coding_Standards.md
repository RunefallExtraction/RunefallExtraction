---
Document: Coding_Standards.md
Section: 02_Technical
---

# Coding Standards

## Document Metadata
- **Purpose:** Binding coding standards for all first-party code, enforced by `.editorconfig` (IDE + Roslyn) and code review.
- **Audience:** Every engineer, from the first line of code they write on this project.
- **Scope:** Full reconstruction of `CODING_STANDARDS.md`. Implements the ratified decisions referenced in `CONTRIBUTING.md §1` and the architecture in `Architecture_Overview.md`.
- **Dependencies:** `Architecture_Overview.md`, `Standing_Engineering_Rules.md`.
- **Related Documents:** `Architecture_Decision_Log_Index.md`, `Technical_Debt_Register.md`.
- **GDD Chapters Covered:** Ch. 193.4 (naming), 194.3 (generated-code provenance).
- **Current Implementation Status:** Active and enforced — every reviewed slice to date has been checked against these rules (see closure gate 1, "static validation," in `Standing_Engineering_Rules.md`).

## Overview
Eight binding rule groups: architecture, naming, multiplayer/authority, performance, async/threading, public API docs, testing, and generated-code provenance.

## Detailed Explanation

### 1. Architecture rules (non-negotiable)
- **Composition Root + DI.** Dependencies are wired at a single composition root (`Core/Architecture/ApplicationManager.cs`) and passed in. Systems receive what they need; they do not fetch globals.
- **No gameplay singletons.** Do **not** add `public static T Instance` to gameplay systems. The only permitted engine-lifetime singletons are true bootstrap/root objects, and they must be justified in review. Note: several GDD sample snippets use `Instance` — those are illustrative only and must be adapted to DI when implemented.
- **No service locators, no global mutable managers.** Cross-module communication goes through the typed event bus (`Core/Architecture/EventSystem.cs`) or explicit interfaces.
- **Dependencies point downward only.** Never reference upward; asmdef boundaries enforce this. `Runefall.Core` has no first-party dependencies.
- **Data-driven.** Balance/config values live in ScriptableObjects or `StreamingAssets/Configs` JSON, never hard-coded. No magic numbers — name constants.

### 2. Naming (GDD Ch. 193.4)

| Symbol | Convention | Example |
|---|---|---|
| Types, methods, properties, namespaces | PascalCase | `PlayerController`, `ApplyDamage` |
| Interfaces | `I` + PascalCase | `IEventBus` |
| Constants | PascalCase | `MaxPlayers` |
| Private/internal fields | `_camelCase` | `_moveSpeed` |
| Private static fields | `s_camelCase` | `s_instanceCount` |
| Locals & parameters | camelCase | `targetPosition` |
| Files | PascalCase, one primary type per file | `DamageSystem.cs` |
| Assets | snake_case | `copper_sword.fbx` |
| Prefabs / Scenes | PascalCase | `Vanguard_Default.prefab`, `Raid_Greybox.unity` |
| Test files | `ClassName_Tests` | `HealthSystem_Tests.cs` |

*Applied example, per Standing Rule 2 (`Architecture_Retrospectives_Index.md`):* assemblies are named by responsibility, not first consumer — `Runefall.Abilities`, `Runefall.Locomotion` — the naming convention above extends to assembly names too.

### 3. Multiplayer & authority
- The server is authoritative; the client predicts and decorates. Never trust client-supplied results (see `TDD-01_Networking.md`).
- Any code touching gameplay outcome must carry `// TODO: HUMAN_REVIEW — verify network authority` until reviewed, and be validated at **24 players** (GDD Ch. 140).
- Keep input (intent) separate from applying state, so local prototypes swap cleanly to authoritative implementations. This is precisely the seam every ability/combat/movement system has been built behind since ADR-0005.

### 4. Performance (mobile-inclusive budgets)
- No per-frame/per-tick allocations on hot paths (movement, combat, VFX). No LINQ or lambdas that capture in `Update`/tick loops.
- Pool everything spawned at runtime (projectiles, VFX, damage numbers) via Core pooling / `VFX/VFXPool`. Never `Instantiate`/`Destroy` per cast.
- Cache component lookups; never `GetComponent`/`Find` in loops.
- Respect the GDD performance budgets (draw calls 2000/1000/500/250 for PC-High/PC-Low/Mobile-High/Mobile-Low; particle caps per GDD Ch. C2/156 — see `17_Art/Performance_Budgets.md`, NOT YET WRITTEN).

### 5. Async & threading
Prefer `UniTask`/coroutines over raw `async void`. No `Task` on gameplay hot paths. Server tick logic is synchronous and deterministic.

### 6. Public API & documentation
XML `///` docs on all public types/members. Each system has a one-paragraph header comment describing its responsibility and its events.

### 7. Testing
Every module gets an EditMode test asmdef (and PlayMode where behavior is runtime) **when it gets code**. Name tests `Method_State_Expectation`. Deterministic tests only — no wall-clock `Thread.Sleep`; use frame/tick stepping.

### 8. Generated-code provenance (GDD Ch. 194.3)
AI-assisted files carry a provenance header and explicit `HUMAN_REVIEW` TODOs for authority/performance/security-critical logic.

## QA Notes
Rule 3's `HUMAN_REVIEW` TODO convention is the primary mechanism for flagging code that needs human sign-off before the networking retrofit — grep for it as part of any pre-M12 audit.

## Appendix
Full source: `CODING_STANDARDS.md`.

---
*Traceability: GDD Ch. 193.4, 194.3 · Cross-cutting, all Engineering · Owner Discipline: Engineering · Status: Active, enforced.*

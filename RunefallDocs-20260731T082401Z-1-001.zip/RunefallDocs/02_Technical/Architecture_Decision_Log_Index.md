---
Document: Architecture_Decision_Log_Index.md
Section: 02_Technical
---

# Architecture Decision Log — Index (ADR-0001 to ADR-0018)

## Document Metadata
- **Purpose:** The canonical, chronological record of every major architecture decision made on Runefall, with context, alternatives considered, and reasoning — not just the outcome.
- **Audience:** Engineering (primary); anyone needing to understand *why* the codebase is shaped the way it is before proposing a change.
- **Scope:** Full reconstruction of `Architecture_Decisions.md` (all 18 ADRs, verified against source). Status legend: **Proposed** · **Accepted** · **Superseded**. When a later decision changes an earlier one, the earlier record's status is updated to Superseded with a forward link — never silently replaced.
- **Dependencies:** `00_Executive/Current_Project_Status.md`.
- **Related Documents:** `Architecture_Retrospectives_Index.md`, `Architecture_Overview.md`, `Standing_Engineering_Rules.md`, `Technical_Debt_Register.md`.
- **GDD Chapters Covered:** Varies per ADR (cited inline).
- **Current Implementation Status:** All 18 ADRs below are **Accepted** except ADR-0008 (**Proposed**, implementation deferred to VS1 Batch E).

## Overview
Eighteen ADRs span 2026-07-20 (project start) to 2026-07-25 (Extraction Vertical Slice). They form a continuous line: composition-root architecture → engine/transport/camera decisions → the Gameplay orchestration layer → combat's geometric hit detection → the unified ability model → telegraphs → the unified Effect/Status framework → Locomotion and Abilities extractions (both driven by the same "second real consumer" test) → the Extraction loop itself.

## Detailed Explanation

### Summary table

| ADR | Title | Date | Status |
|---|---|---|---|
| 0001 | Composition Root + DI + Event-Driven Architecture | 2026-07-20 | Accepted |
| 0002 | Engine Version: Unity 6.3 | 2026-07-20 | Accepted |
| 0003 | Networking Transport: ENet/UDP with WebSocket Fallback | 2026-07-20 | Accepted |
| 0004 | Camera: Custom Top-Down Controller instead of Cinemachine | 2026-07-20 | Accepted |
| 0005 | New Assembly: `Runefall.Gameplay` (Match/Session Orchestration) | 2026-07-20 | Accepted |
| 0006 | Shared Lifecycle Contracts (Events/Enums) Live in `Runefall.Core` | 2026-07-20 | Accepted |
| 0007 | Event-Driven Scene Flow: SceneDirector + Persistent Bootstrap + Loading Overlay | 2026-07-20 | Accepted |
| 0008 | Save/Persistence Architecture (JSON now → backend later) | 2026-07-20 | **Proposed** (VS1 Batch E) |
| 0009 | Player Control Scheme: Click-to-Move + Abilities Q/W/E/R | 2026-07-20 | Accepted |
| 0010 | Combat Hit Detection: Geometric `CombatantRegistry` (not physics overlaps) | 2026-07-21 | Accepted |
| 0011 | Combat contracts + `CombatantRegistry` as a DI service in Core | 2026-07-21 | Accepted (updates 0010) |
| 0012 | Unified data-driven ability model (one FSM + `IAbility` strategies) | 2026-07-24 | Accepted |
| 0013 | Telegraphs as a one-way, render-agnostic view assembly + data-driven cast rooting | 2026-07-24 | Accepted |
| 0014 | Unified Status/Gameplay Effect Framework + `ICombatant` as the single combat gateway | 2026-07-24 | Accepted (extends 0011, 0012) |
| 0015 | `Runefall.Locomotion`: the single, generic locomotion foundation | 2026-07-24 | Accepted (extends 0005) |
| 0016 | Project Validation Framework (extensible health-check) | 2026-07-24 | Accepted |
| 0017 | `Runefall.Abilities`: the generic ability engine, extracted from `Runefall.Champions` | 2026-07-24 | Accepted (extends 0012) |
| 0018 | Extraction loop: `ExtractionZone` requests, `MatchController` completes, `RaidInventory` banks | 2026-07-25 | Accepted |

### ADR-0001 — Composition Root + DI + Event-Driven Architecture
**Problem:** how do systems obtain dependencies and communicate without global state, given the charter forbids singleton abuse/tight coupling? **Selected:** `ApplicationManager` composition root wires plain-C# services into a `ServiceContainer`, injects a typed `CoreServices` facade into scene `MonoBehaviour`s via `IInjectable`; cross-system messaging uses `IEventBus`. **Reasoning:** no hidden globals, testable, zero external deps, minimal allocation, over static singletons/service locators or a third-party DI container (Zenject/VContainer). **Trade-off:** manual wiring, no auto-resolve. **Impact:** foundational — every system follows it. **Future:** a container (VContainer) could replace the manual root later without changing consumers.

### ADR-0002 — Engine Version: Unity 6.3
**Problem:** GDD Ch. 135/208 specifies Unity 2022 LTS; the actual project is 6000.3.6f1. **Selected:** standardize on Unity **6.3** — matches project reality, newer LTS line, FishNet/Nakama both support it, avoids a downgrade. The GDD text still references 2022 LTS for provenance; this ADR is the record that supersedes it.

### ADR-0003 — Networking Transport: ENet/UDP with WebSocket Fallback
**Problem:** the GDD's architecture table says WebSocket; its Ch. 215 sample code uses ENet/UDP — a discrepancy. **Selected:** ENet/UDP for real-time gameplay traffic, WebSocket fallback for restrictive networks/mobile web. **Impact:** not yet implemented (Networking milestone, M12) but all future netcode is designed around this.

### ADR-0004 — Camera: Custom Top-Down Controller instead of Cinemachine
**Problem:** the GDD samples Cinemachine, but `com.unity.cinemachine 3.1.4` failed to resolve ("aborted") in Unity 6.3. **Selected:** a custom `CameraController` behind an `ICameraDirector` interface; Cinemachine removed from the manifest entirely. **Reasoning:** lighter, deterministic, allocation-free, testable, target-swap friendly, and removes a package-resolution blocker outright rather than fighting a version pin. **Trade-off:** no built-in cinematic blends — acceptable for gameplay camera; a boss-intro cinematic camera can implement `ICameraDirector` later, optionally backed by Cinemachine again.

### ADR-0005 — New Assembly: `Runefall.Gameplay` (Match/Session Orchestration)
**Problem:** where does cross-system gameplay orchestration (match lifecycle, spawning, extraction) live without polluting system modules or creating cycles? **Selected:** a new top-level `Runefall.Gameplay` assembly that references the system modules; nothing references it back — a clean top-of-graph feature layer. Player avatar, spawner, extraction, and loot orchestration all landed here across the VS1 batches.

### ADR-0006 — Shared Lifecycle Contracts (Events/Enums) Live in `Runefall.Core`
**Problem:** UI (publisher) and Gameplay (subscriber) must communicate via the event bus without referencing each other directly — where do shared types like `MatchState` and `StartMatchRequestedEvent` live? **Selected:** a "shared kernel" in Core — lifecycle enums and flow events live in `Runefall.Core`; implementations (e.g. `MatchController`) live in the feature assemblies that own the behavior. Preserves the decoupling benefit of the event bus: publisher and subscriber share only a Core contract, never each other.

### ADR-0007 — Event-Driven Scene Flow
**Problem:** robust Boot→Menu→Raid→Menu scene transitions without flicker, coupling callers to a loader. **Selected:** callers publish `LoadSceneRequestedEvent`; a coroutine-free `SceneDirector` service (using `AsyncOperation.completed`) loads and publishes started/completed events; `ApplicationManager` syncs `GameState`; a `LoadingOverlayPanel` on a `DontDestroyOnLoad` bootstrap object shows during loads — no dedicated Loading scene needed. Guards missing Build Settings entries by failing loud rather than silently.

### ADR-0008 — Save/Persistence Architecture (Proposed)
**Problem:** the extraction loop needs to bank loot to a persistent stash now, without blocking on the full TDD-03 PostgreSQL backend. **Proposed:** `ISaveService`/`JsonSaveService` in Core with a versioned save DTO, swappable later to a Nakama/Postgres-backed implementation behind the same interface. **Status:** Proposed — implementation scheduled for VS1 Batch E, not yet built. **Accepted trade-off:** local JSON saves are not authoritative or anti-cheat-safe, which is acceptable pre-networking.

### ADR-0009 — Player Control Scheme: Click-to-Move + Abilities Q/W/E/R
**Problem:** choose the PC control scheme and reconcile it with ability keybinds. A WASD + mouse-facing scheme was briefly explored before the product owner confirmed the GDD scheme. **Selected:** PC uses right-click move-to-point (character faces travel direction); gamepad/mobile uses left-stick direct move (camera-relative); abilities on Q/W/E/R (no conflict, since movement uses the mouse). Matches GDD Ch. 210 and the Albion/OSRS reference.

### ADR-0010 — Combat Hit Detection: Geometric `CombatantRegistry`
**Problem:** how do abilities/attacks determine who they hit — reliably now, and correctly under future server authority? **Selected:** a `CombatantRegistry` of `IDamageable`s queried with geometry (`QueryInRadius`/`QueryInCone`), not Unity physics overlaps/colliders/layers. **Reasoning:** deterministic and identical on client and server — critical for FishNet authority (no physics desync); no collider/layer/NavMesh setup; allocation-free with a preallocated buffer; easy to unit test. **Trade-off:** O(n) queries over live combatants (fine at slice scale; spatial partitioning is a documented future drop-in — see Technical Debt TD-02).

### ADR-0011 — Combat contracts + `CombatantRegistry` as a DI service in Core (updates ADR-0010)
**Problem:** where do combat contracts live, and how is the registry shared via DI without singletons? **Selected:** the pure-geometry kernel (`IDamageable`, `DamageInstance`, `ICombatantRegistry`, `CombatantRegistry`) lives in `Core.Combat`, exposed via `CoreServices` and created at the composition root; combat *logic* (`DamageResolver`, `HealthComponent`, `DeathHandler`) stays in `Combat`. **Reasoning:** the registry is pure data + geometry with no combat logic, so it belongs with the other Core infrastructure; every entity gets it through the existing `IInjectable` flow — no singletons, no new plumbing.

### ADR-0012 — Unified data-driven ability model
**Problem:** basic attack, Q/W/E/R, and future mob/boss attacks must not each re-implement timing, cooldown, hit detection, or netcode. **Selected:** one `AbilitySystem` phase FSM (Windup→Active→Recovery→Cooldown) drives every ability slot from a data-produced `AbilityParams` bundle; the per-ability *impact* is a small `IAbility` strategy (`ShapedStrikeAbility` covers Cone/Circle; projectile/dash/zone/buff each add one class later). **Reasoning:** timing, cooldown, phase events, and future server authority live in one place, so every ability inherits correct netcode for free; a new ability implements only its impact. Basic attack fits as a 0-windup, non-rooting ability with no special-casing. **Amendment (2026-07-24, C3.2):** the FSM terminates cleanly on interruption — `OnDisable` cancels an in-flight cast so a despawned caster never orphans dependent views or leaves a stuck movement lock.

### ADR-0013 — Telegraphs as a one-way, render-agnostic view assembly
**Problem:** telegraphs must be reusable by every caster, never influence gameplay, and be swappable (mesh → shader/VFX) later without touching gameplay — and they must stay an *honest* promise of the impact area (GDD Pillar 5). **Selected:** a standalone `Runefall.Telegraph` assembly referencing **only** `Runefall.Core`, consuming `AbilityPhaseEvent`; verified one-way dependency (no gameplay assembly references it). A generic `TelegraphPresenter` maps casterId→pooled `ITelegraph`; the concrete `MeshTelegraph` is swappable behind the interface. **Cast rooting** is a data flag (`AbilityDef.RootsCaster`) read by locomotion via a small `ICastState` interface — it blocks movement/manual rotation only, never camera/UI. Basic attack never roots.

### ADR-0014 — Unified Status/Gameplay Effect Framework + `ICombatant`
**Problem:** C3.3 needs crowd control, but the GDD shows CC, buffs/debuffs, DoT/HoT, shields, and stat modifiers are all the same underlying shape — a CC-only system would become a parallel "second effect system." **Selected:** a **composition capability model** — one `EffectController` per entity holding effects; behaviour composed from `[SerializeReference] EffectModule`s on an `EffectDef` (closed for modification — the engine never switches on effect type). Effects act through small capability interfaces an entity implements only if it has them (`ICastInterruptible`, `IMovementConstrainable`, future `IStatModifiable`/`IHealthModifiable`). The **`ICombatant` handle** (`IDamageable` + `Effects` + `GetCapability<T>()`) is the single lookup the registry returns — damage, effects, and future healing/shields/stat-mods all resolve through it, never a parallel path. **C3.3 scope:** stagger + knockback shipped; stat aggregation, stacking, DoT ticks, shields, CC-resistance magnitude, and a central ticker are deliberately deferred (see Technical Debt TD-04/05/06).

### ADR-0015 — `Runefall.Locomotion`
**Problem:** `CharacterMotor`/`ICharacterMotor`/`MoveCommand` lived in `Gameplay.Player`, but `Runefall.Mobs` (C4) correctly references `Combat`, not `Gameplay` — every movable entity (players, mobs, bosses, summons, pets, NPCs) must share one locomotion system with no second implementation ever appearing. **Selected:** extract a dedicated `Runefall.Locomotion` assembly depending on **Core + Data only**, knowing nothing about players, AI, combat, abilities, UI, input, or networking. `CharacterMotor` implements the generic Core capability `IMovementConstrainable`, keeping it combat-agnostic. **Rejected alternatives:** folding the motor into `Combat` (locomotion is not a combat responsibility); leaving it in Gameplay (inverts layering or forces a duplicate mob motor). **Migration:** GUID-preserving file move, zero prefab/scene breakage.

### ADR-0016 — Project Validation Framework
**Problem:** a C2 asset-wiring null bug recurred; the project needs a permanent, extensible guardrail. **Selected:** an editor-only framework — `IProjectValidator` (auto-discovered via `TypeCache`), a `ValidationReport`, and one menu command (`Runefall ▸ Validate ▸ Run All Validators`) producing a consolidated PASS/FAIL report. Adding a validator is a new class only; the runner itself never changes (open/closed principle). First validators: asset-wiring (the C2 recurrence guard) and duplicate-definition-id checking.

### ADR-0017 — `Runefall.Abilities` (extends ADR-0012)
**Problem:** `Runefall.Champions` had become 100% generic ability-engine code with zero champion-specific logic left in it — mis-scoped exactly like the stranded `CharacterMotor` before ADR-0015. The C4 Hollow Husk is a real second consumer that needs the same engine. **Selected:** extract the five generic files into a new `Runefall.Abilities` assembly (`→ Core, Data, Combat`), used by Champions, Mobs, and every future caster. `Runefall.Champions` is retained as an empty stub for future champion-specific runtime. **Extraction gate passed:** a second consumer exists today; no owner assumptions in the code; coupling reduced; the graph is objectively cleaner; the extraction would still be valid if Champions vanished entirely. This is the same "second real consumer" test applied in ADR-0015.

### ADR-0018 — Extraction loop
**Problem:** implement the genre-defining carry→extract→bank-or-lose loop without building a full inventory framework first. **Selected (Option B, minimal real model):** five owners in existing assemblies — `ItemDef` (Data, minimal: Id/DisplayName/Value only), `RaidInventory` + `Stash` + `ExtractionZone` + `LootPickup` (Gameplay), `RaidResultsPanel` (UI, display-only). **No new assembly, no new asmdef edge** — `Runefall.Inventory` stays deferred until inventory becomes a genuine multi-consumer domain (equipment/vendors/crafting/market), per Standing Rule 12. **Ownership seam:** extraction and inventory never reference each other directly; `ExtractionZone` only publishes an event, `MatchController` remains the sole owner of "the raid has ended," and `RaidInventory` reacts to it.

## Programmer Notes
Three ADRs (0015, 0017, and implicitly 0005) share one recurring pattern worth internalizing: **a system gets extracted into its own assembly only when a second real consumer exists today** — never speculatively. This is now a Standing Rule (see `Standing_Engineering_Rules.md`) applied consistently from the Locomotion extraction through the Abilities extraction.

## Appendix
Full source: `Architecture_Decisions.md` (all 18 entries, verified verbatim against source for this document).

---
*Traceability: Cross-cutting, all of Engineering · Owner Discipline: Engineering/Architecture · Status: 17 Accepted, 1 Proposed (ADR-0008).*

---
Document: Assembly_Map.md
Section: 02_Technical
---

# Assembly Map

## Document Metadata
- **Purpose:** The detailed, current reference for every assembly (asmdef) in the project — what it owns, what it depends on, and why it exists (or was deleted).
- **Audience:** Engineering — the document to check before adding a new file to figure out which assembly it belongs in, or before proposing a new assembly.
- **Scope:** The as-built assembly graph through the Architecture Freeze (2026-07-25): 10 runtime assemblies + 8 test assemblies, zero cycles. Builds on the summary table already in `Architecture_Overview.md`.
- **Dependencies:** `Architecture_Overview.md`.
- **Related Documents:** `Architecture_Decision_Log_Index.md` (ADR-0005, 0013, 0015, 0017 — the assemblies added), `Architecture_Retrospectives_Index.md` (R-005 — the 9 assemblies deleted), `Standing_Engineering_Rules.md` Rule 12 (the ownership test assemblies are held to).
- **GDD Chapters Covered:** Ch. 193 (project structure).
- **Current Implementation Status:** Implemented — 18 assemblies (10 runtime, 8 test), zero dependency cycles, verified at every slice closure via the Mandatory Slice Closure Gate 2 (whole-project dependency audit).

## Overview
Every assembly in the current codebase owns a distinct, non-overlapping responsibility, and every dependency edge points strictly downward. This is verified — not assumed — at the close of every implementation slice.

## Detailed Explanation

### Dependency graph (current, 10 runtime assemblies)

```mermaid
flowchart BT
    Core["Runefall.Core<br/>(no first-party deps)"]
    Data["Runefall.Data"] --> Core
    Combat["Runefall.Combat"] --> Data
    Combat --> Core
    Locomotion["Runefall.Locomotion"] --> Data
    Locomotion --> Core
    Abilities["Runefall.Abilities<br/>(was Champions — ADR-0017)"] --> Combat
    Abilities --> Data
    Abilities --> Core
    Telegraph["Runefall.Telegraph<br/>(one-way view — ADR-0013)"] --> Core
    Mobs["Runefall.Mobs"] --> Combat
    Mobs --> Locomotion
    Mobs --> Abilities
    Mobs --> Data
    Mobs --> Core
    Gameplay["Runefall.Gameplay<br/>(top orchestration layer — ADR-0005)"] --> Mobs
    Gameplay --> Abilities
    Gameplay --> Locomotion
    Gameplay --> Combat
    Gameplay --> Data
    Gameplay --> Core
    UI["Runefall.UI"] --> Core
    UI --> Data
    UI --> Combat
    Editor["Runefall.Editor<br/>(editor-only)"] --> Gameplay
    Editor --> UI
    Editor --> Mobs
    Editor --> Abilities
    Editor --> Telegraph
    Editor --> Locomotion
    Editor --> Combat
    Editor --> Data
    Editor --> Core
```
**Nothing references `Runefall.Editor`, `Runefall.Gameplay`, or `Runefall.Telegraph` upward — they sit at (or near) the top of the graph by design (ADR-0005, ADR-0013).**

### Per-assembly detail

| Assembly | Owns | Depends on | Origin |
|---|---|---|---|
| `Runefall.Core` | App lifecycle, event bus (18 typed events), config/data loading, custom camera, input, pooling, shared combat contracts (`IDamageable`, `ICombatantRegistry`), shared capabilities (`IMovementConstrainable`, `ICastInterruptible`) | (none — root) | TDD-00 (original plan) |
| `Runefall.Data` | `DefinitionBase`-derived ScriptableObject defs (`ChampionDef`, `WeaponDef`, `AbilityDef`, `MobDef`, `ItemDef`, `EffectDef`, …) | Core | TDD-00 |
| `Runefall.Combat` | `DamageResolver`, `HealthComponent`-as-`ICombatant`, `EffectController`, `ImpulseBody` | Core, Data | TDD-00 |
| `Runefall.Locomotion` | `ICharacterMotor`, `MoveCommand`, `CharacterMotor` | Core, Data | **ADR-0015** — extracted from `Gameplay.Player` at the 2nd real consumer (Mobs) |
| `Runefall.Abilities` | `AbilitySystem`, `IAbility`, `ShapedStrikeAbility`, `AbilityContext`, `ICastState` — the generic ability engine | Core, Data, Combat | **ADR-0017** — extracted from `Runefall.Champions`, which had become 100% generic |
| `Runefall.Telegraph` | `TelegraphPresenter`, `TelegraphPool`, `MeshTelegraph`, `ITelegraph` | Core only | **ADR-0013** — deliberately one-way; no gameplay assembly may reference it, and it may never reference gameplay |
| `Runefall.Mobs` | Mob base, `AiBrain`, `Faction`, `MobSpawner`, `MotorConfig` | Core, Data, Combat, Locomotion, Abilities | TDD-00 (planned), content proven minimal by R-002 through R-005 |
| `Runefall.Gameplay` | `MatchController`, `PlayerSpawner`, `PlayerController`, `RaidInventory`/`Stash`/`ExtractionZone`/`LootPickup` (ADR-0018) | Core, Data, Combat, Locomotion, Abilities, Mobs | **ADR-0005** — top-of-graph orchestration layer, not in the original plan |
| `Runefall.UI` | `MainMenuPanel`, `HudPanel`, `RaidResultsPanel`, `LoadingOverlayPanel` | Core, Data, Combat (read-only) | TDD-00 |
| `Runefall.Editor` | `RunefallSceneBuilder`, `RunefallGameplayBuilder`, `RunefallVfxBuilder`, the Validation Framework (`IProjectValidator`, `ProjectValidationRunner`) | All (editor-only asmdef) | TDD-00 |
| `Runefall.Tests.*` (8 assemblies) | EditMode + PlayMode tests, one per populated runtime assembly area | Target module | TDD-00 |
| `Runefall.Champions` | (empty — retained as a stub) | — | Emptied by ADR-0017; **not deleted**, unlike the 9 below, because a first champion-specific runtime type is expected soon (M2) |

### Deleted assemblies (R-005, 2026-07-25) and their recreation triggers
`Runefall.Networking`, `Runefall.Inventory`, `Runefall.Economy`, `Runefall.Progression`, `Runefall.Gathering`, `Runefall.World`, `Runefall.Audio`, `Runefall.VFX` — all deleted after being held to the class-level ownership test (owned no compiled code, had no compiled dependant, broke nothing on delete). See `Architecture_Retrospectives_Index.md`'s Future Assembly Roadmap table for the exact recreation trigger per assembly (e.g. `Runefall.Networking` recreates "when the first server-authoritative type is written").

### Why `Runefall.Champions` was kept empty instead of deleted
This is the one asymmetry in the current graph, and it's deliberate, not an oversight: R-005 applied the exact same test to `Champions` as to the other 9, but its recreation trigger (first champion-specific runtime type — M2, imminent) was judged close enough that recreating it twice in quick succession wasn't worth the ~2–3 minute savings. This is noted explicitly so it isn't mistaken for an inconsistency in the rule's application.

## Programmer Notes
Before adding a new `.cs` file, ask: which existing assembly already owns this responsibility? If none does, check the extraction/creation gates in `Standing_Engineering_Rules.md` (Rules 1, 6, 12) before creating a new one.

## Appendix
Full sources: `TDD-00_Architecture_Overview.md`; `Architecture_Audit_2026-07-24.md`; `Architecture_Decisions.md` (ADR-0005, 0013, 0015, 0017); `Architecture_Retrospectives.md` (R-005).

---
*Traceability: GDD Ch. 193 · Milestone M0 (Done), maintained every slice · Owner Discipline: Engineering · Status: Implemented, verified zero-cycle at every slice closure.*

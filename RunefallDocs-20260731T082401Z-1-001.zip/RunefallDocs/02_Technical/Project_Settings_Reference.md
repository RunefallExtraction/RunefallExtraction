---
Document: Project_Settings_Reference.md
Section: 02_Technical
---

# Project Settings Reference

## Document Metadata
- **Purpose:** The checklist of Unity Project Settings that must be tuned to match GDD targets, applied through the editor UI (never hand-edited YAML, to avoid corrupting the project).
- **Audience:** Engineering, especially whoever owns the initial project setup or a settings audit.
- **Scope:** Full reconstruction of `ProjectSettings_Checklist.md`, reconciled against the later ADR-0004 (camera) decision.
- **Dependencies:** `Architecture_Overview.md`.
- **Related Documents:** `Architecture_Decision_Log_Index.md` (ADR-0002 engine version, ADR-0004 camera/Cinemachine).
- **GDD Chapters Covered:** Ch. 5.7 / performance section (quality tiers), 156 (performance budgets).
- **Current Implementation Status:** Checklist items are per-item unconfirmed in source (checkboxes unchecked in the original document) — this reference does not assert they've all been applied, only what they should be set to.

## Overview
Settings are applied through the Unity Project Settings UI and committed as a `ProjectSettings/*.asset` diff, never hand-edited as raw YAML.

## Detailed Explanation

### Already applied (per source, at time of writing)
- **Player → Company Name** = `Runefall Studios` (placeholder — change to the legal entity when known)
- **Player → Product Name** = `Runefall Extraction`

### ⚠️ Reconciliation needed — Cinemachine
The source checklist notes "Cinemachine package added to the manifest (verify it resolves on first open — Unity 6.3 uses Cinemachine 3.x)." **This is superseded:** per **ADR-0004** (same date, 2026-07-20, but a later decision in the sequence), `com.unity.cinemachine 3.1.4` failed to resolve ("aborted") in Unity 6.3, and the project moved to a **custom `CameraController` behind `ICameraDirector`**, with Cinemachine **removed** from the manifest entirely. Per the repository's "document both" rule: the checklist item above is the earlier state; ADR-0004 is the current, correct state. Do not re-add Cinemachine to the manifest without a new ADR.

### Player / Rendering
- Color Space = **Linear** (Edit ▸ Project Settings ▸ Player ▸ Other Settings) — required for correct URP lighting.
- Active Input Handling = **Input System Package (New)** — the new Input System exclusively.
- Graphics APIs: Windows → Direct3D11/12 + Vulkan; Android → Vulkan + GLES3; iOS → Metal.
- URP assigned in Graphics + Quality (PC → `PC_RPAsset`, Mobile → `Mobile_RPAsset`, under `Assets/Settings/`).

### Quality tiers → GDD budgets (Ch. 5.7 / performance section)
Quality levels mapped to four target profiles, each assigned the matching URP asset:

| Tier | Draw calls | Triangles | Notes |
|---|---|---|---|
| PC-High | ≤ 2000 | ≤ 500k on-screen | Shadows on, MSAA as budget allows |
| PC-Low | ≤ 1000 | ≤ 250k | |
| Mobile-High | ≤ 500 | ≤ 200k | Particle emission ×0.5 (Ch. C2) |
| Mobile-Low | ≤ 250 | ≤ 100k | Particle emission ×0.3 |

Texture memory budget trends 2GB (PC) → 250MB (Mobile-Low).

### Build / Scripting
- Scripting Backend: Mono in Editor/dev; **IL2CPP** for Player builds (PC + mobile).
- Target Architectures (Android): ARM64 (+ARMv7 if required by store).
- Managed Stripping Level: Low initially — raise after networking reflection needs are known (FishNet/serialization can be stripping-sensitive).
- Api Compatibility Level: .NET Standard 2.1.

### Server build (Phase 1+, per `TDD-02_Server_and_Orchestration.md`)
Dedicated **Server** build target (Linux, headless) — `-batchmode -nographics`; strip UI/VFX/Audio assemblies via platform defines. **Not yet built** — M12.

### Physics / Time
Fixed Timestep aligned with the 30 Hz server tick where gameplay physics is authoritative — revisit in the networking phase.

### Commit convention
`chore(settings): tune project settings to GDD targets (color space, input, quality tiers)`.

## Programmer Notes
Given ADR-0002 already settled the engine version at Unity 6.3 (superseding the GDD's 2022 LTS text), and ADR-0004 already settled the camera package question, this checklist's remaining open items (quality tiers, IL2CPP, server build target) are the ones still worth auditing directly against a live project rather than assuming from this document alone.

## Appendix
Full source: `ProjectSettings_Checklist.md`; reconciled against `Architecture_Decisions.md` ADR-0002, ADR-0004.

---
*Traceability: GDD Ch. 5.7, 156 · Milestone M0/M13 (settings now, budgets validated per-pillar and at M13) · Owner Discipline: Engineering · Status: Reference checklist, per-item confirmation not tracked in source.*

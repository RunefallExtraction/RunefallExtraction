---
Document: Engine_and_Platform_Decisions.md
Section: 02_Technical
---

# Engine & Platform Decisions

## Document Metadata
- **Purpose:** A single, quick-reference landing page for "what engine/version/platform-level decisions were made and why" — pulling together the relevant ADRs rather than duplicating them.
- **Audience:** Anyone doing initial project setup, onboarding, or auditing platform assumptions.
- **Scope:** Summarizes ADR-0002 (Engine Version) and ADR-0004 (Camera) from `Architecture_Decision_Log_Index.md`, plus the GDD-vs-reality reconciliation noted in `Runefall_Technical_Reference_Ch136-317.md`.
- **Dependencies:** `Architecture_Decision_Log_Index.md`.
- **Related Documents:** `00_Executive/Platform_and_Hardware_Targets.md`, `Project_Settings_Reference.md`.
- **GDD Chapters Covered:** Ch. 135.1, 208 (tech stack / engine).
- **Current Implementation Status:** Both decisions Accepted and in force.

## Overview
Two platform-level decisions correct a GDD/reality mismatch that existed from day one: the engine version, and the camera package.

## Detailed Explanation

### Engine version: Unity 6.3 (ADR-0002)
The GDD (Ch. 135/208) specifies Unity 2022 LTS; the actual project has always been on **6000.3.6f1**. Rather than downgrade to match old documentation, the project standardized on Unity 6.3 — it matches project reality, sits on a newer LTS line, and both FishNet and Nakama support it. The GDD's text is kept for provenance but is superseded by this ADR. See `Architecture_Decision_Log_Index.md` ADR-0002 for full reasoning.

### Camera: custom controller, not Cinemachine (ADR-0004)
The GDD's Ch. 211 sample code uses Cinemachine, and the project's `ProjectSettings_Checklist.md` originally noted Cinemachine had been added to the manifest. **This did not hold** — `com.unity.cinemachine 3.1.4` failed to resolve ("aborted") under Unity 6.3. The project pivoted to a custom `CameraController` behind an `ICameraDirector` interface, and removed Cinemachine from the manifest entirely. This is lighter, deterministic, allocation-free, testable, and removes a package-resolution blocker outright. See `Architecture_Decision_Log_Index.md` ADR-0004, and `Project_Settings_Reference.md` for the reconciliation against the (now superseded) settings checklist note.

### Why both are recorded here together
Both decisions share a shape: the GDD's illustrative/sample-code assumption didn't survive contact with the real Unity 6.3 project, and the fix was a documented, deliberate substitution rather than fighting the mismatch. Anyone reading the GDD's tech-stack chapters or sample code should check this document first for what actually shipped.

## Programmer Notes
If Cinemachine is ever reconsidered (e.g. for a boss-intro cinematic camera), it can be layered behind the existing `ICameraDirector` interface without touching gameplay camera code — this was an explicit design goal of ADR-0004, not an accident.

## Appendix
Full source: `Architecture_Decisions.md` ADR-0002, ADR-0004; `Runefall_Technical_Reference_Ch136-317.md` §10 (Reconciled Facts).

---
*Traceability: GDD Ch. 135.1, 208, 211 · Milestone M0 · Owner Discipline: Engineering · Status: Both decisions Accepted, in force.*

---
Document: Standing_Engineering_Rules.md
Section: 02_Technical
---

# Standing Engineering Rules

## Document Metadata
- **Purpose:** The 13 permanent engineering rules distilled from the project's retrospectives — the default standard every new piece of code is held to.
- **Audience:** Every engineer on the project, from day one.
- **Scope:** Verbatim reconstruction of the "Standing Engineering Rules" section of `Architecture_Retrospectives.md`, plus the Mandatory Slice Closure Gates it operates under.
- **Dependencies:** `Architecture_Retrospectives_Index.md` (where each rule was discovered/added).
- **Related Documents:** `Architecture_Decision_Log_Index.md`, `Architecture_Freeze_Policy.md`.
- **GDD Chapters Covered:** N/A (engineering process).
- **Current Implementation Status:** All 13 rules are active and enforced as of the current Architecture Freeze.

## Overview
**Meta-principle:** every new class, interface, state, abstraction, asset, or dependency starts **REJECTED** until it proves the existing architecture cannot already own the responsibility. Improvement on this project has consistently come from *removing* abstractions, not adding them.

## Detailed Explanation

### The 13 rules

1. **Extraction 5-point gate** — extract a system into its own assembly only when: a genuine 2nd consumer exists *today*; the code carries no owner assumptions; coupling is reduced; the dependency graph gets objectively cleaner; it still makes sense if the original assembly vanished entirely.

2. **Name assemblies by responsibility, not by first consumer.** Example: `Gameplay.Player` → `Locomotion`; `Champions` → `Abilities`. An assembly that ends up holding only a generic engine must not stay named after whichever entity happened to use it first.

3. **The `*Def` three-condition rule.** Every field on any Definition ScriptableObject (`ChampionDef`, `WeaponDef`, `AbilityDef`, `EffectDef`, `MobDef`, `ItemDef`, etc.) must satisfy all three: (a) traceable to the final GDD or an approved ADR; (b) immutable authored data — no runtime state; (c) an identified runtime owner that actually consumes it. Fail any one → remove, relocate, or postpone the field.

4. **Audit definition fields against the GDD, never against a sibling definition.** Never inherit a field "because the similar def has it" — `MobDef` inheriting `Armor`/`MagicResist`/`RotationSpeed` from `ChampionDef` by analogy (later removed, R-003) is the canonical cautionary example.

5. **Runtime-component rule** — a runtime component must own runtime state or runtime behaviour. A component that merely exposes immutable authored data must not exist; expose that data on an existing component instead (e.g. through `ICombatant`). Definitions own authored data; components own runtime; nothing exists as pure glue between them.

6. **Contracts ship with their first implementation.** No interface without a genuine 2nd consumer; no capability (scheduler, HFSM, data-driven graph) before the first consumer actually requires it.

7. **Movement intent rule.** Everything that wants to move an entity — input, AI, knockback, patrol, escort, scripted sequences — produces a `MoveCommand`. Only `CharacterMotor` ever actually moves an entity. Never write a second motor.

8. **Document extraction seams before they hide.** When one class temporarily owns a responsibility that will extract later, record the trigger and the future owner *now*, not when the extraction happens.

9. **Three mechanical disciplines:** cross-assembly moves preserve `.meta` GUIDs; tooling reflection is exception-guarded (a bad plugin/validator can never abort a batch run); shared cross-domain capabilities live in Core as generic interfaces.

10. **Deterministic startup failures over lazy runtime recovery.** Bind required dependencies explicitly (e.g. in `Awake`) and fail loud if missing — do not lazily bind and silently no-op. Lazy binding hides misconfiguration; this is the same philosophy that drives the Validation Framework (ADR-0016).

11. **Runtime Ownership Rule.** Architecture optimizes for *responsibility ownership, cohesion, and coupling* — **not** for minimizing class count. A runtime class may grow while it owns one cohesive responsibility; extract a subset only when that subset becomes independently cohesive, reusable, or introduces measurable coupling. **Never extract merely for size, line count, or method count.** Conversely, a new class that owns a distinct responsibility no existing class can correctly own is good architecture, not regression. The goal is not "one class, one property" — it's that every runtime type continuously justifies its existence through ownership.

12. **Create assemblies on first real consumer.** An assembly is held to the *same* ownership test as a class (rules 5, 6, 11). An assembly that owns no compiled code, has no compiled dependant, and breaks nothing if deleted **must not exist** — it's an empty abstraction with no owner, exactly like an interface with no consumer. Recreating one costs ~2–3 minutes (Unity auto-generates the GUID and auto-includes it in compilation/CI), so there's no carrying cost to deferring — the future roadmap lives in documentation (see the Future Assembly Roadmap in `Architecture_Retrospectives_Index.md`), not in empty placeholder asmdefs.

13. **Domain reporters are per-domain — never a generic hub.** A *reporter* (e.g. `PlayerHealthReporter`, `LootReporter`) is a legitimate class that owns one behaviour: translating a single domain's authoritative runtime state into primitive UI-facing events across the Gameplay→UI boundary that must not be crossed directly. It owns no gameplay rule and little/no state — acceptable *only* because it's strictly scoped to one domain and justified by the assembly boundary plus the server-authoritative future (the state owner itself stays UI-free for headless/server use). A reporter that begins reading a second domain has become the god-reporter anti-pattern and must be split. Every future domain (quests, crafting, economy, progression, reputation, …) gets its own reporter, never an extension of an existing one.

### Mandatory Slice Closure Gates (operating procedure these rules feed into)
Every slice is marked CLOSED only after all five pass, in order:
1. Static validation (compile-clean, no temp debug/TODOs)
2. Whole-project dependency audit (zero cycles, every edge downward and justified)
3. Whole-project ownership audit (every assembly owns one distinct responsibility)
4. Production scalability review (scales via *extend at a measurable trigger*, never *new framework*)
5. Architecture retrospective (what changed and why it stayed/became simpler)

Then: Unity verification + adversarial review, then CLOSE.

## Programmer Notes
These rules are not aspirational — every one of them was **discovered by a specific retrospective** after a specific slice, and every one has since been applied and held on subsequent slices (see `Architecture_Retrospectives_Index.md` for the R-001–R-006 narrative each rule came from). When proposing new code, check it against this list before writing it, not after.

## Appendix
Full source: `Architecture_Retrospectives.md`, "Standing Engineering Rules" and "Mandatory Slice Closure Gates" sections.

---
*Traceability: Cross-cutting, all of Engineering · Owner Discipline: Engineering · Status: Active, enforced under the Architecture Freeze.*

---
Document: Architecture_Overview.md
Section: 02_Technical
---

# Architecture Overview

## Document Metadata
- **Purpose:** The top-level technical architecture — module boundaries, client/server split, shared mandatory patterns — and, critically, where the **as-built** codebase has already diverged from the original TDD-00 plan, and why.
- **Audience:** Every engineer; the first document to read before touching any code.
- **Scope:** `TDD-00_Architecture_Overview.md` (the original plan, 2026-07-20) reconciled against `Architecture_Audit_2026-07-24.md` and the ADR/Retrospective history (the as-built reality, through 2026-07-25).
- **Dependencies:** None (root technical document).
- **Related Documents:** `Architecture_Decision_Log_Index.md`, `Architecture_Retrospectives_Index.md`, `Standing_Engineering_Rules.md`, `Assembly_Map.md` (NOT YET WRITTEN — the detailed per-assembly reference this document summarizes).
- **GDD Chapters Covered:** Ch. 135 (tech stack), 191–213 (foundation/core framework), 193 (project structure).
- **Current Implementation Status:** Implemented — this describes the actual current architecture as of the Architecture Freeze (2026-07-25), not just the plan.

## Overview
This document exists specifically to satisfy the repository rule "if implementation differs from design, document both, never silently overwrite." TDD-00 planned a 16-assembly module map on 2026-07-20; by the Architecture Freeze on 2026-07-25, the actual codebase has **10 populated runtime assemblies + 8 test assemblies (18 total, zero cycles)** — smaller, and shaped differently, than planned. Both pictures are recorded below.

## Detailed Explanation

### Client / Server / Backend split (Planned Design — unchanged, not yet built)
```
┌── Dedicated Game Server (headless Unity, authoritative) ──┐
│  Combat · Champions · Mobs · World · Loot · Movement       │  FishNet 30 Hz
│  validates all input, owns world state, emits phase events │◄────────────┐
└────────────────────────────────────────────────────────────┘             │
        ▲ RPC/SyncVar (state down, input up)                                │
┌── Game Client (Unity, thin) ──────────────────────────────┐              │
│  Input · Prediction · Camera · VFX · Audio · UI/HUD        │              │
└────────────────────────────────────────────────────────────┘              │
        ▲ REST/WebSocket (accounts, stash, market, match)                    │
┌── Backend Services ────────────────────────────────────────┐              │
│  Nakama (auth, matchmaking) · PostgreSQL · Redis · Timescale│──────────────┘
│  Node.js Orchestrator (spawns/kills game servers on K8s)   │
└────────────────────────────────────────────────────────────┘
```
**Status:** this three-tier split remains the target architecture (TDD-00/01/02/03). **Not yet built** — the current codebase is single-player, with every gameplay system deliberately authored behind server-authoritative-ready seams (command→simulation→event) so this retrofit does not require gameplay rewrites (ADR-0005 is the first concrete instance of this seam).

### Module map — Planned Design (TDD-00, 2026-07-20)

| Assembly | Responsibility | May depend on |
|---|---|---|
| `Runefall.Core` | App lifecycle, event bus, config/data loading, camera, input, pooling | (none) |
| `Runefall.Data` | ScriptableObject defs | Core |
| `Runefall.Networking` | FishNet layer, spawner, Nakama/Redis clients | Core, Data, FishNet |
| `Runefall.Combat` | Damage, CC, telegraphs, hit validation, combat logging | Core, Data, Networking |
| `Runefall.Champions` | Champion base + 4 kits, ability system, relics | Core, Data, Networking, Combat |
| `Runefall.World` | Map, terrain, rivers, props, landmarks, storm/extraction | Core, Data, Networking |
| `Runefall.Mobs` | Mob base, families, spawner, boss FSMs | Core, Data, Networking, Combat |
| `Runefall.Inventory` | Items, equipment, durability, gear appearance, sockets | Core, Data, Networking |
| `Runefall.Gathering` | Nodes, resources, refining, crafting | Core, Data, Networking, Inventory |
| `Runefall.Economy` | Loot, market, banking, insurance | Core, Data, Networking, Inventory |
| `Runefall.Progression` | 15 skills, mastery, talents, collection, factions | Core, Data, Networking |
| `Runefall.UI` | HUD, menus, lobby, matchmaking, market/inventory UI | Core, Data |
| `Runefall.Audio` | Middleware, ability/ambient cues | Core, Data |
| `Runefall.VFX` | VFX pool, shared particle library, telegraph prefabs | Core, Data |
| `Runefall.Editor` | Greybox builder, scene setup, validators | all |
| `Runefall.Tests.*` | EditMode + PlayMode tests per module | target module |

### Module map — Current Implementation (as-built, through Architecture Freeze 2026-07-25)

| Assembly | Responsibility | Relationship to the plan |
|---|---|---|
| `Runefall.Core` | App lifecycle, event bus (18 typed `IGameEvent` structs), config/data loading, camera (custom, not Cinemachine — ADR-0004), input, pooling, shared combat contracts (`IDamageable`, `ICombatantRegistry` — ADR-0011), shared capabilities (`IMovementConstrainable`, `ICastInterruptible` — ADR-0014) | As planned, but now also holds the Core-side halves of Combat's contracts (ADR-0011) and the Effect Framework's capability interfaces (ADR-0014) |
| `Runefall.Data` | `DefinitionBase`-derived ScriptableObject defs (`ChampionDef`, `WeaponDef`, `AbilityDef`, `MobDef`, `ItemDef`, `EffectDef`, …) | As planned |
| `Runefall.Combat` | Damage resolution, `HealthComponent`-as-`ICombatant`, `EffectController`, `ImpulseBody` | As planned, minus telegraphs (moved out — see Telegraph below) and minus networking (not yet built) |
| `Runefall.Abilities` *(was `Runefall.Champions`)* | The generic ability engine: `AbilitySystem`, `IAbility`, `ShapedStrikeAbility`, phase FSM | **Renamed via ADR-0017** — it had become 100% generic (zero champion-specific code) and Mobs needed the same engine; `Runefall.Champions` retained as an empty stub for future champion-only runtime |
| `Runefall.Locomotion` *(new, not in original plan)* | `ICharacterMotor`, `MoveCommand`, `CharacterMotor` | **Added via ADR-0015** — extracted from `Gameplay.Player` once Mobs (a second real consumer) needed the same motor; depends only on Core+Data |
| `Runefall.Gameplay` *(new, not in original plan)* | Match/session orchestration: `MatchController`, `PlayerSpawner`, `PlayerController`, extraction/loot ownership | **Added via ADR-0005** — a top-of-graph feature layer for cross-system orchestration that the original plan had no home for |
| `Runefall.Mobs` | Mob base + AI (`AiBrain`, `Faction`), spawner | As planned in spirit, but the actual AI runtime turned out to be one ~150-line class plus one property, not a framework (R-004) |
| `Runefall.Telegraph` *(new, not in original plan)* | The one-way, render-agnostic ability telegraph view | **Added via ADR-0013** — telegraphs needed to be reusable by every caster and provably unable to affect gameplay, which required their own assembly referencing only Core |
| `Runefall.UI` | HUD, menus, results screen | As planned, scope so far: menu/HUD/results/loading |
| `Runefall.Editor` | Scene/gameplay builders, the Validation Framework (ADR-0016) | As planned |
| `Runefall.Tests.*` (8 assemblies) | EditMode + PlayMode tests | As planned |
| ~~`Runefall.Networking`~~ | — | **Deleted** (R-005) — empty placeholder, zero compiled code; recreated when the first server-authoritative type is actually written (FishNet integration begins, M12) |
| ~~`Runefall.Champions`~~ | — | Emptied by ADR-0017, then **its emptiness is itself the current, correct state** — not deleted (kept as a stub) because a first champion-specific runtime type is expected relatively soon in M2 |
| ~~`Runefall.Inventory`~~ | — | **Deleted** (R-005) — the Extraction Vertical Slice (ADR-0018) deliberately built the extraction loot loop *without* it (a 3-field `ItemDef` inside Data + Gameplay-owned `RaidInventory`/`Stash`); recreated at the first item/stack/container runtime type (M3) |
| ~~`Runefall.Economy`~~, ~~`Runefall.Progression`~~, ~~`Runefall.Gathering`~~, ~~`Runefall.World`~~, ~~`Runefall.Audio`~~, ~~`Runefall.VFX`~~ | — | **All deleted** (R-005) — same reasoning: empty placeholders held to the class-level ownership test (Standing Rule 12), each with a documented recreation trigger (see `Architecture_Retrospectives_Index.md`, Future Assembly Roadmap) |

**Why the shrinkage is not a regression:** every deletion followed the same objective test used for classes — no compiled code, no compiled dependant, breaks nothing on delete — and every deleted assembly has a documented, specific trigger for recreation. See `Standing_Engineering_Rules.md` Rule 12 and `Architecture_Retrospectives_Index.md` R-005 for the full reasoning.

**Dependency rule (unchanged from the plan):** arrows point downward only. `Runefall.Core` depends on nothing first-party. Zero cycles, audited at every slice closure (Mandatory Slice Closure Gate 2).

### Shared patterns (mandatory, unchanged from the plan, verified still in force)
- **Event bus** (`Core/Architecture/EventSystem.cs`) — typed publish/subscribe, no polling of other modules. Now 18 typed `IGameEvent` structs, allocation-free.
- **Composition root** (`Core/Architecture/ApplicationManager.cs`) — builds and wires managers per scene; systems receive dependencies via `IInjectable`, never fetch globals. **Zero gameplay singletons** confirmed at every audit to date.
- **Config loading** (`Core/Data/ConfigManager.cs` + `DataManager.cs`) — ScriptableObjects for gameplay tuning, JSON in `StreamingAssets/Configs` for server/deploy config (not yet needed — no server build exists).
- **Object pooling** — planned for hot paths (projectiles, VFX, damage numbers); `TelegraphPool` (ADR-0013) is the first concrete instance shipped.

### Scenes (GDD Ch. 124–134)
Planned: `Boot → MainMenu → Lobby → Loading → Raid`. As-built (per ADR-0007): `Boot → MainMenu → Loading → Raid_Greybox`, event-driven via `SceneDirector` + a persistent bootstrap object + a persistent `LoadingOverlayPanel` — no dedicated Loading *scene* was needed (a Lobby scene is not yet built; matchmaking/lobby is M12).

## Programmer Notes
This document will need another reconciliation pass once Networking (M12) actually begins — at that point `Runefall.Networking` gets recreated for real, and the Client/Server/Backend split above stops being purely aspirational. Until then, treat the "Current Implementation" table as the accurate picture of what exists to build against.

## Appendix
Full sources: `TDD-00_Architecture_Overview.md` (2026-07-20); `Architecture_Audit_2026-07-24.md`; `Architecture_Decisions.md` (ADR-0005, 0013, 0015, 0017); `Architecture_Retrospectives.md` (R-004, R-005).

---
*Traceability: GDD Ch. 135, 191–213, 193 · Milestone M0 (Done) · Owner Discipline: Engineering/Architecture · Status: Implemented (as-built architecture documented above).*

---
Document: Technical_Debt_Register.md
Section: 02_Technical
---

# Technical Debt Register

## Document Metadata
- **Purpose:** The consolidated log of deliberately deferred engineering decisions — conscious, documented trade-offs, not bugs — and exactly what would trigger fixing each one.
- **Audience:** Engineering, Production (for milestone-trigger awareness).
- **Scope:** Full reconstruction of `Technical_Debt.md`, current as of its 2026-07-24 (C3.3 close-out) last update.
- **Dependencies:** `Architecture_Decision_Log_Index.md`, `Architecture_Retrospectives_Index.md`.
- **Related Documents:** `Coding_Standards.md`, `01_Production/Risk_Register.md`.
- **GDD Chapters Covered:** N/A (implementation debt, not design).
- **Current Implementation Status:** 14 open items, 2 resolved this register (TD-16 resolved 2026-07-25 by the empty-assembly cull), plus 2 items resolved before ever needing a TD number (A1, A4 from the 2026-07-24 audit).

## Overview
"Debt introduced at close should normally be **None**" — items on this register are pre-existing, deliberate deferrals with a clear owner and trigger, not accumulating mess. Sixteen items are tracked (TD-01 through TD-16); TD-16 has already been resolved.

## Detailed Explanation

### Open / tracked items

| # | Item | Type | Introduced | Trigger / Milestone | Notes |
|---|---|---|---|---|---|
| TD-01 | Per-entity `Update()` in `AbilitySystem` + `EffectController` | Performance | C3.1 / C3.3 | Perf/Networking pass, or when concurrent casters/effects grow | `EffectController.Tick(dt)` is already extracted for a central `EffectTicker`; `AbilitySystem` would follow the same pattern. Not needed at current entity counts. |
| TD-02 | `CombatantRegistry` O(n) queries | Performance | C2 | Perf pass, when profiling shows hit-query cost | Spatial partitioning is a drop-in behind `ICombatantRegistry` (ADR-0010/0011). |
| TD-03 | Timing uses `Time.time` / `Time.deltaTime` | Multiplayer | C3.1–C3.3 | Networking milestone (FishNet) | Swap to the server tick; the single-timing-source design isolates this. Applies to ability phases, cooldowns, effect durations, impulse decay. |
| TD-04 | Effect framework — stat-modifier aggregation, stacking rules, DoT/HoT ticks, shields/temp-HP | Design (deferred by intent) | C3.3 | First real consumer (progression / itemization / elemental batches) | Each is an additive `EffectDef` field + at most one capability interface. "Wait for the second case" to avoid wrong abstractions (ADR-0014). |
| TD-05 | CC-resistance magnitude (tenacity) | Design (deferred) | C3.3 | Progression/skill system | Hook present (`EffectDef.Resistable`); resistance = 0 until skills exist (GDD Ch. 33 formula). |
| TD-06 | `Runefall.Effects` assembly extraction | Architecture | C3.3 | When effect module count / compile pressure justifies isolation | Currently effects live in Core/Data/Combat; extraction is a file move + asmdef. |
| TD-07 | `HealthComponent` doubles as the `ICombatant` handle | Architecture (watch) | C3.3 | When a 3rd combat facet lands (stats/shields) | Consider extracting a dedicated `Combatant` facade aggregating Health + Effects + capabilities. Thin today; monitor for god-object creep. |
| TD-08 | Telegraph polish — per-champion color, shader/VFX fill, dedicated render layer | Polish | C3.2 | Polish milestone (C8) / Art | `ITelegraph` seam makes the renderer swap gameplay-free; layering via transparent-queue + ground offset is sufficient now. |
| TD-09 | `ImpulseBody` knockback ignores collision (transform-based) | Design (greybox) | C3.3 | C4 (mobs use `CharacterMotor`) / polish | Inert dummies can be pushed through geometry. `CharacterMotor` knockback respects collision. |
| TD-10 | Effect networking — server authority, replication, save/load/replay/spectator | Multiplayer | C3.3 | Networking + Persistence milestones | Per-entity `EffectController` → `NetworkBehaviour`; effects are transient (re-derived on load); replay/spectator reconstruct from the server apply/remove stream + events. |
| TD-11 | Effect-module re-entrancy (a module applying/removing effects during `OnRemove`/`OnTick`) | Architecture (watch) | C3.3 | When complex modules (e.g. on-expiry procs) land | Current modules don't re-enter; if needed, iterate a snapshot or defer mutations. |
| TD-12 | Fat `Runefall.Core` — Input/Camera/SceneFlow are not kernel | Architecture | Audit 2026-07-24 | Before those subsystems grow | Extract to own assemblies for compile isolation + clearer boundaries. Small now (160/227/78 lines), higher cost later. |
| TD-13 | No logging/telemetry abstraction (ad-hoc `Debug.*`) | Process | Audit 2026-07-24 | Server build / observability milestone | Introduce a thin `ILog` (levels/categories/sinks) wrapping `Debug`. Low migration cost. |
| TD-14 | Editor builders will grow monolithic (`RunefallSceneBuilder`/`RunefallGameplayBuilder`) | Design | Audit 2026-07-24 | When content generation grows | Split by concern (champion/effect/scene generators). Cohesive today. |
| TD-15 | Android reads StreamingAssets from inside the APK (sync file read won't work) | Implementation | M1 | Mobile-platform milestone | Tracked marker in `ConfigService` (`TODO: HUMAN_REVIEW`); needs an async/`UnityWebRequest` StreamingAssets loader on Android. |

### Resolved items

| # | Item | Resolution |
|---|---|---|
| **TD-16** | ~~Pre-scaffolded empty assemblies referenced by nobody~~ | **RESOLVED 2026-07-25.** Held each empty assembly to the class ownership test (Standing Rule 12). All 9 (Networking/Champions/Inventory/Economy/Progression/Gathering/World/Audio/VFX) owned nothing, had no compiled dependant, broke nothing on delete → deleted. Assemblies 27→18, all populated, zero cycles. Future domains now tracked as documented creation triggers (R-005 Future Assembly Roadmap), not empty asmdefs. |
| **A1** | Locomotion stranded in `Gameplay.Player` | Resolved 2026-07-24 (architecture checkpoint): extracted `Runefall.Locomotion` (ADR-0015). Mobs/summons/pets/NPCs now reuse one motor; zero cycles. |
| **A4** | No editor validation guardrail | Resolved 2026-07-24: Validation Framework (ADR-0016) with asset-wiring + duplicate-id validators, extensible via `IProjectValidator`. |

## Producer Notes
Several items here (TD-04, TD-05, TD-06) are explicitly gated on "first real consumer" rather than a date — this is the Standing Rules philosophy (`Standing_Engineering_Rules.md` Rules 1/6/12) applied to debt, not just to new abstractions: don't build the generalized version until something concrete actually needs it.

## QA Notes
TD-09 (`ImpulseBody` knockback ignoring collision) is a known, accepted visual bug on inert test dummies only — `CharacterMotor`-driven entities (players, and mobs from C4 onward) are unaffected. Do not file this as a new bug against mob knockback; it's tracked here.

## Appendix
Full source: `Technical_Debt.md` (last updated 2026-07-24, C3.3 close-out; TD-16 resolution recorded 2026-07-25).

---
*Traceability: Cross-cutting, all of Engineering · Owner Discipline: Engineering · Status: 14 open, 2 resolved (TD-16, plus A1/A4 pre-numbering).*

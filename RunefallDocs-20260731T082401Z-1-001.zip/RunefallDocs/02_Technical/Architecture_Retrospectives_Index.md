---
Document: Architecture_Retrospectives_Index.md
Section: 02_Technical
---

# Architecture Retrospectives — Index (R-001 to R-006)

## Document Metadata
- **Purpose:** The permanent, running log of what was learned at the close of every Level-3 implementation slice — not a summary of work done, but of what the work taught about the architecture.
- **Audience:** Engineering (primary).
- **Scope:** Full reconstruction of `Architecture_Retrospectives.md` — the Architecture Freeze policy, the Mandatory Slice Closure Gates, and retrospectives R-001 through R-006 (newest first in the source; presented oldest-first here for narrative continuity).
- **Dependencies:** `Architecture_Decision_Log_Index.md`.
- **Related Documents:** `Standing_Engineering_Rules.md` (the 13 permanent rules distilled here, given their own reference document rather than duplicated in full), `Architecture_Freeze_Policy.md`, `13_AI/AI_Gameplay_Overview.md` (NOT YET WRITTEN).
- **GDD Chapters Covered:** N/A (process/architecture history).
- **Current Implementation Status:** Six retrospectives closed (R-001 through R-006); the Architecture Freeze declared after R-005 remains in effect as of the latest project status.

## Overview
Every Level-3 implementation slice ends with a retrospective here. Read together, R-001 through R-006 tell one continuous story: the codebase got **simpler while gaining gameplay**, because every new type was rejected by default until it proved it couldn't be owned by something that already existed.

## Detailed Explanation

### 🔒 Architecture Freeze — in effect since 2026-07-25 (governing policy)
The foundational architecture is considered **complete**. One principle governs the whole project: *nothing exists before it owns a real, measurable responsibility* — now applied consistently across classes, interfaces, runtime components, definitions, and assemblies.

**Architecture changes are now reactive, not proactive.** A subsystem may be changed **only** when implementation exposes one of these measurable triggers:
1. Ownership ambiguity
2. Duplicated responsibility
3. Coupling that prevents extension
4. An objective dependency-graph improvement
5. A measurable runtime or memory bottleneck
6. A repeated implementation pattern across multiple real consumers

If none exists: **build gameplay.** Do not reopen a closed slice without objective evidence of a trigger.

**Frozen subsystems** (stable unless implementation proves a deficiency): Core DI + event system · Definition architecture · Validation framework · Locomotion architecture · Ability architecture · AI ownership model · Mob architecture · Assembly structure · Dependency direction · Ownership rules · Review process.

**Priority shift:** effort now goes to gameplay, combat feel, champions, mobs, bosses, progression, loot, extraction flow, matchmaking, networking, persistence, content pipeline, tools, balancing, performance, production readiness. **Success is measured by playable features, not refined infrastructure.**

### Mandatory Slice Closure Gates (added 2026-07-24)
Every slice is marked CLOSED only after all five pass:
1. **Static validation** — compile-clean, no temp debug/TODOs.
2. **Whole-project dependency audit** — all assemblies: zero cycles, every edge downward and justified, no convenience/unused edges.
3. **Whole-project ownership audit** — every assembly owns one distinct responsibility; no overlap; no unjustified class.
4. **Production scalability review** — how the change scales to hundreds of entities/more types/bosses; the answer must be *extend at a measurable trigger*, never *new framework*.
5. **Architecture retrospective** — what changed and why it stayed or became simpler.

Then: Unity verification + adversarial review, then CLOSE.

### The six retrospectives (chronological)

**R-001 — Architecture Checkpoint: `Runefall.Locomotion` + Validation Framework (2026-07-24).** The first extraction. Confirmed a GUID-preserving `.meta` move keeps prefab/scene references intact; confirmed `Runefall.Locomotion` needs only Core+Data because `CharacterMotor` reaches the effect system through the generic `IMovementConstrainable` capability, not through Combat. **Surprise:** adversarial review found `Activator.CreateInstance` sitting outside a try/catch in the new validator — a single bad future validator could have aborted the whole run; not caught by the happy-path test, caught by deliberately challenging the code. **New rules:** movement execution vs. decision separation (only `CharacterMotor` moves anything); tooling reflection must be exception-guarded; cross-assembly moves preserve `.meta` GUIDs; shared cross-domain capabilities live in Core as generic interfaces.

**R-002 — C4 Slice 0: `Runefall.Abilities` extraction (2026-07-24).** The cleanest extraction yet — the file-by-file audit (introduced the prior slice) confirmed all five files were generic before any file moved, making the extraction mechanical and behavior-neutral. **No surprises** — proof the pattern (Locomotion → Abilities) is now repeatable and low-risk. **New rule:** name assemblies by responsibility, not by first consumer (`Champions` should have been `Abilities` from the start — same lesson as `Gameplay.Player` → `Locomotion`).

**R-003 — C4 Slice 1: `MobDef` + `Faction` + `MobDefValidator` (2026-07-24).** The AI *data model* slice, reduced by successive approval gates from ~12 proposed types down to **3**. **Surprise:** `Armor`, `MagicResist`, and `RotationSpeed` had been inherited onto `MobDef` *by analogy to `ChampionDef`*, not from the GDD — the final GDD field audit showed mob stat tables author no armor/MR/rotation (mob durability is HP + tier only), and the gate removed them. **Root lesson:** audit a definition's fields against the GDD itself, never against a sibling definition.

**R-004 — C4 Slice 2: `AiBrain` + `ICombatant.Faction` (2026-07-24).** The entire Husk AI runtime shipped as **one class + one property**. This slice *added* real gameplay (perceive → chase → attack → leash → return) while *removing* 9 of the 11 originally-proposed types (scheduler, HFSM, state classes, `AiBrainDef`, blackboard, perception, selector, contexts, `FactionComponent`) — reuse and composition over new frameworks: a mob is the same `HealthComponent`/`AbilitySystem`/`CharacterMotor`/`EffectController`/`CombatantRegistry` a champion uses, driven by a thin controller that owns only orchestration. **Cohesion audit:** `AiBrain` is ~150 lines, every field earns its place, and stays that size through Slice 3. **Lesson for the rest of the project:** adding gameplay does not require adding architecture.

**R-005 — C4 Slice 3: `MobSpawner` + `MotorConfig` + empty-assembly cull (2026-07-25).** The defining move: **9 empty runtime assemblies were deleted** (`Networking, Champions, Inventory, Economy, Progression, Gathering, World, Audio, VFX`) after being held to the exact same ownership test that had already removed 9 AI types. Assembly count went **27 → 18** (10 runtime + 8 test), zero dangling references, zero cycles. `MotorConfig` (a definition-agnostic locomotion contract) also cut the `Locomotion → Data` edge. Gameplay went up (a visible, functioning mob) while nodes, edges, and API surface all went down simultaneously. **New Standing Rule 12:** hold assemblies to the same ownership test as classes; the future roadmap lives in documentation (see the Future Assembly Roadmap table below), not in empty placeholder asmdefs, because recreating one costs only 2–3 minutes.

**R-006 — Extraction Vertical Slice: the loop + first Gameplay Ownership Audit (2026-07-25).** The first gameplay slice built entirely under the Freeze. **Freeze held:** no new assembly, no new asmdef edge — 18 assemblies, zero cycles, unchanged; gameplay was added purely as new types inside owners that already existed, plus three event messages. Introduced the **Mandatory Gameplay Ownership Audit** (four questions per new runtime class: runtime state, runtime behaviour, why not an existing owner, what breaks if deleted) — applied to `RaidInventory`, `Stash`, `ExtractionZone`, `LootPickup`, `RaidResultsPanel`, and `LootReporter`, with every class answering all four cleanly. **New rule (Standing Rule 13):** domain reporters are strictly per-domain, never a generic hub — `LootReporter` is the loot-domain analog of the existing `PlayerHealthReporter`, and any future domain (quests, crafting, economy, progression, reputation) gets its own reporter, never an extension of an existing one.

### Future Assembly Roadmap (from R-005 — deferred, not deleted-forever)
Each assembly is recreated only when its objective trigger fires:

| Assembly | Status | Objective creation trigger |
|---|---|---|
| `Runefall.Networking` | Deleted | First server-authoritative type is written (FishNet integration begins) |
| `Runefall.Champions` | Deleted | First champion-specific runtime type that `Runefall.Abilities` cannot own |
| `Runefall.Inventory` | Deleted | First item/stack/container runtime type |
| `Runefall.Economy` | Deleted | First currency/market/trade runtime type |
| `Runefall.Progression` | Deleted | First XP/level/unlock runtime type |
| `Runefall.Gathering` | Deleted | First resource-node/harvest runtime type |
| `Runefall.World` | Deleted | First zone/streaming/POI runtime type |
| `Runefall.Audio` | Deleted | First audio-routing/mixer runtime type beyond raw AudioSource |
| `Runefall.VFX` | Deleted | First pooled/data-driven VFX type beyond ParticleSystem |

## Programmer Notes
If you are about to propose a new interface, assembly, or abstraction, first check: does a second real consumer for it exist *today*? If not, this repository's entire architectural history says: don't build it yet, document the trigger, and move on. This is not a stylistic preference — it produced measurable simplification (27→18 assemblies, 11→2 AI types) while gameplay was actively being added, not paused.

## Appendix
Full source: `Architecture_Retrospectives.md` (verified verbatim against source for this document).

---
*Traceability: Cross-cutting, all of Engineering · Owner Discipline: Engineering/Architecture · Status: 6 retrospectives closed; Architecture Freeze in effect.*
